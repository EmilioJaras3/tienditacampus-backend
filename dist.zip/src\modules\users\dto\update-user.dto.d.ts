export declare class UpdateUserDto {
    firstName?: string;
    lastName?: string;
    phone?: string;
    avatarUrl?: string;
    twoFactorCode?: string | null;
    twoFactorExpires?: Date | null;
}
