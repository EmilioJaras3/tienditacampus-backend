import { DailySale } from './daily-sale.entity';
import { Product } from '../../products/entities/product.entity';
export declare class SaleDetail {
    id: string;
    dailySaleId: string;
    dailySale: DailySale;
    productId: string;
    product: Product;
    quantityPrepared: number;
    quantitySold: number;
    quantityLost: number;
    wasteReason: 'expired' | 'damaged' | 'other' | null;
    wasteCost: number;
    unitCost: number;
    unitPrice: number;
    subtotal: number;
    createdAt: Date;
}
