export declare class RescueAdminDto {
    email: string;
    secret: string;
}
