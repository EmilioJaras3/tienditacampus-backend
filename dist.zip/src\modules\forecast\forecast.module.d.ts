export declare class ForecastModule {
}
