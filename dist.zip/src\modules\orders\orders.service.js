"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OrdersService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const order_entity_1 = require("./entities/order.entity");
const order_item_entity_1 = require("./entities/order-item.entity");
const product_entity_1 = require("../products/entities/product.entity");
const inventory_record_entity_1 = require("../inventory/entities/inventory-record.entity");
const daily_sale_entity_1 = require("../sales/entities/daily-sale.entity");
const sale_detail_entity_1 = require("../sales/entities/sale-detail.entity");
const inventory_service_1 = require("../inventory/inventory.service");
let OrdersService = class OrdersService {
    constructor(orderRepo, dataSource, inventoryService) {
        this.orderRepo = orderRepo;
        this.dataSource = dataSource;
        this.inventoryService = inventoryService;
    }
    async createOrder(dto, buyer) {
        const queryRunner = this.dataSource.createQueryRunner();
        await queryRunner.connect();
        await queryRunner.startTransaction();
        try {
            let totalOrderAmount = 0;
            const orderItemsToSave = [];
            for (const item of dto.items) {
                const product = await queryRunner.manager.findOne(product_entity_1.Product, {
                    where: { id: item.productId, sellerId: dto.sellerId, isActive: true }
                });
                if (!product) {
                    throw new common_1.NotFoundException(`Producto ${item.productId} no encontrado o inactivo`);
                }
                const activeInventory = await queryRunner.manager.findOne(inventory_record_entity_1.InventoryRecord, {
                    where: { productId: product.id, status: 'active' }
                });
                if (!activeInventory || activeInventory.quantityRemaining < item.quantity) {
                    throw new common_1.BadRequestException(`Sin stock suficiente para el producto: ${product.name}`);
                }
                const subtotal = item.quantity * Number(product.salePrice);
                totalOrderAmount += subtotal;
                const orderItem = new order_item_entity_1.OrderItem();
                orderItem.product = product;
                orderItem.productId = product.id;
                orderItem.quantity = item.quantity;
                orderItem.unitPrice = product.salePrice;
                orderItemsToSave.push(orderItem);
            }
            let order = new order_entity_1.Order();
            order.buyerId = buyer.id;
            order.sellerId = dto.sellerId;
            order.totalAmount = totalOrderAmount;
            order.status = 'requested';
            order.deliveryMessage = dto.deliveryMessage || null;
            order = await queryRunner.manager.save(order_entity_1.Order, order);
            for (const orderItem of orderItemsToSave) {
                orderItem.order = order;
                orderItem.orderId = order.id;
                await queryRunner.manager.save(order_item_entity_1.OrderItem, orderItem);
            }
            await queryRunner.commitTransaction();
            const finalOrder = await this.orderRepo.findOne({
                where: { id: order.id },
                relations: ['items', 'items.product', 'seller']
            });
            if (!finalOrder)
                throw new common_1.InternalServerErrorException('Error recuperando la orden guardada');
            return finalOrder;
        }
        catch (error) {
            await queryRunner.rollbackTransaction();
            console.error('Purchase Transaction Error:', error);
            if (error instanceof common_1.BadRequestException || error instanceof common_1.NotFoundException) {
                throw error;
            }
            throw new common_1.InternalServerErrorException('No se pudo procesar la compra.');
        }
        finally {
            await queryRunner.release();
        }
    }
    async acceptOrder(orderId, seller) {
        const order = await this.orderRepo.findOne({
            where: { id: orderId },
            relations: ['items', 'items.product']
        });
        if (!order)
            throw new common_1.NotFoundException('Orden no encontrada');
        if (order.sellerId !== seller.id)
            throw new common_1.BadRequestException('No tienes permiso para aceptar esta orden');
        if (order.status !== 'requested')
            throw new common_1.BadRequestException('La orden no está en estado solicitado');
        const queryRunner = this.dataSource.createQueryRunner();
        await queryRunner.connect();
        await queryRunner.startTransaction();
        try {
            order.status = 'accepted';
            await queryRunner.manager.save(order_entity_1.Order, order);
            await queryRunner.commitTransaction();
            return order;
        }
        catch (error) {
            await queryRunner.rollbackTransaction();
            if (error instanceof common_1.BadRequestException)
                throw error;
            throw new common_1.InternalServerErrorException('No se pudo aceptar la orden.');
        }
        finally {
            await queryRunner.release();
        }
    }
    async rejectOrder(orderId, seller) {
        const order = await this.orderRepo.findOne({ where: { id: orderId } });
        if (!order)
            throw new common_1.NotFoundException('Orden no encontrada');
        if (order.sellerId !== seller.id)
            throw new common_1.BadRequestException('No tienes permiso para rechazar esta orden');
        if (order.status !== 'requested')
            throw new common_1.BadRequestException('Solo puedes rechazar órdenes solicitadas');
        order.status = 'rejected';
        return this.orderRepo.save(order);
    }
    async deliverOrder(orderId, user) {
        const order = await this.orderRepo.findOne({
            where: { id: orderId },
            relations: ['items', 'items.product', 'seller', 'buyer']
        });
        if (!order) {
            throw new common_1.NotFoundException('Orden no encontrada');
        }
        if (order.status !== 'pending' && order.status !== 'accepted') {
            throw new common_1.BadRequestException('Esta orden ya fue procesada o cancelada');
        }
        if (order.buyerId !== user.id && order.sellerId !== user.id) {
            throw new common_1.BadRequestException('No tienes permiso para confirmar esta orden');
        }
        const queryRunner = this.dataSource.createQueryRunner();
        await queryRunner.connect();
        await queryRunner.startTransaction();
        try {
            for (const item of order.items) {
                await this.inventoryService.consumeFIFO(item.productId, order.sellerId, item.quantity, queryRunner.manager);
            }
            order.status = 'completed';
            await queryRunner.manager.save(order_entity_1.Order, order);
            const todayStr = new Date().toISOString().split('T')[0];
            let dailySale = await queryRunner.manager.findOne(daily_sale_entity_1.DailySale, {
                where: { sellerId: order.sellerId, saleDate: todayStr },
                relations: ['details']
            });
            if (!dailySale) {
                dailySale = new daily_sale_entity_1.DailySale();
                dailySale.sellerId = order.sellerId;
                dailySale.saleDate = todayStr;
                dailySale.totalInvestment = 0;
                dailySale.totalRevenue = 0;
                dailySale.unitsSold = 0;
                dailySale.unitsLost = 0;
                dailySale.details = [];
                dailySale = await queryRunner.manager.save(daily_sale_entity_1.DailySale, dailySale);
            }
            for (const orderItem of order.items) {
                let saleDetail = dailySale.details.find(d => d.productId === orderItem.productId);
                let isNewDetail = false;
                if (!saleDetail) {
                    saleDetail = new sale_detail_entity_1.SaleDetail();
                    saleDetail.dailySaleId = dailySale.id;
                    saleDetail.dailySale = dailySale;
                    saleDetail.productId = orderItem.productId;
                    saleDetail.quantityPrepared = 0;
                    saleDetail.quantitySold = 0;
                    saleDetail.quantityLost = 0;
                    saleDetail.unitCost = await this.getUnitCost(queryRunner, orderItem.productId);
                    saleDetail.unitPrice = orderItem.unitPrice;
                    isNewDetail = true;
                }
                saleDetail.quantitySold += orderItem.quantity;
                if (isNewDetail) {
                    dailySale.details.push(saleDetail);
                }
                else {
                    await queryRunner.manager.save(sale_detail_entity_1.SaleDetail, saleDetail);
                }
            }
            let totalRevenue = 0;
            let unitsSold = 0;
            let unitsLost = 0;
            let totalInvestment = 0;
            let totalWasteCost = 0;
            for (const d of dailySale.details) {
                totalRevenue += Number(d.unitPrice) * d.quantitySold;
                unitsSold += d.quantitySold;
                unitsLost += d.quantityLost;
                const investmentContrib = d.quantityPrepared > 0 ? d.quantityPrepared : d.quantitySold;
                totalInvestment += Number(d.unitCost) * investmentContrib;
                totalWasteCost += Number(d.wasteCost || 0);
            }
            dailySale.totalRevenue = totalRevenue;
            dailySale.totalInvestment = totalInvestment;
            dailySale.unitsSold = unitsSold;
            dailySale.unitsLost = unitsLost;
            dailySale.totalWasteCost = totalWasteCost;
            const profit = totalRevenue - totalInvestment;
            dailySale.profitMargin = totalRevenue > 0 ? (profit / totalRevenue) * 100 : 0;
            let breakEvenUnits = null;
            if (unitsSold > 0) {
                const avgSalePrice = totalRevenue / unitsSold;
                const unitsPrepared = unitsSold + unitsLost;
                const avgUnitCost = unitsPrepared > 0 ? totalInvestment / unitsPrepared : 0;
                const wasteRate = unitsPrepared > 0 ? unitsLost / unitsPrepared : 0;
                const effectiveUnitCost = avgUnitCost * (1 + wasteRate);
                const unitMargin = avgSalePrice - effectiveUnitCost;
                if (unitMargin > 0) {
                    breakEvenUnits = Number((totalInvestment / unitMargin).toFixed(2));
                }
            }
            dailySale.breakEvenUnits = breakEvenUnits;
            await queryRunner.manager.save(daily_sale_entity_1.DailySale, dailySale);
            await queryRunner.manager.update(daily_sale_entity_1.DailySale, dailySale.id, {
                totalRevenue: dailySale.totalRevenue,
                totalInvestment: dailySale.totalInvestment,
                unitsSold: dailySale.unitsSold,
                unitsLost: dailySale.unitsLost,
                totalWasteCost: dailySale.totalWasteCost,
                profitMargin: dailySale.profitMargin,
                breakEvenUnits: dailySale.breakEvenUnits
            });
            await queryRunner.commitTransaction();
            return order;
        }
        catch (error) {
            await queryRunner.rollbackTransaction();
            console.error('Delivery Transaction Error:', error);
            throw new common_1.InternalServerErrorException('Error al confirmar la recepción');
        }
        finally {
            await queryRunner.release();
        }
    }
    async getUnitCost(queryRunner, productId) {
        const prod = await queryRunner.manager.findOne(product_entity_1.Product, { where: { id: productId } });
        return prod ? Number(prod.unitCost) : 0;
    }
    async getBuyerPurchases(buyer, page = 1, limit = 20) {
        const where = buyer.role === 'admin' ? {} : { buyerId: buyer.id };
        const [data, total] = await this.orderRepo.findAndCount({
            where,
            relations: ['seller', 'items', 'items.product'],
            order: { createdAt: 'DESC' },
            skip: (page - 1) * limit,
            take: limit,
        });
        return { data, total, page, limit };
    }
    async getSellerSales(seller, page = 1, limit = 20) {
        const where = seller.role === 'admin' ? {} : { sellerId: seller.id };
        const [data, total] = await this.orderRepo.findAndCount({
            where,
            relations: ['buyer', 'items', 'items.product'],
            order: { createdAt: 'DESC' },
            skip: (page - 1) * limit,
            take: limit,
        });
        return { data, total, page, limit };
    }
};
exports.OrdersService = OrdersService;
exports.OrdersService = OrdersService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(order_entity_1.Order)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.DataSource,
        inventory_service_1.InventoryService])
], OrdersService);
//# sourceMappingURL=orders.service.js.map