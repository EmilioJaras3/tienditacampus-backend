export declare const configuration: () => {
    nodeEnv: string;
    port: number;
    database: {
        url: string | undefined;
        host: string;
        port: number;
        name: string;
        user: string | undefined;
        password: string | undefined;
    };
    jwt: {
        secret: string | undefined;
        expiration: string;
    };
    argon2: {
        memoryCost: number;
        timeCost: number;
        parallelism: number;
    };
    security: {
        maxFailedLoginAttempts: number;
        lockoutDurationMinutes: number;
    };
};
