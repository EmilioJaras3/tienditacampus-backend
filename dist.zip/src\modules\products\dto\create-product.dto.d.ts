export declare class CreateProductDto {
    name: string;
    description?: string;
    unitCost: number;
    salePrice: number;
    isPerishable?: boolean;
    shelfLifeDays?: number;
    imageUrl?: string;
    categoryId: string;
    subcategory?: string;
}
