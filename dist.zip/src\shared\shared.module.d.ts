export declare class SharedModule {
}
