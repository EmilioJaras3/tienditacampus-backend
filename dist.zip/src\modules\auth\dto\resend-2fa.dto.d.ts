export declare class ResendTwoFactorDto {
    email: string;
}
