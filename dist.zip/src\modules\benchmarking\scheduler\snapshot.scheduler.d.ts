import { SnapshotService } from '../snapshots/snapshot.service';
import { ConfigService } from '@nestjs/config';
export declare class SnapshotScheduler {
    private snapshotService;
    private configService;
    private readonly logger;
    constructor(snapshotService: SnapshotService, configService: ConfigService);
    handleDailySnapshot(): Promise<void>;
    handlePeriodicSnapshot(): Promise<void>;
}
