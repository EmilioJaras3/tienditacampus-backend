export declare class TwoFactorModule {
}
