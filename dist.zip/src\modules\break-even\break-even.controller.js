"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BreakEvenController = void 0;
const common_1 = require("@nestjs/common");
const jwt_auth_guard_1 = require("../../common/guards/jwt-auth.guard");
const roles_guard_1 = require("../../common/guards/roles.guard");
const roles_decorator_1 = require("../../common/decorators/roles.decorator");
const break_even_service_1 = require("./break-even.service");
const calculate_break_even_dto_1 = require("./dto/calculate-break-even.dto");
let BreakEvenController = class BreakEvenController {
    constructor(breakEvenService) {
        this.breakEvenService = breakEvenService;
    }
    calculate(dto, req) {
        return this.breakEvenService.calculate(dto, req.user);
    }
};
exports.BreakEvenController = BreakEvenController;
__decorate([
    (0, common_1.Post)('calculate'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [calculate_break_even_dto_1.CalculateBreakEvenDto, Object]),
    __metadata("design:returntype", void 0)
], BreakEvenController.prototype, "calculate", null);
exports.BreakEvenController = BreakEvenController = __decorate([
    (0, common_1.Controller)('break-even'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, roles_guard_1.RolesGuard),
    (0, roles_decorator_1.Roles)('seller', 'admin'),
    __metadata("design:paramtypes", [break_even_service_1.BreakEvenService])
], BreakEvenController);
//# sourceMappingURL=break-even.controller.js.map