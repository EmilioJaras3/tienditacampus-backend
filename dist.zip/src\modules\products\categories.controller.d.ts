import { ProductsService } from './products.service';
export declare class CategoriesController {
    private readonly productsService;
    constructor(productsService: ProductsService);
    findAll(): Promise<import("./entities/category.entity").Category[]>;
}
