import { JwtService } from '@nestjs/jwt';
import { UsersService } from '../../users/users.service';
import { AuditService } from '../../audit/audit.service';
import { GoogleLoginDto } from '../dto/google-login.dto';
export declare class GoogleLoginUseCase {
    private readonly usersService;
    private readonly jwtService;
    private readonly auditService;
    constructor(usersService: UsersService, jwtService: JwtService, auditService: AuditService);
    execute(dto: GoogleLoginDto): Promise<{
        user: import("../../users/entities/user.entity").User;
        accessToken: string;
    }>;
}
