"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SalesModule = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const sales_service_1 = require("./sales.service");
const sales_controller_1 = require("./sales.controller");
const daily_sale_entity_1 = require("./entities/daily-sale.entity");
const sale_detail_entity_1 = require("./entities/sale-detail.entity");
const product_entity_1 = require("../products/entities/product.entity");
const inventory_record_entity_1 = require("../inventory/entities/inventory-record.entity");
const inventory_module_1 = require("../inventory/inventory.module");
const audit_module_1 = require("../audit/audit.module");
const sales_repository_1 = require("./repositories/sales.repository");
const create_daily_sale_use_case_1 = require("./use-cases/create-daily-sale.use-case");
const close_day_use_case_1 = require("./use-cases/close-day.use-case");
const track_sale_use_case_1 = require("./use-cases/track-sale.use-case");
let SalesModule = class SalesModule {
};
exports.SalesModule = SalesModule;
exports.SalesModule = SalesModule = __decorate([
    (0, common_1.Module)({
        imports: [
            typeorm_1.TypeOrmModule.forFeature([daily_sale_entity_1.DailySale, sale_detail_entity_1.SaleDetail, product_entity_1.Product, inventory_record_entity_1.InventoryRecord]),
            inventory_module_1.InventoryModule,
            audit_module_1.AuditModule
        ],
        controllers: [sales_controller_1.SalesController],
        providers: [
            sales_service_1.SalesService,
            sales_repository_1.SalesRepository,
            {
                provide: 'ISalesRepository',
                useClass: sales_repository_1.SalesRepository,
            },
            create_daily_sale_use_case_1.CreateDailySaleUseCase,
            close_day_use_case_1.CloseDayUseCase,
            track_sale_use_case_1.TrackSaleUseCase
        ],
        exports: [sales_service_1.SalesService],
    })
], SalesModule);
//# sourceMappingURL=sales.module.js.map