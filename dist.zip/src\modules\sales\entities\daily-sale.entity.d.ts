import { User } from '../../users/entities/user.entity';
import { SaleDetail } from './sale-detail.entity';
export declare class DailySale {
    id: string;
    sellerId: string;
    seller: User;
    saleDate: string;
    totalInvestment: number;
    totalRevenue: number;
    totalProfit: string;
    profitMargin: number;
    unitsSold: number;
    unitsLost: number;
    breakEvenUnits: number | null;
    totalWasteCost: number;
    isClosed: boolean;
    notes: string;
    details: SaleDetail[];
    createdAt: Date;
    updatedAt: Date;
}
