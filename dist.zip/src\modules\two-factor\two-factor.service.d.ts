import { Repository } from 'typeorm';
import { TwoFactorCode } from './entities/two-factor-code.entity';
export declare class TwoFactorService {
    private readonly twoFactorRepo;
    private readonly logger;
    constructor(twoFactorRepo: Repository<TwoFactorCode>);
    generateCode(userId: string): Promise<string>;
    verifyCode(userId: string, plainCode: string): Promise<boolean>;
    cleanExpiredCodes(): Promise<void>;
}
