export declare const ROLES_KEY = "roles";
export declare const Roles: (...roles: ("admin" | "seller" | "buyer")[]) => import("@nestjs/common").CustomDecorator<string>;
