"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateDailySaleUseCase = void 0;
const common_1 = require("@nestjs/common");
const daily_sale_entity_1 = require("../entities/daily-sale.entity");
const sale_detail_entity_1 = require("../entities/sale-detail.entity");
const sales_repository_1 = require("../repositories/sales.repository");
let CreateDailySaleUseCase = class CreateDailySaleUseCase {
    constructor(salesRepository) {
        this.salesRepository = salesRepository;
    }
    async execute(prepareDto, user) {
        const existing = await this.salesRepository.findToday(user.id);
        if (existing) {
            throw new common_1.BadRequestException('Daily sale already initialized for today. Use update methods instead.');
        }
        let totalInvestment = 0;
        const details = [];
        for (const item of prepareDto.items) {
            const product = await this.salesRepository.findProduct(item.productId);
            if (!product)
                throw new common_1.BadRequestException(`Product ${item.productId} not found`);
            const detail = new sale_detail_entity_1.SaleDetail();
            detail.product = product;
            detail.productId = product.id;
            detail.quantityPrepared = item.quantityPrepared;
            detail.unitCost = product.unitCost;
            detail.unitPrice = product.salePrice;
            totalInvestment += Number(product.unitCost) * item.quantityPrepared;
            details.push(detail);
        }
        const dailySale = new daily_sale_entity_1.DailySale();
        dailySale.seller = user;
        dailySale.sellerId = user.id;
        dailySale.totalInvestment = totalInvestment;
        dailySale.saleDate = new Date().toISOString().split('T')[0];
        return await this.salesRepository.createDailySale(dailySale, details);
    }
};
exports.CreateDailySaleUseCase = CreateDailySaleUseCase;
exports.CreateDailySaleUseCase = CreateDailySaleUseCase = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [sales_repository_1.SalesRepository])
], CreateDailySaleUseCase);
//# sourceMappingURL=create-daily-sale.use-case.js.map