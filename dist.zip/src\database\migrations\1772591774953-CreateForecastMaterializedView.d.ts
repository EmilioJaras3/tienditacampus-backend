import { MigrationInterface, QueryRunner } from "typeorm";
export declare class CreateForecastMaterializedView1772591774953 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
