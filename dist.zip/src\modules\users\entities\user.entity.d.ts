export declare class User {
    id: string;
    email: string;
    passwordHash: string;
    firstName: string;
    lastName: string;
    phone: string | null;
    avatarUrl: string | null;
    major: string | null;
    campusLocation: string | null;
    role: 'admin' | 'seller' | 'buyer';
    isActive: boolean;
    isEmailVerified: boolean;
    lastLoginAt: Date | null;
    loginCount: number;
    failedLoginAttempts: number;
    lockedUntil: Date | null;
    passwordChangedAt: Date | null;
    createdAt: Date;
    updatedAt: Date;
    twoFactorCode: string | null;
    twoFactorExpires: Date | null;
    get isLocked(): boolean;
}
