"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var AdminSeedService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.AdminSeedService = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const typeorm_1 = require("@nestjs/typeorm");
const argon2_1 = require("@node-rs/argon2");
const typeorm_2 = require("typeorm");
const user_entity_1 = require("./entities/user.entity");
let AdminSeedService = AdminSeedService_1 = class AdminSeedService {
    constructor(configService, usersRepository) {
        this.configService = configService;
        this.usersRepository = usersRepository;
        this.logger = new common_1.Logger(AdminSeedService_1.name);
    }
    async onApplicationBootstrap() {
        const emailRaw = this.configService.get('DEFAULT_ADMIN_EMAIL');
        const password = this.configService.get('DEFAULT_ADMIN_PASSWORD');
        if (!emailRaw || !password) {
            this.logger.warn('DEFAULT_ADMIN_EMAIL or DEFAULT_ADMIN_PASSWORD not set. Skipping seed.');
            return;
        }
        const email = emailRaw.toLowerCase();
        const existing = await this.usersRepository.findOne({ where: { email } });
        if (!existing) {
            const memoryCost = this.configService.get('ARGON2_MEMORY_COST', 65536);
            const timeCost = this.configService.get('ARGON2_TIME_COST', 3);
            const parallelism = this.configService.get('ARGON2_PARALLELISM', 4);
            const passwordHash = await (0, argon2_1.hash)(password, {
                memoryCost,
                timeCost,
                parallelism,
            });
            const user = this.usersRepository.create({
                email,
                passwordHash,
                firstName: 'Admin',
                lastName: 'User',
                phone: null,
                major: null,
                campusLocation: null,
                role: 'admin',
                isEmailVerified: true,
                isActive: true,
            });
            await this.usersRepository.save(user);
            this.logger.log(`Default admin user created: ${email}`);
            return;
        }
        let needsUpdate = false;
        if (existing.role !== 'admin') {
            existing.role = 'admin';
            needsUpdate = true;
        }
        if (!existing.isEmailVerified) {
            existing.isEmailVerified = true;
            needsUpdate = true;
        }
        if (!existing.isActive) {
            existing.isActive = true;
            needsUpdate = true;
        }
        if (needsUpdate) {
            await this.usersRepository.save(existing);
            this.logger.log(`Default admin user updated: ${email}`);
        }
    }
};
exports.AdminSeedService = AdminSeedService;
exports.AdminSeedService = AdminSeedService = AdminSeedService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(1, (0, typeorm_1.InjectRepository)(user_entity_1.User)),
    __metadata("design:paramtypes", [config_1.ConfigService,
        typeorm_2.Repository])
], AdminSeedService);
//# sourceMappingURL=admin-seed.service.js.map