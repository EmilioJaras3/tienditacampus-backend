"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OrdersModule = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const orders_controller_1 = require("./orders.controller");
const orders_service_1 = require("./orders.service");
const order_entity_1 = require("./entities/order.entity");
const order_item_entity_1 = require("./entities/order-item.entity");
const daily_sale_entity_1 = require("../sales/entities/daily-sale.entity");
const sale_detail_entity_1 = require("../sales/entities/sale-detail.entity");
const inventory_record_entity_1 = require("../inventory/entities/inventory-record.entity");
const product_entity_1 = require("../products/entities/product.entity");
const inventory_module_1 = require("../inventory/inventory.module");
const create_order_use_case_1 = require("./use-cases/create-order.use-case");
const deliver_order_use_case_1 = require("./use-cases/deliver-order.use-case");
let OrdersModule = class OrdersModule {
};
exports.OrdersModule = OrdersModule;
exports.OrdersModule = OrdersModule = __decorate([
    (0, common_1.Module)({
        imports: [
            typeorm_1.TypeOrmModule.forFeature([
                order_entity_1.Order,
                order_item_entity_1.OrderItem,
                product_entity_1.Product,
                inventory_record_entity_1.InventoryRecord,
                daily_sale_entity_1.DailySale,
                sale_detail_entity_1.SaleDetail,
            ]),
            inventory_module_1.InventoryModule,
        ],
        controllers: [orders_controller_1.OrdersController],
        providers: [
            orders_service_1.OrdersService,
            create_order_use_case_1.CreateOrderUseCase,
            deliver_order_use_case_1.DeliverOrderUseCase,
        ],
        exports: [orders_service_1.OrdersService],
    })
], OrdersModule);
//# sourceMappingURL=orders.module.js.map