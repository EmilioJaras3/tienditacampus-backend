import { SalesRepository } from '../repositories/sales.repository';
import { TrackSaleDto } from '../dto/track-sale.dto';
import { User } from '../../users/entities/user.entity';
export declare class TrackSaleUseCase {
    private readonly salesRepository;
    constructor(salesRepository: SalesRepository);
    execute(trackDto: TrackSaleDto, user: User): Promise<any>;
    private recalculateHeader;
}
