"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TrackSaleUseCase = void 0;
const common_1 = require("@nestjs/common");
const sales_repository_1 = require("../repositories/sales.repository");
let TrackSaleUseCase = class TrackSaleUseCase {
    constructor(salesRepository) {
        this.salesRepository = salesRepository;
    }
    async execute(trackDto, user) {
        const dailySale = await this.salesRepository.findToday(user.id);
        if (!dailySale) {
            throw new common_1.NotFoundException('No active daily sale found for today. Please initialize the day first.');
        }
        const detail = dailySale.details.find(d => d.productId === trackDto.productId);
        if (!detail) {
            throw new common_1.NotFoundException('Product not found in today\'s records');
        }
        if (detail.quantityPrepared < (trackDto.quantitySold + trackDto.quantityLost)) {
            throw new common_1.BadRequestException('Cannot sell/lose more than prepared quantity');
        }
        detail.quantitySold = trackDto.quantitySold;
        detail.quantityLost = trackDto.quantityLost;
        await this.salesRepository.saveSaleDetail(detail);
        return await this.recalculateHeader(dailySale.id);
    }
    async recalculateHeader(dailySaleId) {
        const sale = await this.salesRepository.findSaleWithDetails(dailySaleId);
        if (!sale)
            throw new common_1.NotFoundException('Sale not found');
        let totalRevenue = 0;
        let unitsSold = 0;
        let unitsLost = 0;
        let totalWasteCost = 0;
        for (const detail of sale.details) {
            totalRevenue += Number(detail.unitPrice) * detail.quantitySold;
            unitsSold += detail.quantitySold;
            unitsLost += detail.quantityLost;
            totalWasteCost += Number(detail.wasteCost || 0);
        }
        sale.totalRevenue = totalRevenue;
        sale.unitsSold = unitsSold;
        sale.unitsLost = unitsLost;
        sale.totalWasteCost = totalWasteCost;
        const profit = totalRevenue - Number(sale.totalInvestment);
        sale.profitMargin = totalRevenue > 0 ? (profit / totalRevenue) * 100 : 0;
        if (sale.unitsSold > 0) {
            const avgSalePrice = totalRevenue / sale.unitsSold;
            const unitsPrepared = sale.unitsSold + sale.unitsLost;
            const avgUnitCost = unitsPrepared > 0 ? Number(sale.totalInvestment) / unitsPrepared : 0;
            const wasteRate = unitsPrepared > 0 ? sale.unitsLost / unitsPrepared : 0;
            const effectiveUnitCost = avgUnitCost * (1 + wasteRate);
            const unitMargin = avgSalePrice - effectiveUnitCost;
            if (unitMargin > 0) {
                sale.breakEvenUnits = Number((Number(sale.totalInvestment) / unitMargin).toFixed(2));
            }
            else {
                sale.breakEvenUnits = null;
            }
        }
        else {
            sale.breakEvenUnits = null;
        }
        await this.salesRepository.updateSale(sale.id, {
            totalRevenue: sale.totalRevenue,
            unitsSold: sale.unitsSold,
            unitsLost: sale.unitsLost,
            totalWasteCost: sale.totalWasteCost,
            profitMargin: sale.profitMargin,
            breakEvenUnits: sale.breakEvenUnits
        });
        return sale;
    }
};
exports.TrackSaleUseCase = TrackSaleUseCase;
exports.TrackSaleUseCase = TrackSaleUseCase = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [sales_repository_1.SalesRepository])
], TrackSaleUseCase);
//# sourceMappingURL=track-sale.use-case.js.map