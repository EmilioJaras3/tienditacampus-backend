"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UsersService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const config_1 = require("@nestjs/config");
const argon2_1 = require("@node-rs/argon2");
const user_entity_1 = require("./entities/user.entity");
const product_entity_1 = require("../products/entities/product.entity");
let UsersService = class UsersService {
    constructor(usersRepository, productRepository, configService) {
        this.usersRepository = usersRepository;
        this.productRepository = productRepository;
        this.configService = configService;
    }
    async findByEmail(email) {
        return this.usersRepository.findOne({
            where: { email: email.toLowerCase(), isActive: true },
        });
    }
    async findById(id) {
        return this.usersRepository.findOne({
            where: { id, isActive: true },
        });
    }
    async getPublicProfile(id) {
        const user = await this.usersRepository.findOne({
            where: { id, isActive: true },
            select: ['id', 'firstName', 'lastName', 'email', 'avatarUrl', 'createdAt', 'role']
        });
        if (!user) {
            throw new common_1.NotFoundException('Vendedor no encontrado');
        }
        const products = await this.productRepository.createQueryBuilder('product')
            .where('product.seller_id = :sellerId', { sellerId: id })
            .andWhere('product.isActive = :isActive', { isActive: true })
            .andWhere(`EXISTS (
                SELECT 1 FROM inventory_records inventory 
                WHERE inventory.product_id = product.id 
                AND inventory.quantity_remaining > 0 
                AND inventory.status = 'active'
            )`)
            .getMany();
        return {
            ...user,
            products,
        };
    }
    async create(dto) {
        const existing = await this.usersRepository.findOne({
            where: { email: dto.email.toLowerCase() },
        });
        if (existing) {
            throw new common_1.ConflictException('El email ya está registrado');
        }
        const memoryCost = this.configService.get('ARGON2_MEMORY_COST', 65536);
        const timeCost = this.configService.get('ARGON2_TIME_COST', 3);
        const parallelism = this.configService.get('ARGON2_PARALLELISM', 4);
        const passwordHash = await (0, argon2_1.hash)(dto.password, {
            memoryCost,
            timeCost,
            parallelism,
        });
        const user = this.usersRepository.create({
            email: dto.email.toLowerCase(),
            passwordHash,
            firstName: dto.firstName,
            lastName: dto.lastName,
            phone: dto.phone ?? null,
            major: dto.major ?? null,
            campusLocation: dto.campusLocation ?? null,
            ...(dto.role ? { role: dto.role } : {}),
        });
        return this.usersRepository.save(user);
    }
    async update(id, dto) {
        const user = await this.findById(id);
        if (!user) {
            throw new common_1.NotFoundException('Usuario no encontrado');
        }
        Object.assign(user, dto);
        return this.usersRepository.save(user);
    }
    async recordSuccessfulLogin(id) {
        await this.usersRepository.update(id, {
            lastLoginAt: new Date(),
            loginCount: () => 'login_count + 1',
            failedLoginAttempts: 0,
            lockedUntil: null,
        });
    }
    async recordFailedLogin(id) {
        const user = await this.findById(id);
        if (!user)
            return;
        const newAttempts = user.failedLoginAttempts + 1;
        const maxAttempts = this.configService.get('MAX_FAILED_LOGIN_ATTEMPTS', 5);
        const updateData = {
            failedLoginAttempts: newAttempts,
        };
        if (newAttempts >= maxAttempts) {
            const lockoutMinutes = this.configService.get('LOCKOUT_DURATION_MINUTES', 15);
            updateData.lockedUntil = new Date(Date.now() + lockoutMinutes * 60 * 1000);
        }
        await this.usersRepository.update(id, updateData);
    }
    async updateRole(id, role) {
        await this.usersRepository.update(id, { role });
    }
    async updatePasswordChangedAt(id) {
        await this.usersRepository.update(id, {
            passwordChangedAt: new Date(),
        });
    }
    async updateEmailVerified(id, isVerified) {
        await this.usersRepository.update(id, { isEmailVerified: isVerified });
    }
};
exports.UsersService = UsersService;
exports.UsersService = UsersService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(user_entity_1.User)),
    __param(1, (0, typeorm_1.InjectRepository)(product_entity_1.Product)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository,
        config_1.ConfigService])
], UsersService);
//# sourceMappingURL=users.service.js.map