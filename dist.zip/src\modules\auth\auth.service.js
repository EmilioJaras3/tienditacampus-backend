"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthService = void 0;
const common_1 = require("@nestjs/common");
const jwt_1 = require("@nestjs/jwt");
const argon2_1 = require("@node-rs/argon2");
const users_service_1 = require("../users/users.service");
const audit_service_1 = require("../audit/audit.service");
const mailer_service_1 = require("../mailer/mailer.service");
const two_factor_service_1 = require("../two-factor/two-factor.service");
let AuthService = class AuthService {
    constructor(usersService, jwtService, auditService, mailerService, twoFactorService) {
        this.usersService = usersService;
        this.jwtService = jwtService;
        this.auditService = auditService;
        this.mailerService = mailerService;
        this.twoFactorService = twoFactorService;
    }
    async register(dto) {
        const user = await this.usersService.create({
            email: dto.email,
            password: dto.password,
            firstName: dto.firstName,
            lastName: dto.lastName,
            phone: dto.phone,
            role: dto.role,
        });
        const payload = { sub: user.id, email: user.email, role: user.role };
        const accessToken = this.jwtService.sign(payload);
        await this.auditService.log({
            action: 'user.register',
            entityType: 'user',
            entityId: user.id,
            userId: user.id,
            description: `Nuevo usuario registrado: ${user.email}`,
            metadata: {
                email: user.email,
                role: user.role,
                registeredAt: new Date().toISOString(),
            },
        });
        return {
            user: {
                id: user.id,
                email: user.email,
                firstName: user.firstName,
                lastName: user.lastName,
                role: user.role,
            },
            accessToken,
        };
    }
    async login(dto) {
        const user = await this.usersService.findByEmail(dto.email.toLowerCase());
        if (!user) {
            throw new common_1.UnauthorizedException('Credenciales inválidas');
        }
        if (user.isLocked && user.lockedUntil) {
            const remainingMinutes = Math.ceil((user.lockedUntil.getTime() - Date.now()) / 60000);
            throw new common_1.ForbiddenException(`Cuenta bloqueada temporalmente. Intenta de nuevo en ${remainingMinutes} minuto(s).`);
        }
        const isPasswordValid = await (0, argon2_1.verify)(user.passwordHash, dto.password);
        if (!isPasswordValid) {
            await this.usersService.recordFailedLogin(user.id);
            await this.auditService.log({
                action: 'user.login_failed',
                entityType: 'user',
                entityId: user.id,
                userId: user.id,
                level: 'warn',
                description: `Intento de login fallido para ${dto.email}`,
                metadata: {
                    email: dto.email,
                    failedAttempts: user.failedLoginAttempts + 1,
                    timestamp: new Date().toISOString(),
                },
            });
            throw new common_1.UnauthorizedException('Credenciales inválidas');
        }
        const twoFactorCode = await this.twoFactorService.generateCode(user.id);
        await this.mailerService.send2faCode(user.email, twoFactorCode);
        return {
            requiresTwoFactor: true,
            message: 'Código de verificación enviado a tu correo electrónico',
        };
    }
    async verify2fa(dto) {
        const user = await this.usersService.findByEmail(dto.email.toLowerCase());
        if (!user) {
            throw new common_1.UnauthorizedException('Código o usuario inválido');
        }
        const isCodeValid = await this.twoFactorService.verifyCode(user.id, dto.code);
        if (!isCodeValid) {
            throw new common_1.UnauthorizedException('Código inválido o expirado');
        }
        await this.usersService.recordSuccessfulLogin(user.id);
        const payload = { sub: user.id, email: user.email, role: user.role };
        const accessToken = this.jwtService.sign(payload);
        await this.auditService.log({
            action: 'user.login_2fa',
            entityType: 'user',
            entityId: user.id,
            userId: user.id,
            description: `Login 2FA exitoso: ${user.email}`,
            metadata: {
                email: user.email,
                role: user.role,
                loginCount: user.loginCount + 1,
                lastLoginAt: new Date().toISOString(),
            },
        });
        return {
            user: {
                id: user.id,
                email: user.email,
                firstName: user.firstName,
                lastName: user.lastName,
                role: user.role,
                lastLoginAt: new Date().toISOString(),
                loginCount: user.loginCount + 1,
            },
            accessToken,
        };
    }
    async resend2fa(dto) {
        const user = await this.usersService.findByEmail(dto.email.toLowerCase());
        if (!user) {
            throw new common_1.NotFoundException('Usuario no encontrado');
        }
        const twoFactorCode = await this.twoFactorService.generateCode(user.id);
        await this.mailerService.send2faCode(user.email, twoFactorCode);
        return {
            message: 'Nuevo código de verificación enviado a tu correo',
        };
    }
    async loginWithGoogle(dto) {
        try {
            const response = await fetch('https://www.googleapis.com/oauth2/v3/userinfo', {
                headers: { Authorization: `Bearer ${dto.token}` }
            });
            if (!response.ok) {
                throw new common_1.UnauthorizedException('Token de Google inválido o expirado');
            }
            const data = await response.json();
            const email = data.email.toLowerCase();
            let user = await this.usersService.findByEmail(email);
            const adminEmails = (process.env.ADMIN_EMAILS || 'jarassanchezl@gmail.com,jarassabchezl@gmail.com').toLowerCase().split(',');
            const assignedRole = adminEmails.includes(email) ? 'admin' : 'buyer';
            if (!user) {
                const randomPassword = `Gg#${Math.random().toString(36).slice(-8)}A1!x`;
                await this.usersService.create({
                    email: email,
                    password: randomPassword,
                    firstName: data.given_name || 'Usuario',
                    lastName: data.family_name || 'Google',
                    role: assignedRole
                });
                user = await this.usersService.findByEmail(email);
            }
            else if (user.role !== assignedRole && assignedRole === 'admin') {
                await this.usersService.updateRole(user.id, 'admin');
                user.role = 'admin';
            }
            if (!user) {
                throw new Error('Fallo crítico al auto-registrar usuario con Google SSO');
            }
            await this.usersService.recordSuccessfulLogin(user.id);
            const payload = { sub: user.id, email: user.email, role: user.role };
            const accessToken = this.jwtService.sign(payload);
            await this.auditService.log({
                action: 'user.login_google',
                entityType: 'user',
                entityId: user.id,
                userId: user.id,
                description: `Login SSO exitoso (Google): ${user.email}`,
                metadata: {
                    email: user.email,
                    role: user.role,
                    provider: 'google',
                    timestamp: new Date().toISOString(),
                },
            });
            return {
                user: {
                    id: user.id,
                    email: user.email,
                    firstName: user.firstName,
                    lastName: user.lastName,
                    role: user.role,
                    lastLoginAt: new Date().toISOString(),
                    loginCount: user.loginCount + 1,
                },
                accessToken,
            };
        }
        catch (error) {
            console.error('SSO Google Error:', error);
            if (error instanceof common_1.UnauthorizedException)
                throw error;
            throw new common_1.UnauthorizedException('Fallo al validar credenciales con servidor de Google');
        }
    }
    async getProfile(userId) {
        const user = await this.usersService.findById(userId);
        if (!user) {
            throw new common_1.UnauthorizedException('Usuario no encontrado');
        }
        return {
            id: user.id,
            email: user.email,
            firstName: user.firstName,
            lastName: user.lastName,
            phone: user.phone,
            avatarUrl: user.avatarUrl,
            role: user.role,
            isEmailVerified: user.isEmailVerified,
            lastLoginAt: user.lastLoginAt,
            loginCount: user.loginCount,
            createdAt: user.createdAt,
        };
    }
    async rescueAdmin(email, secret) {
        const RESCUE_SECRET = 'TC-ADMIN-RESCUE-2024';
        if (secret !== RESCUE_SECRET) {
            throw new common_1.ForbiddenException('Clave de rescate inválida');
        }
        const user = await this.usersService.findByEmail(email.toLowerCase());
        if (!user) {
            throw new common_1.NotFoundException('Usuario no encontrado');
        }
        await this.usersService.recordSuccessfulLogin(user.id);
        if (user.role === 'admin') {
            await this.usersService.updateEmailVerified(user.id, true);
        }
        await this.auditService.log({
            action: 'user.rescue',
            entityType: 'user',
            entityId: user.id,
            userId: user.id,
            description: `RESCATE ADMINISTRATIVO ejecutado para: ${user.email}`,
            metadata: {
                email: user.email,
                timestamp: new Date().toISOString(),
            },
        });
        return {
            message: `Cuenta ${user.email} desbloqueada exitosamente. Por favor, intenta iniciar sesión.`,
        };
    }
    async verifyEmail(email, code) {
        const user = await this.usersService.findByEmail(email.toLowerCase());
        if (!user)
            throw new common_1.NotFoundException('Usuario no encontrado');
        const isValid = await this.twoFactorService.verifyCode(user.id, code);
        if (!isValid)
            throw new common_1.UnauthorizedException('Código de verificación inválido o expirado');
        await this.usersService.updateEmailVerified(user.id, true);
        return { message: 'Email verificado exitosamente' };
    }
};
exports.AuthService = AuthService;
exports.AuthService = AuthService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [users_service_1.UsersService,
        jwt_1.JwtService,
        audit_service_1.AuditService,
        mailer_service_1.MailerService,
        two_factor_service_1.TwoFactorService])
], AuthService);
//# sourceMappingURL=auth.service.js.map