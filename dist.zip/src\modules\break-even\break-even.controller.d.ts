import { BreakEvenService } from './break-even.service';
import { CalculateBreakEvenDto } from './dto/calculate-break-even.dto';
export declare class BreakEvenController {
    private readonly breakEvenService;
    constructor(breakEvenService: BreakEvenService);
    calculate(dto: CalculateBreakEvenDto, req: any): Promise<{
        productId: string;
        productName: string;
        fixedCosts: string;
        unitCost: string;
        effectiveUnitCost: string;
        unitPrice: string;
        unitMargin: string;
        wasteRate: number;
        wasteRateSample: {
            totalLost: number;
            totalHandled: number;
            periodDays: number;
        };
        breakEvenUnits: number;
        formula: string;
    }>;
}
