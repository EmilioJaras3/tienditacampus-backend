export declare class CreateUserDto {
    email: string;
    password: string;
    firstName: string;
    lastName: string;
    phone?: string;
    major?: string;
    campusLocation?: string;
    role?: 'seller' | 'buyer';
}
