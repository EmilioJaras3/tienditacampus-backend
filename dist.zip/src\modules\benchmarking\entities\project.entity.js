"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Project = exports.DbEngine = exports.ProjectType = void 0;
const typeorm_1 = require("typeorm");
const query_entity_1 = require("./query.entity");
const execution_entity_1 = require("./execution.entity");
var ProjectType;
(function (ProjectType) {
    ProjectType["ECOMMERCE"] = "ECOMMERCE";
    ProjectType["SOCIAL"] = "SOCIAL";
    ProjectType["FINANCIAL"] = "FINANCIAL";
    ProjectType["HEALTHCARE"] = "HEALTHCARE";
    ProjectType["IOT"] = "IOT";
    ProjectType["EDUCATION"] = "EDUCATION";
    ProjectType["CONTENT"] = "CONTENT";
    ProjectType["ENTERPRISE"] = "ENTERPRISE";
    ProjectType["LOGISTICS"] = "LOGISTICS";
    ProjectType["GOVERNMENT"] = "GOVERNMENT";
})(ProjectType || (exports.ProjectType = ProjectType = {}));
var DbEngine;
(function (DbEngine) {
    DbEngine["POSTGRESQL"] = "POSTGRESQL";
    DbEngine["MYSQL"] = "MYSQL";
    DbEngine["MONGODB"] = "MONGODB";
    DbEngine["OTHER"] = "OTHER";
})(DbEngine || (exports.DbEngine = DbEngine = {}));
let Project = class Project {
};
exports.Project = Project;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)(),
    __metadata("design:type", Number)
], Project.prototype, "project_id", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'varchar',
        length: 20,
    }),
    __metadata("design:type", String)
], Project.prototype, "project_type", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', nullable: true }),
    __metadata("design:type", String)
], Project.prototype, "description", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'varchar',
        length: 20,
    }),
    __metadata("design:type", String)
], Project.prototype, "db_engine", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => query_entity_1.Query, (query) => query.project),
    __metadata("design:type", Array)
], Project.prototype, "queries", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => execution_entity_1.Execution, (execution) => execution.project),
    __metadata("design:type", Array)
], Project.prototype, "executions", void 0);
exports.Project = Project = __decorate([
    (0, typeorm_1.Entity)('projects')
], Project);
//# sourceMappingURL=project.entity.js.map