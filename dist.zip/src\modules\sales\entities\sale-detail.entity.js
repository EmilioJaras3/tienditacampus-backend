"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SaleDetail = void 0;
const typeorm_1 = require("typeorm");
const daily_sale_entity_1 = require("./daily-sale.entity");
const product_entity_1 = require("../../products/entities/product.entity");
let SaleDetail = class SaleDetail {
};
exports.SaleDetail = SaleDetail;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('uuid'),
    __metadata("design:type", String)
], SaleDetail.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'daily_sale_id' }),
    __metadata("design:type", String)
], SaleDetail.prototype, "dailySaleId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => daily_sale_entity_1.DailySale, (dailySale) => dailySale.details, { onDelete: 'CASCADE' }),
    (0, typeorm_1.JoinColumn)({ name: 'daily_sale_id' }),
    __metadata("design:type", daily_sale_entity_1.DailySale)
], SaleDetail.prototype, "dailySale", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'product_id' }),
    __metadata("design:type", String)
], SaleDetail.prototype, "productId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => product_entity_1.Product),
    (0, typeorm_1.JoinColumn)({ name: 'product_id' }),
    __metadata("design:type", product_entity_1.Product)
], SaleDetail.prototype, "product", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', name: 'quantity_prepared' }),
    __metadata("design:type", Number)
], SaleDetail.prototype, "quantityPrepared", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0, name: 'quantity_sold' }),
    __metadata("design:type", Number)
], SaleDetail.prototype, "quantitySold", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0, name: 'quantity_lost' }),
    __metadata("design:type", Number)
], SaleDetail.prototype, "quantityLost", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'enum',
        enumName: 'waste_reason_type',
        enum: ['expired', 'damaged', 'other'],
        nullable: true,
        name: 'waste_reason',
        comment: 'Causalidad de la merma: vencimiento, daño físico u otro',
    }),
    __metadata("design:type", Object)
], SaleDetail.prototype, "wasteReason", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'decimal',
        precision: 10,
        scale: 2,
        default: 0,
        name: 'waste_cost',
        comment: 'Costo económico real de la merma (quantity_lost * unit_cost)',
    }),
    __metadata("design:type", Number)
], SaleDetail.prototype, "wasteCost", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 10, scale: 2, name: 'unit_cost' }),
    __metadata("design:type", Number)
], SaleDetail.prototype, "unitCost", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 10, scale: 2, name: 'unit_price' }),
    __metadata("design:type", Number)
], SaleDetail.prototype, "unitPrice", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'decimal',
        precision: 10,
        scale: 2,
        generatedType: 'STORED',
        asExpression: 'quantity_sold * unit_price',
        insert: false,
        update: false,
    }),
    __metadata("design:type", Number)
], SaleDetail.prototype, "subtotal", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ type: 'timestamptz', name: 'created_at' }),
    __metadata("design:type", Date)
], SaleDetail.prototype, "createdAt", void 0);
exports.SaleDetail = SaleDetail = __decorate([
    (0, typeorm_1.Entity)('sale_details')
], SaleDetail);
//# sourceMappingURL=sale-detail.entity.js.map