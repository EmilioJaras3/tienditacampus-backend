"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var SnapshotScheduler_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.SnapshotScheduler = void 0;
const common_1 = require("@nestjs/common");
const schedule_1 = require("@nestjs/schedule");
const snapshot_service_1 = require("../snapshots/snapshot.service");
const config_1 = require("@nestjs/config");
let SnapshotScheduler = SnapshotScheduler_1 = class SnapshotScheduler {
    constructor(snapshotService, configService) {
        this.snapshotService = snapshotService;
        this.configService = configService;
        this.logger = new common_1.Logger(SnapshotScheduler_1.name);
    }
    async handleDailySnapshot() {
        try {
            this.logger.log('⏰ Ejecutando snapshot programado...');
            const accessToken = this.configService.get('GOOGLE_ACCESS_TOKEN');
            if (!accessToken) {
                this.logger.warn('⚠️ No hay token disponible. Usuario debe autenticarse primero.');
                return;
            }
            await this.snapshotService.executeDailySnapshot(accessToken);
        }
        catch (error) {
            this.logger.error('❌ Error en snapshot programado:', error.message);
        }
    }
    async handlePeriodicSnapshot() {
        this.logger.log('📊 Snapshot periódico (cada 6 horas)');
        try {
            const accessToken = this.configService.get('GOOGLE_ACCESS_TOKEN');
            if (accessToken) {
                await this.snapshotService.executeDailySnapshot(accessToken);
            }
            else {
                this.logger.warn('⚠️ No hay token para snapshot periódico');
            }
        }
        catch (error) {
            this.logger.error('❌ Error en snapshot periódico:', error.message);
        }
    }
};
exports.SnapshotScheduler = SnapshotScheduler;
__decorate([
    (0, schedule_1.Cron)('0 17 * * *'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], SnapshotScheduler.prototype, "handleDailySnapshot", null);
__decorate([
    (0, schedule_1.Cron)('0 */6 * * *'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], SnapshotScheduler.prototype, "handlePeriodicSnapshot", null);
exports.SnapshotScheduler = SnapshotScheduler = SnapshotScheduler_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [snapshot_service_1.SnapshotService,
        config_1.ConfigService])
], SnapshotScheduler);
//# sourceMappingURL=snapshot.scheduler.js.map