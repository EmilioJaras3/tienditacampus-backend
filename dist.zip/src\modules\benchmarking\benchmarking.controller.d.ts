import { Response } from 'express';
import { BenchmarkingService } from './benchmarking.service';
import { OAuthBigQueryService } from './auth/oauth-bigquery.service';
import { SnapshotService } from './snapshots/snapshot.service';
export declare class BenchmarkingController {
    private readonly benchmarkingService;
    private readonly oauthService;
    private readonly snapshotService;
    private readonly logger;
    constructor(benchmarkingService: BenchmarkingService, oauthService: OAuthBigQueryService, snapshotService: SnapshotService);
    getProject(): Promise<{
        project_id: number;
    }>;
    getMetrics(limit?: string): Promise<any[]>;
    runQueries(): Promise<{
        message: string;
    }>;
    takeSnapshot(googleToken: string): Promise<any>;
    takeHistoricalSnapshot(googleToken: string, days?: number): Promise<any>;
    executeSnapshot(body: {
        accessToken: string;
    }): Promise<void>;
    googleAuth(): {
        url: string;
    };
    googleCallback(code: string, res: Response): Promise<void>;
    exportCSV(projectId: number, res: Response): Promise<void>;
}
