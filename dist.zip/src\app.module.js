"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AppModule = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const typeorm_1 = require("@nestjs/typeorm");
const schedule_1 = require("@nestjs/schedule");
const serve_static_1 = require("@nestjs/serve-static");
const path_1 = require("path");
const configuration_1 = require("./config/configuration");
const validation_schema_1 = require("./config/validation.schema");
const database_config_1 = require("./config/database.config");
const auth_module_1 = require("./modules/auth/auth.module");
const users_module_1 = require("./modules/users/users.module");
const products_module_1 = require("./modules/products/products.module");
const sales_module_1 = require("./modules/sales/sales.module");
const inventory_module_1 = require("./modules/inventory/inventory.module");
const audit_module_1 = require("./modules/audit/audit.module");
const benchmarking_module_1 = require("./modules/benchmarking/benchmarking.module");
const reports_module_1 = require("./modules/reports/reports.module");
const health_controller_1 = require("./common/controllers/health.controller");
const orders_module_1 = require("./modules/orders/orders.module");
const break_even_module_1 = require("./modules/break-even/break-even.module");
const dashboard_module_1 = require("./modules/dashboard/dashboard.module");
const forecast_module_1 = require("./modules/forecast/forecast.module");
const expiration_module_1 = require("./modules/expiration/expiration.module");
const shared_module_1 = require("./shared/shared.module");
let AppModule = class AppModule {
};
exports.AppModule = AppModule;
exports.AppModule = AppModule = __decorate([
    (0, common_1.Module)({
        imports: [
            shared_module_1.SharedModule,
            config_1.ConfigModule.forRoot({
                isGlobal: true,
                load: [configuration_1.configuration],
                validationSchema: validation_schema_1.validationSchema,
            }),
            schedule_1.ScheduleModule.forRoot(),
            serve_static_1.ServeStaticModule.forRoot({
                rootPath: (0, path_1.join)(__dirname, '..', 'uploads'),
                serveRoot: '/uploads',
            }),
            typeorm_1.TypeOrmModule.forRootAsync({
                inject: [config_1.ConfigService],
                useFactory: database_config_1.databaseConfig,
            }),
            auth_module_1.AuthModule,
            users_module_1.UsersModule,
            products_module_1.ProductsModule,
            inventory_module_1.InventoryModule,
            sales_module_1.SalesModule,
            audit_module_1.AuditModule,
            orders_module_1.OrdersModule,
            benchmarking_module_1.BenchmarkingModule,
            reports_module_1.ReportsModule,
            break_even_module_1.BreakEvenModule,
            dashboard_module_1.DashboardModule,
            forecast_module_1.ForecastModule,
            expiration_module_1.ExpirationModule,
        ],
        controllers: [health_controller_1.HealthController],
    })
], AppModule);
//# sourceMappingURL=app.module.js.map