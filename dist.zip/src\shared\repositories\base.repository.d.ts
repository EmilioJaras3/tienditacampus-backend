import { Repository, DeepPartial, ObjectLiteral } from 'typeorm';
export declare abstract class BaseRepository<T extends ObjectLiteral> {
    protected readonly repository: Repository<T>;
    constructor(repository: Repository<T>);
    findById(id: any): Promise<T>;
    findAll(): Promise<T[]>;
    save(data: DeepPartial<T>): Promise<T>;
    delete(id: any): Promise<void>;
}
