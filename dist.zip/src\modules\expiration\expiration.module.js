"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ExpirationModule = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const expiration_service_1 = require("./expiration.service");
const expiration_controller_1 = require("./expiration.controller");
const inventory_record_entity_1 = require("../inventory/entities/inventory-record.entity");
const daily_sale_entity_1 = require("../sales/entities/daily-sale.entity");
const sale_detail_entity_1 = require("../sales/entities/sale-detail.entity");
const product_entity_1 = require("../products/entities/product.entity");
let ExpirationModule = class ExpirationModule {
};
exports.ExpirationModule = ExpirationModule;
exports.ExpirationModule = ExpirationModule = __decorate([
    (0, common_1.Module)({
        imports: [
            typeorm_1.TypeOrmModule.forFeature([inventory_record_entity_1.InventoryRecord, daily_sale_entity_1.DailySale, sale_detail_entity_1.SaleDetail, product_entity_1.Product]),
        ],
        controllers: [expiration_controller_1.ExpirationController],
        providers: [expiration_service_1.ExpirationService],
        exports: [expiration_service_1.ExpirationService],
    })
], ExpirationModule);
//# sourceMappingURL=expiration.module.js.map