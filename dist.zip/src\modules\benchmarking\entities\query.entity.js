"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Query = exports.QueryType = void 0;
const typeorm_1 = require("typeorm");
const project_entity_1 = require("./project.entity");
const execution_entity_1 = require("./execution.entity");
var QueryType;
(function (QueryType) {
    QueryType["SIMPLE_SELECT"] = "SIMPLE_SELECT";
    QueryType["AGGREGATION"] = "AGGREGATION";
    QueryType["JOIN"] = "JOIN";
    QueryType["WINDOW_FUNCTION"] = "WINDOW_FUNCTION";
    QueryType["SUBQUERY"] = "SUBQUERY";
    QueryType["WRITE_OPERATION"] = "WRITE_OPERATION";
})(QueryType || (exports.QueryType = QueryType = {}));
let Query = class Query {
};
exports.Query = Query;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)(),
    __metadata("design:type", Number)
], Query.prototype, "query_id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'project_id' }),
    __metadata("design:type", Number)
], Query.prototype, "project_id", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => project_entity_1.Project, (project) => project.queries),
    (0, typeorm_1.JoinColumn)({ name: 'project_id' }),
    __metadata("design:type", project_entity_1.Project)
], Query.prototype, "project", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text' }),
    __metadata("design:type", String)
], Query.prototype, "query_description", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text' }),
    __metadata("design:type", String)
], Query.prototype, "query_sql", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 100, nullable: true }),
    __metadata("design:type", String)
], Query.prototype, "target_table", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'varchar',
        length: 30,
        nullable: true,
    }),
    __metadata("design:type", String)
], Query.prototype, "query_type", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => execution_entity_1.Execution, (execution) => execution.query),
    __metadata("design:type", Array)
], Query.prototype, "executions", void 0);
exports.Query = Query = __decorate([
    (0, typeorm_1.Entity)('queries')
], Query);
//# sourceMappingURL=query.entity.js.map