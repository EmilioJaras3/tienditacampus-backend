import { DailySale } from '../entities/daily-sale.entity';
import { SalesRepository } from '../repositories/sales.repository';
import { PrepareDailySaleDto } from '../dto/prepare-daily-sale.dto';
import { User } from '../../users/entities/user.entity';
export declare class CreateDailySaleUseCase {
    private readonly salesRepository;
    constructor(salesRepository: SalesRepository);
    execute(prepareDto: PrepareDailySaleDto, user: User): Promise<DailySale>;
}
