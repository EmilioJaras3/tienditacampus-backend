import { Repository } from 'typeorm';
import { ConfigService } from '@nestjs/config';
import { User } from './entities/user.entity';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';
import { Product } from '../products/entities/product.entity';
export declare class UsersService {
    private readonly usersRepository;
    private readonly productRepository;
    private readonly configService;
    constructor(usersRepository: Repository<User>, productRepository: Repository<Product>, configService: ConfigService);
    findByEmail(email: string): Promise<User | null>;
    findById(id: string): Promise<User | null>;
    getPublicProfile(id: string): Promise<any>;
    create(dto: CreateUserDto): Promise<User>;
    update(id: string, dto: UpdateUserDto): Promise<User>;
    recordSuccessfulLogin(id: string): Promise<void>;
    recordFailedLogin(id: string): Promise<void>;
    updateRole(id: string, role: 'admin' | 'seller' | 'buyer'): Promise<void>;
    updatePasswordChangedAt(id: string): Promise<void>;
    updateEmailVerified(id: string, isVerified: boolean): Promise<void>;
}
