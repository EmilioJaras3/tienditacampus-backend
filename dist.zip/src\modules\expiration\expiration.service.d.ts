import { DataSource } from 'typeorm';
export declare class ExpirationService {
    private readonly dataSource;
    private readonly logger;
    constructor(dataSource: DataSource);
    handleCronExpiration(): Promise<void>;
    processExpiredInventory(): Promise<{
        lotsExpired: number;
        totalUnitsLost: number;
        totalWasteCost: number;
    }>;
}
