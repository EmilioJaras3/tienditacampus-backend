export declare class ExpirationModule {
}
