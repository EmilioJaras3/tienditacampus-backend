import { DailySale } from '../entities/daily-sale.entity';
import { SalesRepository } from '../repositories/sales.repository';
import { User } from '../../users/entities/user.entity';
import { AuditService } from '../../audit/audit.service';
export declare class CloseDayUseCase {
    private readonly salesRepository;
    private readonly auditService;
    constructor(salesRepository: SalesRepository, auditService: AuditService);
    execute(user: User, wastes: {
        productId: string;
        waste: number;
        wasteReason?: 'expired' | 'damaged' | 'other';
    }[]): Promise<DailySale>;
}
