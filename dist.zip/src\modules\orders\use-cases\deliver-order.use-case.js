"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DeliverOrderUseCase = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const order_entity_1 = require("../entities/order.entity");
const product_entity_1 = require("../../products/entities/product.entity");
const daily_sale_entity_1 = require("../../sales/entities/daily-sale.entity");
const sale_detail_entity_1 = require("../../sales/entities/sale-detail.entity");
const inventory_service_1 = require("../../inventory/inventory.service");
const transaction_manager_util_1 = require("../../../shared/utils/transaction-manager.util");
let DeliverOrderUseCase = class DeliverOrderUseCase {
    constructor(orderRepo, inventoryService, transactionManager) {
        this.orderRepo = orderRepo;
        this.inventoryService = inventoryService;
        this.transactionManager = transactionManager;
    }
    async execute(orderId, user) {
        return this.transactionManager.execute(async (queryRunner) => {
            const order = await queryRunner.manager.findOne(order_entity_1.Order, {
                where: { id: orderId },
                relations: ['items', 'items.product', 'seller', 'buyer']
            });
            if (!order)
                throw new common_1.NotFoundException('Orden no encontrada');
            if (order.status !== 'pending' && order.status !== 'accepted') {
                throw new common_1.BadRequestException('Esta orden ya fue procesada o cancelada');
            }
            if (order.buyerId !== user.id && order.sellerId !== user.id) {
                throw new common_1.BadRequestException('No tienes permiso para confirmar esta orden');
            }
            for (const item of order.items) {
                await this.inventoryService.consumeFIFO(item.productId, order.sellerId, item.quantity, queryRunner.manager);
            }
            order.status = 'completed';
            await queryRunner.manager.save(order_entity_1.Order, order);
            await this.syncDailySale(queryRunner, order);
            return order;
        }, 'Fallo al procesar la entrega de la orden');
    }
    async syncDailySale(queryRunner, order) {
        const todayStr = new Date().toISOString().split('T')[0];
        let dailySale = await queryRunner.manager.findOne(daily_sale_entity_1.DailySale, {
            where: { sellerId: order.sellerId, saleDate: todayStr },
            relations: ['details']
        });
        if (!dailySale) {
            dailySale = new daily_sale_entity_1.DailySale();
            dailySale.sellerId = order.sellerId;
            dailySale.saleDate = todayStr;
            dailySale.totalInvestment = 0;
            dailySale.totalRevenue = 0;
            dailySale.unitsSold = 0;
            dailySale.unitsLost = 0;
            dailySale.details = [];
            dailySale = await queryRunner.manager.save(daily_sale_entity_1.DailySale, dailySale);
        }
        for (const orderItem of order.items) {
            const details = (dailySale.details || []);
            let saleDetail = details.find(d => d.productId === orderItem.productId);
            let isNewDetail = false;
            if (!saleDetail) {
                saleDetail = new sale_detail_entity_1.SaleDetail();
                saleDetail.dailySaleId = dailySale.id;
                saleDetail.productId = orderItem.productId;
                saleDetail.quantityPrepared = 0;
                saleDetail.quantitySold = 0;
                saleDetail.quantityLost = 0;
                saleDetail.unitCost = await this.getUnitCost(queryRunner, orderItem.productId);
                saleDetail.unitPrice = orderItem.unitPrice;
                isNewDetail = true;
            }
            saleDetail.quantitySold += orderItem.quantity;
            if (isNewDetail)
                dailySale.details.push(saleDetail);
            else
                await queryRunner.manager.save(sale_detail_entity_1.SaleDetail, saleDetail);
        }
        this.recalculateAggregates(dailySale);
        await queryRunner.manager.save(daily_sale_entity_1.DailySale, dailySale);
        await queryRunner.manager.update(daily_sale_entity_1.DailySale, dailySale.id, {
            totalRevenue: dailySale.totalRevenue,
            totalInvestment: dailySale.totalInvestment,
            unitsSold: dailySale.unitsSold,
            unitsLost: dailySale.unitsLost,
            totalWasteCost: dailySale.totalWasteCost,
            profitMargin: dailySale.profitMargin,
            breakEvenUnits: dailySale.breakEvenUnits
        });
    }
    recalculateAggregates(dailySale) {
        let totalRevenue = 0;
        let unitsSold = 0;
        let unitsLost = 0;
        let totalInvestment = 0;
        let totalWasteCost = 0;
        for (const d of dailySale.details) {
            totalRevenue += Number(d.unitPrice) * d.quantitySold;
            unitsSold += d.quantitySold;
            unitsLost += d.quantityLost;
            const investmentContrib = d.quantityPrepared > 0 ? d.quantityPrepared : d.quantitySold;
            totalInvestment += Number(d.unitCost) * investmentContrib;
            totalWasteCost += Number(d.wasteCost || 0);
        }
        dailySale.totalRevenue = totalRevenue;
        dailySale.totalInvestment = totalInvestment;
        dailySale.unitsSold = unitsSold;
        dailySale.unitsLost = unitsLost;
        dailySale.totalWasteCost = totalWasteCost;
        const profit = totalRevenue - totalInvestment;
        dailySale.profitMargin = totalRevenue > 0 ? (profit / totalRevenue) * 100 : 0;
        if (unitsSold > 0) {
            const avgSalePrice = totalRevenue / unitsSold;
            const unitsPrepared = unitsSold + unitsLost;
            const avgUnitCost = unitsPrepared > 0 ? totalInvestment / unitsPrepared : 0;
            const wasteRate = unitsPrepared > 0 ? unitsLost / unitsPrepared : 0;
            const effectiveUnitCost = avgUnitCost * (1 + wasteRate);
            const unitMargin = avgSalePrice - effectiveUnitCost;
            if (unitMargin > 0) {
                dailySale.breakEvenUnits = Number((totalInvestment / unitMargin).toFixed(2));
            }
        }
    }
    async getUnitCost(queryRunner, productId) {
        const prod = await queryRunner.manager.findOne(product_entity_1.Product, { where: { id: productId } });
        return prod ? Number(prod.unitCost) : 0;
    }
};
exports.DeliverOrderUseCase = DeliverOrderUseCase;
exports.DeliverOrderUseCase = DeliverOrderUseCase = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(order_entity_1.Order)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        inventory_service_1.InventoryService,
        transaction_manager_util_1.TransactionManager])
], DeliverOrderUseCase);
//# sourceMappingURL=deliver-order.use-case.js.map