"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProductsService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const product_entity_1 = require("./entities/product.entity");
const category_entity_1 = require("./entities/category.entity");
const inventory_record_entity_1 = require("../inventory/entities/inventory-record.entity");
const audit_service_1 = require("../audit/audit.service");
let ProductsService = class ProductsService {
    constructor(productRepository, categoryRepository, inventoryRepository, auditService) {
        this.productRepository = productRepository;
        this.categoryRepository = categoryRepository;
        this.inventoryRepository = inventoryRepository;
        this.auditService = auditService;
    }
    async findAllCategories() {
        return await this.categoryRepository.find({
            where: { isActive: true },
            order: { name: 'ASC' },
        });
    }
    async create(createProductDto, user) {
        const product = this.productRepository.create({
            ...createProductDto,
            seller: user,
            sellerId: user.id,
        });
        const saved = await this.productRepository.save(product);
        await this.auditService.log({
            action: 'CREATE_PRODUCT',
            userId: user.id,
            entityType: 'products',
            entityId: saved.id,
            description: `Producto creado: ${saved.name}`,
            metadata: { salePrice: saved.salePrice }
        });
        return saved;
    }
    async findAll(user, page = 1, limit = 20) {
        const qb = this.productRepository.createQueryBuilder('product')
            .leftJoinAndSelect('product.category', 'cat')
            .leftJoin('inventory_records', 'inventory', 'inventory.product_id = product.id')
            .select([
            'product.id',
            'product.name',
            'product.description',
            'product.unitCost',
            'product.salePrice',
            'product.isPerishable',
            'product.shelfLifeDays',
            'product.imageUrl',
            'product.isActive',
            'product.createdAt',
            'cat.id',
            'cat.name'
        ])
            .addSelect('COALESCE(SUM(inventory.quantity_remaining), 0)', 'stock');
        if (user.role !== 'admin') {
            qb.where('product.sellerId = :sellerId', { sellerId: user.id });
        }
        qb.andWhere('product.isActive = :isActive', { isActive: true })
            .groupBy('product.id')
            .addGroupBy('cat.id')
            .orderBy('product.createdAt', 'DESC');
        const totalQb = this.productRepository.createQueryBuilder('product');
        if (user.role !== 'admin') {
            totalQb.where('product.sellerId = :sellerId', { sellerId: user.id });
        }
        const total = await totalQb.andWhere('product.isActive = :isActive', { isActive: true })
            .getCount();
        qb.offset((page - 1) * limit).limit(limit);
        const rawResults = await qb.getRawMany();
        const wasteRateQuery = `SELECT
                sd.product_id,
                COALESCE(SUM(sd.quantity_lost), 0)::int AS total_lost,
                COALESCE(SUM(sd.quantity_sold + sd.quantity_lost), 0)::int AS total_handled
            FROM sale_details sd
            INNER JOIN daily_sales ds ON ds.id = sd.daily_sale_id
            WHERE 1=1
              ${user.role === 'admin' ? '' : 'AND ds.seller_id = $1'}
              AND ds.sale_date >= (CURRENT_DATE - INTERVAL '30 days')
            GROUP BY sd.product_id`;
        const wasteRates = await this.productRepository.query(wasteRateQuery, user.role === 'admin' ? [] : [user.id]);
        const wasteRateMap = new Map();
        wasteRates.forEach((row) => {
            const lost = Number(row.total_lost);
            const handled = Number(row.total_handled);
            wasteRateMap.set(row.product_id, handled > 0 ? lost / handled : 0);
        });
        const data = rawResults.map(raw => {
            const stock = parseInt(raw.stock || raw.product_stock || '0', 10);
            const unitCost = parseFloat(raw.product_unit_cost || raw.product_unitCost || '0');
            const salePrice = parseFloat(raw.product_sale_price || raw.product_salePrice || '0');
            const wasteRate = wasteRateMap.get(raw.product_id) || 0;
            const effectiveUnitCost = unitCost * (1 + wasteRate);
            const margin = salePrice - effectiveUnitCost;
            const totalInvestment = stock * unitCost;
            const breakEvenUnits = margin > 0 && totalInvestment > 0
                ? Math.ceil(totalInvestment / margin)
                : 0;
            return {
                id: raw.product_id,
                name: raw.product_name,
                description: raw.product_description,
                unitCost: unitCost,
                salePrice: salePrice,
                isPerishable: raw.product_is_perishable || raw.product_isPerishable,
                shelfLifeDays: raw.product_shelf_life_days || raw.product_shelfLifeDays,
                imageUrl: raw.product_image_url || raw.product_imageUrl,
                createdAt: raw.product_created_at || raw.product_createdAt,
                category: raw.cat_id ? {
                    id: raw.cat_id,
                    name: raw.cat_name
                } : null,
                stock,
                wasteRate: Number((wasteRate * 100).toFixed(2)),
                breakEvenUnits
            };
        });
        return { data, total, page, limit };
    }
    async findMarketplace(query, sellerId, category, page = 1, limit = 20) {
        const qb = this.productRepository.createQueryBuilder('product')
            .leftJoin('product.seller', 'seller')
            .leftJoin('product.category', 'cat')
            .innerJoin('inventory_records', 'inventory', `inventory.product_id = product.id AND inventory.status = 'active' AND (inventory.expires_at IS NULL OR inventory.expires_at >= CURRENT_DATE)`)
            .select([
            'product.id',
            'product.name',
            'product.description',
            'product.salePrice',
            'product.imageUrl',
            'product.createdAt',
            'seller.id',
            'seller.firstName',
            'seller.lastName',
            'seller.avatarUrl',
            'cat.id',
            'cat.name'
        ])
            .addSelect('SUM(inventory.quantity_remaining)', 'quantityRemaining')
            .where('product.isActive = :isActive', { isActive: true })
            .andWhere('inventory.quantity_remaining > 0')
            .groupBy('product.id')
            .addGroupBy('product.name')
            .addGroupBy('product.description')
            .addGroupBy('product.salePrice')
            .addGroupBy('product.imageUrl')
            .addGroupBy('product.createdAt')
            .addGroupBy('seller.id')
            .addGroupBy('seller.firstName')
            .addGroupBy('seller.lastName')
            .addGroupBy('seller.avatarUrl')
            .addGroupBy('cat.id')
            .addGroupBy('cat.name')
            .orderBy('product.createdAt', 'DESC');
        if (sellerId) {
            qb.andWhere('seller.id = :sellerId', { sellerId });
        }
        if (category && category !== 'Todos') {
            qb.andWhere('cat.name = :category', { category });
        }
        if (query) {
            qb.andWhere('(product.name ILIKE :query OR product.description ILIKE :query)', { query: `%${query}%` });
        }
        const totalCountQb = this.productRepository.createQueryBuilder('product')
            .innerJoin('inventory_records', 'inventory', `inventory.product_id = product.id AND inventory.status = 'active' AND (inventory.expires_at IS NULL OR inventory.expires_at >= CURRENT_DATE)`)
            .where('product.isActive = :isActive', { isActive: true })
            .andWhere('inventory.quantity_remaining > 0');
        if (sellerId)
            totalCountQb.leftJoin('product.seller', 'seller').andWhere('seller.id = :sellerId', { sellerId });
        if (category && category !== 'Todos')
            totalCountQb.leftJoin('product.category', 'cat').andWhere('cat.name = :category', { category });
        if (query)
            totalCountQb.andWhere('(product.name ILIKE :query OR product.description ILIKE :query)', { query: `%${query}%` });
        const total = await totalCountQb.getCount();
        qb.offset((page - 1) * limit).limit(limit);
        const rawResults = await qb.getRawMany();
        const data = rawResults.map(raw => ({
            id: raw.product_id,
            name: raw.product_name,
            description: raw.product_description,
            salePrice: parseFloat(raw.product_sale_price || raw.product_salePrice || '0'),
            imageUrl: raw.product_image_url || raw.product_imageUrl,
            createdAt: raw.product_created_at || raw.product_createdAt,
            seller: {
                id: raw.seller_id,
                firstName: raw.seller_first_name || raw.seller_firstName,
                lastName: raw.seller_last_name || raw.seller_lastName,
                avatarUrl: raw.seller_avatar_url || raw.seller_avatarUrl
            },
            category: {
                id: raw.cat_id || raw.category_id,
                name: raw.cat_name || raw.category_name
            },
            quantityRemaining: parseInt(raw.quantityRemaining || raw.quantityremaining || '0', 10)
        }));
        return { data, total, page, limit };
    }
    async findOneMarketplace(id) {
        const product = await this.productRepository.createQueryBuilder('product')
            .leftJoinAndSelect('product.seller', 'seller')
            .where('product.id = :id', { id })
            .andWhere('product.isActive = :isActive', { isActive: true })
            .getOne();
        if (!product) {
            throw new common_1.NotFoundException(`Product with ID ${id} not found or inactive`);
        }
        return product;
    }
    async findOne(id, user) {
        const product = await this.productRepository.findOne({
            where: { id, sellerId: user.id, isActive: true },
        });
        if (!product) {
            throw new common_1.NotFoundException(`Product with ID ${id} not found`);
        }
        return product;
    }
    async update(id, updateProductDto, user) {
        const product = await this.findOne(id, user);
        Object.assign(product, updateProductDto);
        return await this.productRepository.save(product);
    }
    async remove(id, user) {
        const product = await this.findOne(id, user);
        product.isActive = false;
        await this.productRepository.save(product);
    }
};
exports.ProductsService = ProductsService;
exports.ProductsService = ProductsService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(product_entity_1.Product)),
    __param(1, (0, typeorm_1.InjectRepository)(category_entity_1.Category)),
    __param(2, (0, typeorm_1.InjectRepository)(inventory_record_entity_1.InventoryRecord)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository,
        audit_service_1.AuditService])
], ProductsService);
//# sourceMappingURL=products.service.js.map