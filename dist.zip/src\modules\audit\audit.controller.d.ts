import { AuditService } from './audit.service';
export declare class AuditController {
    private readonly auditService;
    constructor(auditService: AuditService);
    getMyActivity(user: {
        userId: string;
    }): Promise<import("./entities/audit-log.entity").AuditLog[]>;
    getRecent(limit?: string): Promise<import("./entities/audit-log.entity").AuditLog[]>;
    searchByMetadata(key: string, value: string): Promise<import("./entities/audit-log.entity").AuditLog[]>;
}
