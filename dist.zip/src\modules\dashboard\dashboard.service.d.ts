import { DataSource } from 'typeorm';
import { User } from '../users/entities/user.entity';
export declare class DashboardService {
    private readonly dataSource;
    constructor(dataSource: DataSource);
    getComparison(user: User, startDate?: string, endDate?: string): Promise<{
        weekComparison: any;
        monthComparison: any;
        profitabilityByProduct: any;
    }>;
}
