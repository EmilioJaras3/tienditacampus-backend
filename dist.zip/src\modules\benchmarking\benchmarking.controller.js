"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var BenchmarkingController_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.BenchmarkingController = void 0;
const common_1 = require("@nestjs/common");
const benchmarking_service_1 = require("./benchmarking.service");
const oauth_bigquery_service_1 = require("./auth/oauth-bigquery.service");
const snapshot_service_1 = require("./snapshots/snapshot.service");
const jwt_auth_guard_1 = require("../../common/guards/jwt-auth.guard");
const roles_guard_1 = require("../../common/guards/roles.guard");
const roles_decorator_1 = require("../../common/decorators/roles.decorator");
let BenchmarkingController = BenchmarkingController_1 = class BenchmarkingController {
    constructor(benchmarkingService, oauthService, snapshotService) {
        this.benchmarkingService = benchmarkingService;
        this.oauthService = oauthService;
        this.snapshotService = snapshotService;
        this.logger = new common_1.Logger(BenchmarkingController_1.name);
    }
    async getProject() {
        const projectId = await this.benchmarkingService.getCurrentProjectId();
        return { project_id: projectId };
    }
    async getMetrics(limit) {
        return this.benchmarkingService.getQueryMetrics(limit ? parseInt(limit) : 20);
    }
    async runQueries() {
        await this.benchmarkingService.runRegisteredQueries();
        return { message: 'Consultas de benchmarking ejecutadas con éxito' };
    }
    async takeSnapshot(googleToken) {
        if (!googleToken) {
            throw new common_1.UnauthorizedException('Se requiere x-google-token (Google OAuth)');
        }
        return this.benchmarkingService.processDailySnapshot(googleToken);
    }
    async takeHistoricalSnapshot(googleToken, days) {
        if (!googleToken) {
            throw new common_1.UnauthorizedException('Se requiere x-google-token (Google OAuth)');
        }
        return this.benchmarkingService.processHistoricalSnapshot(googleToken, days || 30);
    }
    async executeSnapshot(body) {
        if (!body.accessToken) {
            throw new common_1.UnauthorizedException('Access token required');
        }
        return this.snapshotService.executeDailySnapshot(body.accessToken);
    }
    googleAuth() {
        const authUrl = this.oauthService.getAuthUrl();
        return { url: authUrl };
    }
    async googleCallback(code, res) {
        try {
            if (!code)
                throw new common_1.BadRequestException('No code provided');
            const tokens = await this.oauthService.getTokenFromCode(code);
            res.redirect(`/dashboard/benchmarking?token=${tokens.accessToken}`);
        }
        catch (error) {
            this.logger.error('OAuth callback failed:', error.message);
            res.status(500).send(`Authentication failed: ${error.message}`);
        }
    }
    async exportCSV(projectId, res) {
        const csv = await this.snapshotService.exportToCSV(projectId);
        const filename = `project_${projectId}_${new Date().toISOString().split('T')[0]}.csv`;
        res.setHeader('Content-Type', 'text/csv');
        res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
        res.send(csv);
    }
};
exports.BenchmarkingController = BenchmarkingController;
__decorate([
    (0, common_1.Get)('project'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], BenchmarkingController.prototype, "getProject", null);
__decorate([
    (0, common_1.Get)('metrics'),
    __param(0, (0, common_1.Query)('limit')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], BenchmarkingController.prototype, "getMetrics", null);
__decorate([
    (0, common_1.Post)('run-queries'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], BenchmarkingController.prototype, "runQueries", null);
__decorate([
    (0, common_1.Post)('snapshot'),
    __param(0, (0, common_1.Headers)('x-google-token')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], BenchmarkingController.prototype, "takeSnapshot", null);
__decorate([
    (0, common_1.Post)('snapshot/historical'),
    __param(0, (0, common_1.Headers)('x-google-token')),
    __param(1, (0, common_1.Body)('days')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Number]),
    __metadata("design:returntype", Promise)
], BenchmarkingController.prototype, "takeHistoricalSnapshot", null);
__decorate([
    (0, common_1.Post)('snapshots/execute'),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], BenchmarkingController.prototype, "executeSnapshot", null);
__decorate([
    (0, common_1.Get)('auth/google'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], BenchmarkingController.prototype, "googleAuth", null);
__decorate([
    (0, common_1.Get)('auth/callback'),
    __param(0, (0, common_1.Query)('code')),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], BenchmarkingController.prototype, "googleCallback", null);
__decorate([
    (0, common_1.Get)('snapshots/export/:projectId'),
    __param(0, (0, common_1.Param)('projectId')),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, Object]),
    __metadata("design:returntype", Promise)
], BenchmarkingController.prototype, "exportCSV", null);
exports.BenchmarkingController = BenchmarkingController = BenchmarkingController_1 = __decorate([
    (0, common_1.Controller)('benchmarking'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, roles_guard_1.RolesGuard),
    (0, roles_decorator_1.Roles)('admin'),
    __metadata("design:paramtypes", [benchmarking_service_1.BenchmarkingService,
        oauth_bigquery_service_1.OAuthBigQueryService,
        snapshot_service_1.SnapshotService])
], BenchmarkingController);
//# sourceMappingURL=benchmarking.controller.js.map