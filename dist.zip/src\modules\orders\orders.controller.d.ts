import { OrdersService } from './orders.service';
import { CreateOrderDto } from './dto/create-order.dto';
export declare class OrdersController {
    private readonly ordersService;
    constructor(ordersService: OrdersService);
    createOrder(createOrderDto: CreateOrderDto, req: any): Promise<import("./entities/order.entity").Order>;
    getBuyerPurchases(req: any, page?: number, limit?: number): Promise<{
        data: import("./entities/order.entity").Order[];
        total: number;
        page: number;
        limit: number;
    }>;
    getSellerSales(req: any, page?: number, limit?: number): Promise<{
        data: import("./entities/order.entity").Order[];
        total: number;
        page: number;
        limit: number;
    }>;
    acceptOrder(id: string, req: any): Promise<import("./entities/order.entity").Order>;
    rejectOrder(id: string, req: any): Promise<import("./entities/order.entity").Order>;
    deliverOrder(id: string, req: any): Promise<import("./entities/order.entity").Order>;
}
