import { ReportsService } from './reports.service';
export declare class ReportsController {
    private readonly reportsService;
    constructor(reportsService: ReportsService);
    generateWeeklyReport(req: any, weekStart?: string): Promise<import("./entities/weekly-report.entity").WeeklyReport[]>;
    getWeeklyReports(req: any, startWeek?: string, endWeek?: string): Promise<import("./entities/weekly-report.entity").WeeklyReport[]>;
    getReportById(id: string, req: any): Promise<import("./entities/weekly-report.entity").WeeklyReport>;
    deleteReport(id: string, req: any): Promise<void>;
}
