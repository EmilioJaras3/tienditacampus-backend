import { JwtService } from '@nestjs/jwt';
import { UsersService } from '../../users/users.service';
import { AuditService } from '../../audit/audit.service';
import { RegisterDto } from '../dto/register.dto';
export declare class RegisterUseCase {
    private readonly usersService;
    private readonly jwtService;
    private readonly auditService;
    constructor(usersService: UsersService, jwtService: JwtService, auditService: AuditService);
    execute(dto: RegisterDto): Promise<{
        user: import("../../users/entities/user.entity").User;
        accessToken: string;
    }>;
}
