"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ReportsService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const weekly_report_entity_1 = require("./entities/weekly-report.entity");
let ReportsService = class ReportsService {
    constructor(weeklyReportRepository, dataSource) {
        this.weeklyReportRepository = weeklyReportRepository;
        this.dataSource = dataSource;
    }
    async generateWeeklyReport(user, weekStart) {
        await this.dataSource.query(`DELETE FROM weekly_reports WHERE seller_id = $1 AND week_start = COALESCE($2::date, date_trunc('week', CURRENT_DATE)::date)`, [user.id, weekStart ?? null]);
        await this.dataSource.query(`
            WITH target_week AS (
                SELECT COALESCE($2::date, date_trunc('week', CURRENT_DATE)::date) AS week_start
            ),
            weekly_base AS (
                SELECT
                    $1::uuid AS seller_id,
                    tw.week_start,
                    (tw.week_start + interval '6 day')::date AS week_end,
                    COALESCE(SUM(ds.total_revenue), 0)::numeric(10,2) AS total_revenue,
                    COALESCE(SUM(ds.total_investment), 0)::numeric(10,2) AS total_investment,
                    COALESCE(AVG(ds.profit_margin), 0)::numeric(5,2) AS avg_profit_margin,
                    COALESCE(SUM(ds.units_sold), 0)::int AS total_units_sold,
                    COALESCE(SUM(ds.units_lost), 0)::int AS total_units_lost,
                    COALESCE(SUM(ds.total_waste_cost), 0)::numeric(10,2) AS total_waste_cost
                FROM target_week tw
                LEFT JOIN daily_sales ds
                    ON ds.seller_id = $1
                    AND ds.sale_date BETWEEN tw.week_start AND (tw.week_start + interval '6 day')::date
                GROUP BY tw.week_start
            ),
            best_product AS (
                SELECT
                    sd.product_id,
                    SUM(sd.quantity_sold) AS sold_units,
                    ROW_NUMBER() OVER (ORDER BY SUM(sd.quantity_sold) DESC, sd.product_id) AS rn
                FROM sale_details sd
                INNER JOIN daily_sales ds ON ds.id = sd.daily_sale_id
                INNER JOIN target_week tw
                    ON ds.sale_date BETWEEN tw.week_start AND (tw.week_start + interval '6 day')::date
                WHERE ds.seller_id = $1
                GROUP BY sd.product_id
            )
            INSERT INTO weekly_reports (
                seller_id,
                week_start,
                week_end,
                total_investment,
                total_revenue,
                total_profit,
                avg_profit_margin,
                total_units_sold,
                total_units_lost,
                total_waste_cost,
                loss_percentage,
                best_selling_product
            )
            SELECT
                wb.seller_id,
                wb.week_start,
                wb.week_end,
                wb.total_investment,
                wb.total_revenue,
                (wb.total_revenue - wb.total_investment)::numeric(10,2) AS total_profit,
                wb.avg_profit_margin,
                wb.total_units_sold,
                wb.total_units_lost,
                wb.total_waste_cost,
                CASE
                    WHEN (wb.total_units_sold + wb.total_units_lost) > 0
                        THEN ROUND((wb.total_units_lost::numeric * 100) / (wb.total_units_sold + wb.total_units_lost), 2)
                    ELSE 0
                END AS loss_percentage,
                (SELECT bp.product_id FROM best_product bp WHERE bp.rn = 1)
            FROM weekly_base wb
            `, [user.id, weekStart ?? null]);
        const targetWeek = weekStart ?? undefined;
        return this.getWeeklyReports(user, targetWeek, targetWeek);
    }
    async getWeeklyReports(user, startWeek, endWeek) {
        const qb = this.weeklyReportRepository
            .createQueryBuilder('report')
            .leftJoinAndSelect('report.bestSellingProduct', 'bestProduct')
            .where('report.sellerId = :sellerId', { sellerId: user.id })
            .orderBy('report.weekStart', 'DESC');
        if (startWeek) {
            qb.andWhere('report.weekStart >= :startWeek', { startWeek });
        }
        if (endWeek) {
            qb.andWhere('report.weekStart <= :endWeek', { endWeek });
        }
        return qb.getMany();
    }
    async findOne(id, user) {
        const report = await this.weeklyReportRepository.findOne({
            where: { id, sellerId: user.id },
            relations: ['bestSellingProduct'],
        });
        if (!report) {
            throw new common_1.NotFoundException(`Report with ID ${id} not found`);
        }
        return report;
    }
    async remove(id, user) {
        const report = await this.findOne(id, user);
        await this.weeklyReportRepository.remove(report);
    }
};
exports.ReportsService = ReportsService;
exports.ReportsService = ReportsService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(weekly_report_entity_1.WeeklyReport)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.DataSource])
], ReportsService);
//# sourceMappingURL=reports.service.js.map