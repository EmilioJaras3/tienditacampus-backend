import { SalesService } from './sales.service';
import { PrepareDailySaleDto } from './dto/prepare-daily-sale.dto';
import { TrackSaleDto } from './dto/track-sale.dto';
import { CloseDayDto } from './dto/close-day.dto';
export declare class SalesController {
    private readonly salesService;
    constructor(salesService: SalesService);
    getToday(req: any): Promise<any>;
    prepareDay(prepareDto: PrepareDailySaleDto, req: any): Promise<any>;
    trackProduct(trackDto: TrackSaleDto, req: any): Promise<any>;
    getROI(req: any): Promise<{
        investment: number;
        revenue: number;
        netProfit: number;
        roi: number;
    }>;
    getHistory(req: any, page?: number, limit?: number): Promise<{
        data: import("./entities/daily-sale.entity").DailySale[];
        total: number;
        page: number;
        limit: number;
    }>;
    getByWeekdayAnalytics(req: any): Promise<any[]>;
    getPrediction(req: any): Promise<any>;
    closeDay(dto: CloseDayDto, req: any): Promise<any>;
}
