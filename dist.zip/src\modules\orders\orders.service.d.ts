import { Repository, DataSource } from 'typeorm';
import { Order } from './entities/order.entity';
import { CreateOrderDto } from './dto/create-order.dto';
import { User } from '../users/entities/user.entity';
import { InventoryService } from '../inventory/inventory.service';
export declare class OrdersService {
    private readonly orderRepo;
    private readonly dataSource;
    private readonly inventoryService;
    constructor(orderRepo: Repository<Order>, dataSource: DataSource, inventoryService: InventoryService);
    createOrder(dto: CreateOrderDto, buyer: User): Promise<Order>;
    acceptOrder(orderId: string, seller: User): Promise<Order>;
    rejectOrder(orderId: string, seller: User): Promise<Order>;
    deliverOrder(orderId: string, user: User): Promise<Order>;
    private getUnitCost;
    getBuyerPurchases(buyer: User, page?: number, limit?: number): Promise<{
        data: Order[];
        total: number;
        page: number;
        limit: number;
    }>;
    getSellerSales(seller: User, page?: number, limit?: number): Promise<{
        data: Order[];
        total: number;
        page: number;
        limit: number;
    }>;
}
