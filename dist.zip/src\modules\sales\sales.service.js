"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SalesService = void 0;
const common_1 = require("@nestjs/common");
const sales_repository_1 = require("./repositories/sales.repository");
const create_daily_sale_use_case_1 = require("./use-cases/create-daily-sale.use-case");
const close_day_use_case_1 = require("./use-cases/close-day.use-case");
const track_sale_use_case_1 = require("./use-cases/track-sale.use-case");
let SalesService = class SalesService {
    constructor(salesRepository, createDailySaleUseCase, closeDayUseCase, trackSaleUseCase) {
        this.salesRepository = salesRepository;
        this.createDailySaleUseCase = createDailySaleUseCase;
        this.closeDayUseCase = closeDayUseCase;
        this.trackSaleUseCase = trackSaleUseCase;
    }
    async getPrediction(user) {
        return await this.salesRepository.getPrediction(user.id);
    }
    async closeDay(user, wastes) {
        return await this.closeDayUseCase.execute(user, wastes);
    }
    async findToday(user) {
        return await this.salesRepository.findToday(user.id);
    }
    async prepareDay(prepareDto, user) {
        return await this.createDailySaleUseCase.execute(prepareDto, user);
    }
    async trackProduct(trackDto, user) {
        return await this.trackSaleUseCase.execute(trackDto, user);
    }
    async getROI(user) {
        return await this.salesRepository.getROI(user.id);
    }
    async getHistory(user, page = 1, limit = 20) {
        return await this.salesRepository.getHistory(user.id, page, limit);
    }
    async getByWeekdayAnalytics(user) {
        return await this.salesRepository.getByWeekdayAnalytics(user.id);
    }
};
exports.SalesService = SalesService;
exports.SalesService = SalesService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [sales_repository_1.SalesRepository,
        create_daily_sale_use_case_1.CreateDailySaleUseCase,
        close_day_use_case_1.CloseDayUseCase,
        track_sale_use_case_1.TrackSaleUseCase])
], SalesService);
//# sourceMappingURL=sales.service.js.map