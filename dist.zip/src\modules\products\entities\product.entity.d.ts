import { User } from '../../users/entities/user.entity';
import { Category } from './category.entity';
export declare class Product {
    id: string;
    sellerId: string;
    seller: User;
    categoryId: string | null;
    category: Category | null;
    name: string;
    description: string;
    unitCost: number;
    salePrice: number;
    isPerishable: boolean;
    shelfLifeDays: number;
    imageUrl: string;
    isActive: boolean;
    createdAt: Date;
    updatedAt: Date;
}
