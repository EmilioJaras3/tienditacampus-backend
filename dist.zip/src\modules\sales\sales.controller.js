"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SalesController = void 0;
const common_1 = require("@nestjs/common");
const sales_service_1 = require("./sales.service");
const prepare_daily_sale_dto_1 = require("./dto/prepare-daily-sale.dto");
const track_sale_dto_1 = require("./dto/track-sale.dto");
const close_day_dto_1 = require("./dto/close-day.dto");
const jwt_auth_guard_1 = require("../../common/guards/jwt-auth.guard");
const roles_guard_1 = require("../../common/guards/roles.guard");
const business_hours_guard_1 = require("../../common/guards/business-hours.guard");
const roles_decorator_1 = require("../../common/decorators/roles.decorator");
let SalesController = class SalesController {
    constructor(salesService) {
        this.salesService = salesService;
    }
    async getToday(req) {
        const result = await this.salesService.findToday(req.user);
        return result || null;
    }
    prepareDay(prepareDto, req) {
        return this.salesService.prepareDay(prepareDto, req.user);
    }
    trackProduct(trackDto, req) {
        return this.salesService.trackProduct(trackDto, req.user);
    }
    getROI(req) {
        return this.salesService.getROI(req.user);
    }
    getHistory(req, page, limit) {
        return this.salesService.getHistory(req.user, Number(page) || 1, Number(limit) || 20);
    }
    getByWeekdayAnalytics(req) {
        return this.salesService.getByWeekdayAnalytics(req.user);
    }
    getPrediction(req) {
        return this.salesService.getPrediction(req.user);
    }
    closeDay(dto, req) {
        return this.salesService.closeDay(req.user, dto.items);
    }
};
exports.SalesController = SalesController;
__decorate([
    (0, common_1.Get)('today'),
    __param(0, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], SalesController.prototype, "getToday", null);
__decorate([
    (0, common_1.Post)('prepare'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [prepare_daily_sale_dto_1.PrepareDailySaleDto, Object]),
    __metadata("design:returntype", void 0)
], SalesController.prototype, "prepareDay", null);
__decorate([
    (0, common_1.Post)('track'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [track_sale_dto_1.TrackSaleDto, Object]),
    __metadata("design:returntype", void 0)
], SalesController.prototype, "trackProduct", null);
__decorate([
    (0, common_1.Get)('roi'),
    __param(0, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], SalesController.prototype, "getROI", null);
__decorate([
    (0, common_1.Get)('history'),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Query)('page')),
    __param(2, (0, common_1.Query)('limit')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Number, Number]),
    __metadata("design:returntype", void 0)
], SalesController.prototype, "getHistory", null);
__decorate([
    (0, common_1.Get)('analytics/by-weekday'),
    __param(0, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], SalesController.prototype, "getByWeekdayAnalytics", null);
__decorate([
    (0, common_1.Get)('prediction'),
    __param(0, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], SalesController.prototype, "getPrediction", null);
__decorate([
    (0, common_1.Post)('close-day'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [close_day_dto_1.CloseDayDto, Object]),
    __metadata("design:returntype", void 0)
], SalesController.prototype, "closeDay", null);
exports.SalesController = SalesController = __decorate([
    (0, common_1.Controller)('sales'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, roles_guard_1.RolesGuard, business_hours_guard_1.BusinessHoursGuard),
    (0, roles_decorator_1.Roles)('seller', 'admin'),
    __metadata("design:paramtypes", [sales_service_1.SalesService])
], SalesController);
//# sourceMappingURL=sales.controller.js.map