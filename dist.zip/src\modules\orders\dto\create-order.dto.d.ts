export declare class OrderItemDto {
    productId: string;
    quantity: number;
}
export declare class CreateOrderDto {
    sellerId: string;
    items: OrderItemDto[];
    deliveryMessage?: string;
}
