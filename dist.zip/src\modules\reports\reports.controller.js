"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ReportsController = void 0;
const common_1 = require("@nestjs/common");
const jwt_auth_guard_1 = require("../../common/guards/jwt-auth.guard");
const roles_guard_1 = require("../../common/guards/roles.guard");
const business_hours_guard_1 = require("../../common/guards/business-hours.guard");
const roles_decorator_1 = require("../../common/decorators/roles.decorator");
const reports_service_1 = require("./reports.service");
let ReportsController = class ReportsController {
    constructor(reportsService) {
        this.reportsService = reportsService;
    }
    generateWeeklyReport(req, weekStart) {
        return this.reportsService.generateWeeklyReport(req.user, weekStart);
    }
    getWeeklyReports(req, startWeek, endWeek) {
        return this.reportsService.getWeeklyReports(req.user, startWeek, endWeek);
    }
    getReportById(id, req) {
        return this.reportsService.findOne(id, req.user);
    }
    deleteReport(id, req) {
        return this.reportsService.remove(id, req.user);
    }
};
exports.ReportsController = ReportsController;
__decorate([
    (0, common_1.Post)('weekly/generate'),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Query)('weekStart')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", void 0)
], ReportsController.prototype, "generateWeeklyReport", null);
__decorate([
    (0, common_1.Get)('weekly'),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Query)('startWeek')),
    __param(2, (0, common_1.Query)('endWeek')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String]),
    __metadata("design:returntype", void 0)
], ReportsController.prototype, "getWeeklyReports", null);
__decorate([
    (0, common_1.Get)('weekly/:id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], ReportsController.prototype, "getReportById", null);
__decorate([
    (0, common_1.Delete)('weekly/:id'),
    (0, common_1.HttpCode)(common_1.HttpStatus.NO_CONTENT),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], ReportsController.prototype, "deleteReport", null);
exports.ReportsController = ReportsController = __decorate([
    (0, common_1.Controller)('reports'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, roles_guard_1.RolesGuard, business_hours_guard_1.BusinessHoursGuard),
    (0, roles_decorator_1.Roles)('seller', 'admin'),
    __metadata("design:paramtypes", [reports_service_1.ReportsService])
], ReportsController);
//# sourceMappingURL=reports.controller.js.map