"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BreakEvenService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const product_entity_1 = require("../products/entities/product.entity");
let BreakEvenService = class BreakEvenService {
    constructor(productRepository, dataSource) {
        this.productRepository = productRepository;
        this.dataSource = dataSource;
    }
    async calculate(dto, user) {
        const product = await this.productRepository.findOne({
            where: {
                id: dto.productId,
                sellerId: user.id,
                isActive: true,
            },
        });
        if (!product) {
            throw new common_1.NotFoundException('Producto no encontrado para el vendedor autenticado');
        }
        const wasteRateResult = await this.dataSource.query(`SELECT
                COALESCE(SUM(sd.quantity_lost), 0)::int AS total_lost,
                COALESCE(SUM(sd.quantity_sold + sd.quantity_lost), 0)::int AS total_handled
            FROM sale_details sd
            INNER JOIN daily_sales ds ON ds.id = sd.daily_sale_id
            WHERE sd.product_id = $1
              AND ds.seller_id = $2
              AND ds.sale_date >= (CURRENT_DATE - INTERVAL '30 days')`, [dto.productId, user.id]);
        const totalLost = Number(wasteRateResult[0]?.total_lost || 0);
        const totalHandled = Number(wasteRateResult[0]?.total_handled || 0);
        const wasteRate = totalHandled > 0 ? totalLost / totalHandled : 0;
        const rawUnitCost = Number(dto.unitCost ?? product.unitCost);
        const effectiveUnitCost = rawUnitCost * (1 + wasteRate);
        const unitCostCents = this.toCents(effectiveUnitCost);
        const unitPriceCents = this.toCents(dto.unitPrice ?? product.salePrice);
        const fixedCostsCents = this.toCents(dto.fixedCosts);
        const marginCents = unitPriceCents - unitCostCents;
        if (marginCents <= 0n) {
            throw new common_1.BadRequestException('Margen unitario no positivo después de ajustar por merma: ' +
                'el precio debe cubrir el costo efectivo (costo × (1 + tasa_merma))');
        }
        const breakEvenUnits = this.ceilDiv(fixedCostsCents, marginCents);
        return {
            productId: product.id,
            productName: product.name,
            fixedCosts: this.fromCents(fixedCostsCents),
            unitCost: this.fromCents(this.toCents(rawUnitCost)),
            effectiveUnitCost: this.fromCents(unitCostCents),
            unitPrice: this.fromCents(unitPriceCents),
            unitMargin: this.fromCents(marginCents),
            wasteRate: Number((wasteRate * 100).toFixed(2)),
            wasteRateSample: { totalLost, totalHandled, periodDays: 30 },
            breakEvenUnits,
            formula: 'break_even = fixed_costs / (unit_price - unit_cost × (1 + waste_rate))',
        };
    }
    toCents(value) {
        const normalized = Number(value).toFixed(2);
        const [intPart, decimalPart] = normalized.split('.');
        return BigInt(`${intPart}${decimalPart}`);
    }
    fromCents(value) {
        const sign = value < 0n ? '-' : '';
        const abs = value < 0n ? -value : value;
        const base = abs.toString().padStart(3, '0');
        const intPart = base.slice(0, -2);
        const decPart = base.slice(-2);
        return `${sign}${intPart}.${decPart}`;
    }
    ceilDiv(numerator, denominator) {
        const result = (numerator + denominator - 1n) / denominator;
        return Number(result);
    }
};
exports.BreakEvenService = BreakEvenService;
exports.BreakEvenService = BreakEvenService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(product_entity_1.Product)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.DataSource])
], BreakEvenService);
//# sourceMappingURL=break-even.service.js.map