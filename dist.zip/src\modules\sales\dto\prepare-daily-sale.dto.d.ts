export declare class PrepareDailySaleItemDto {
    productId: string;
    quantityPrepared: number;
}
export declare class PrepareDailySaleDto {
    items: PrepareDailySaleItemDto[];
}
