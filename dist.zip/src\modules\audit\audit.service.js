"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuditService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const audit_log_entity_1 = require("./entities/audit-log.entity");
let AuditService = class AuditService {
    constructor(auditRepository) {
        this.auditRepository = auditRepository;
    }
    async log(params) {
        try {
            const entry = this.auditRepository.create({
                action: params.action,
                entityType: params.entityType,
                entityId: params.entityId,
                userId: params.userId,
                metadata: params.metadata || {},
                level: params.level || 'info',
                description: params.description,
                ipAddress: params.ipAddress,
            });
            return await this.auditRepository.save(entry);
        }
        catch (error) {
            console.error('Audit log failed (PostgreSQL):', error.message);
            return null;
        }
    }
    async findByAction(action) {
        return this.auditRepository.find({
            where: { action },
            order: { createdAt: 'DESC' },
            take: 100,
        });
    }
    async findByUser(userId) {
        return this.auditRepository.find({
            where: { userId },
            order: { createdAt: 'DESC' },
            take: 100,
        });
    }
    async findByEntity(entityType, entityId) {
        return this.auditRepository.find({
            where: { entityType, entityId },
            order: { createdAt: 'DESC' },
            take: 50,
        });
    }
    async findByMetadataKey(key, value) {
        if (!/^[a-zA-Z0-9_]+$/.test(key)) {
            return [];
        }
        return this.auditRepository
            .createQueryBuilder('audit')
            .where(`audit.metadata->>:key = :value`, { key, value })
            .orderBy('audit.createdAt', 'DESC')
            .take(50)
            .getMany();
    }
    async getRecent(limit = 50) {
        return this.auditRepository.find({
            order: { createdAt: 'DESC' },
            take: limit,
        });
    }
    async findAll() {
        return this.auditRepository.find({
            order: { createdAt: 'DESC' },
            take: 100
        });
    }
};
exports.AuditService = AuditService;
exports.AuditService = AuditService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(audit_log_entity_1.AuditLog)),
    __metadata("design:paramtypes", [typeorm_2.Repository])
], AuditService);
//# sourceMappingURL=audit.service.js.map