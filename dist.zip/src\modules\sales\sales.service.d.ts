import { User } from '../users/entities/user.entity';
import { PrepareDailySaleDto } from './dto/prepare-daily-sale.dto';
import { TrackSaleDto } from './dto/track-sale.dto';
import { SalesRepository } from './repositories/sales.repository';
import { CreateDailySaleUseCase } from './use-cases/create-daily-sale.use-case';
import { CloseDayUseCase } from './use-cases/close-day.use-case';
import { TrackSaleUseCase } from './use-cases/track-sale.use-case';
export declare class SalesService {
    private readonly salesRepository;
    private readonly createDailySaleUseCase;
    private readonly closeDayUseCase;
    private readonly trackSaleUseCase;
    constructor(salesRepository: SalesRepository, createDailySaleUseCase: CreateDailySaleUseCase, closeDayUseCase: CloseDayUseCase, trackSaleUseCase: TrackSaleUseCase);
    getPrediction(user: User): Promise<any>;
    closeDay(user: User, wastes: {
        productId: string;
        waste: number;
        wasteReason?: 'expired' | 'damaged' | 'other';
    }[]): Promise<any>;
    findToday(user: User): Promise<any | null>;
    prepareDay(prepareDto: PrepareDailySaleDto, user: User): Promise<any>;
    trackProduct(trackDto: TrackSaleDto, user: User): Promise<any>;
    getROI(user: User): Promise<{
        investment: number;
        revenue: number;
        netProfit: number;
        roi: number;
    }>;
    getHistory(user: User, page?: number, limit?: number): Promise<{
        data: import("./entities/daily-sale.entity").DailySale[];
        total: number;
        page: number;
        limit: number;
    }>;
    getByWeekdayAnalytics(user: User): Promise<any[]>;
}
