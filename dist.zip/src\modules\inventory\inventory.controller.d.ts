import { InventoryService } from './inventory.service';
import { CreateInventoryRecordDto } from './dto/create-inventory-record.dto';
export declare class InventoryController {
    private readonly inventoryService;
    constructor(inventoryService: InventoryService);
    addStock(createInventoryDto: CreateInventoryRecordDto, req: any): Promise<import("./entities/inventory-record.entity").InventoryRecord>;
    getHistory(productId: string, req: any): Promise<import("./entities/inventory-record.entity").InventoryRecord[]>;
}
