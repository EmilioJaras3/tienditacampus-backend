import { ProductsService } from './products.service';
import { CreateProductDto } from './dto/create-product.dto';
import { UpdateProductDto } from './dto/update-product.dto';
export declare class ProductsController {
    private readonly productsService;
    constructor(productsService: ProductsService);
    getMarketplace(q?: string, sellerId?: string, category?: string, page?: number, limit?: number): Promise<{
        data: any[];
        total: number;
        page: number;
        limit: number;
    }>;
    findOneMarketplace(id: string): Promise<import("./entities/product.entity").Product>;
    create(createProductDto: CreateProductDto, req: any): Promise<import("./entities/product.entity").Product>;
    findAll(req: any, page?: number, limit?: number): Promise<{
        data: any[];
        total: number;
        page: number;
        limit: number;
    }>;
    findOne(id: string, req: any): Promise<import("./entities/product.entity").Product>;
    update(id: string, updateProductDto: UpdateProductDto, req: any): Promise<import("./entities/product.entity").Product>;
    remove(id: string, req: any): Promise<void>;
}
