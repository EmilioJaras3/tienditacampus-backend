import { User } from '../../users/entities/user.entity';
import { Product } from '../../products/entities/product.entity';
export declare class WeeklyReport {
    id: string;
    sellerId: string;
    seller: User;
    weekStart: string;
    weekEnd: string;
    totalInvestment: number;
    totalRevenue: number;
    totalProfit: number;
    avgProfitMargin: number;
    totalWasteCost: number;
    totalUnitsSold: number;
    totalUnitsLost: number;
    lossPercentage: number;
    bestSellingProductId: string | null;
    bestSellingProduct: Product | null;
    demandPrediction: unknown;
    createdAt: Date;
}
