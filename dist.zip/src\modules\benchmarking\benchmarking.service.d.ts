import { EntityManager, Repository } from 'typeorm';
import { Project } from './entities/project.entity';
import { Query } from './entities/query.entity';
export declare class BenchmarkingService {
    private readonly entityManager;
    private readonly projectRepository;
    private readonly queryRepository;
    private readonly logger;
    constructor(entityManager: EntityManager, projectRepository: Repository<Project>, queryRepository: Repository<Query>);
    getCurrentProjectId(): Promise<number>;
    runRegisteredQueries(): Promise<void>;
    processDailySnapshot(authHeader: string): Promise<any>;
    processHistoricalSnapshot(authHeader: string, days?: number): Promise<any>;
    private sendToBigQuery;
    getQueryMetrics(limit?: number): Promise<any[]>;
}
