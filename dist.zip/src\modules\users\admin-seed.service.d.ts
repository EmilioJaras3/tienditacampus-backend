import { OnApplicationBootstrap } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { Repository } from 'typeorm';
import { User } from './entities/user.entity';
export declare class AdminSeedService implements OnApplicationBootstrap {
    private readonly configService;
    private readonly usersRepository;
    private readonly logger;
    constructor(configService: ConfigService, usersRepository: Repository<User>);
    onApplicationBootstrap(): Promise<void>;
}
