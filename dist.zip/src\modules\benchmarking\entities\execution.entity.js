"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Execution = exports.IndexStrategy = void 0;
const typeorm_1 = require("typeorm");
const project_entity_1 = require("./project.entity");
const query_entity_1 = require("./query.entity");
var IndexStrategy;
(function (IndexStrategy) {
    IndexStrategy["NO_INDEX"] = "NO_INDEX";
    IndexStrategy["SINGLE_INDEX"] = "SINGLE_INDEX";
    IndexStrategy["COMPOSITE_INDEX"] = "COMPOSITE_INDEX";
})(IndexStrategy || (exports.IndexStrategy = IndexStrategy = {}));
let Execution = class Execution {
};
exports.Execution = Execution;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)({ type: 'bigint' }),
    __metadata("design:type", String)
], Execution.prototype, "execution_id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'project_id' }),
    __metadata("design:type", Number)
], Execution.prototype, "project_id", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => project_entity_1.Project, (project) => project.executions),
    (0, typeorm_1.JoinColumn)({ name: 'project_id' }),
    __metadata("design:type", project_entity_1.Project)
], Execution.prototype, "project", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'query_id' }),
    __metadata("design:type", Number)
], Execution.prototype, "query_id", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => query_entity_1.Query, (query) => query.executions),
    (0, typeorm_1.JoinColumn)({ name: 'query_id' }),
    __metadata("design:type", query_entity_1.Query)
], Execution.prototype, "query", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'varchar',
        length: 20,
        nullable: true,
    }),
    __metadata("design:type", String)
], Execution.prototype, "index_strategy", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ type: 'timestamp' }),
    __metadata("design:type", Date)
], Execution.prototype, "execution_timestamp", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'bigint', nullable: true }),
    __metadata("design:type", String)
], Execution.prototype, "execution_time_ms", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'bigint', nullable: true }),
    __metadata("design:type", String)
], Execution.prototype, "records_examined", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'bigint', nullable: true }),
    __metadata("design:type", String)
], Execution.prototype, "records_returned", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'bigint', nullable: true }),
    __metadata("design:type", String)
], Execution.prototype, "dataset_size_rows", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'numeric', precision: 10, scale: 2, nullable: true }),
    __metadata("design:type", Number)
], Execution.prototype, "dataset_size_mb", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], Execution.prototype, "concurrent_sessions", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'bigint', nullable: true }),
    __metadata("design:type", String)
], Execution.prototype, "shared_buffers_hits", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'bigint', nullable: true }),
    __metadata("design:type", String)
], Execution.prototype, "shared_buffers_reads", void 0);
exports.Execution = Execution = __decorate([
    (0, typeorm_1.Entity)('executions')
], Execution);
//# sourceMappingURL=execution.entity.js.map