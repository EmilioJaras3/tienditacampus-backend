"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BenchmarkingModule = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const project_entity_1 = require("./entities/project.entity");
const query_entity_1 = require("./entities/query.entity");
const execution_entity_1 = require("./entities/execution.entity");
const benchmarking_service_1 = require("./benchmarking.service");
const benchmarking_controller_1 = require("./benchmarking.controller");
const oauth_bigquery_service_1 = require("./auth/oauth-bigquery.service");
const snapshot_service_1 = require("./snapshots/snapshot.service");
const snapshot_scheduler_1 = require("./scheduler/snapshot.scheduler");
let BenchmarkingModule = class BenchmarkingModule {
};
exports.BenchmarkingModule = BenchmarkingModule;
exports.BenchmarkingModule = BenchmarkingModule = __decorate([
    (0, common_1.Module)({
        imports: [
            typeorm_1.TypeOrmModule.forFeature([project_entity_1.Project, query_entity_1.Query, execution_entity_1.Execution]),
        ],
        providers: [benchmarking_service_1.BenchmarkingService, oauth_bigquery_service_1.OAuthBigQueryService, snapshot_service_1.SnapshotService, snapshot_scheduler_1.SnapshotScheduler],
        controllers: [benchmarking_controller_1.BenchmarkingController],
        exports: [benchmarking_service_1.BenchmarkingService],
    })
], BenchmarkingModule);
//# sourceMappingURL=benchmarking.module.js.map