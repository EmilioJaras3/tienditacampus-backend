"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CloseDayUseCase = void 0;
const common_1 = require("@nestjs/common");
const sales_repository_1 = require("../repositories/sales.repository");
const audit_service_1 = require("../../audit/audit.service");
let CloseDayUseCase = class CloseDayUseCase {
    constructor(salesRepository, auditService) {
        this.salesRepository = salesRepository;
        this.auditService = auditService;
    }
    async execute(user, wastes) {
        const dailySale = await this.salesRepository.findToday(user.id);
        if (!dailySale)
            throw new common_1.NotFoundException('No hay venta abierta hoy');
        if (dailySale.isClosed)
            throw new common_1.BadRequestException('El día ya está cerrado');
        for (const item of wastes) {
            const detail = dailySale.details.find(d => d.productId === item.productId);
            if (detail) {
                const waste = Number(item.waste);
                if (waste > detail.quantityPrepared) {
                    throw new common_1.BadRequestException(`Merma (${waste}) no puede exceder preparado (${detail.quantityPrepared}) para ${detail.product.name}`);
                }
                detail.quantityLost = waste;
                detail.quantitySold = detail.quantityPrepared - waste;
                detail.wasteReason = item.wasteReason || null;
                detail.wasteCost = Number(detail.unitCost) * waste;
                const unitsSold = detail.quantitySold;
                if (unitsSold > 0) {
                    await this.salesRepository.consumeInventory(item.productId, user.id, unitsSold);
                }
            }
        }
        dailySale.isClosed = true;
        const saved = await this.salesRepository.closeDay(dailySale);
        await this.auditService.log({
            action: 'CLOSE_DAY',
            userId: user.id,
            entityType: 'daily_sales',
            entityId: saved.id,
            description: `Cierre de venta realizado para la fecha ${saved.saleDate}`,
            metadata: { items_processed: wastes.length }
        });
        return saved;
    }
};
exports.CloseDayUseCase = CloseDayUseCase;
exports.CloseDayUseCase = CloseDayUseCase = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [sales_repository_1.SalesRepository,
        audit_service_1.AuditService])
], CloseDayUseCase);
//# sourceMappingURL=close-day.use-case.js.map