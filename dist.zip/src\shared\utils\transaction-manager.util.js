"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TransactionManager = void 0;
const typeorm_1 = require("typeorm");
const common_1 = require("@nestjs/common");
let TransactionManager = class TransactionManager {
    constructor(dataSource) {
        this.dataSource = dataSource;
    }
    async execute(operation, errorMessage = 'Operation failed during transaction') {
        const queryRunner = this.dataSource.createQueryRunner();
        await queryRunner.connect();
        await queryRunner.startTransaction();
        try {
            const result = await operation(queryRunner);
            await queryRunner.commitTransaction();
            return result;
        }
        catch (error) {
            await queryRunner.rollbackTransaction();
            console.error(`[TransactionManager] ${errorMessage}:`, error);
            if (error.status && typeof error.status === 'number') {
                throw error;
            }
            throw new common_1.InternalServerErrorException(errorMessage);
        }
        finally {
            await queryRunner.release();
        }
    }
};
exports.TransactionManager = TransactionManager;
exports.TransactionManager = TransactionManager = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [typeorm_1.DataSource])
], TransactionManager);
//# sourceMappingURL=transaction-manager.util.js.map