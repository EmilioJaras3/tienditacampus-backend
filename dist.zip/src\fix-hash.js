"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const core_1 = require("@nestjs/core");
const app_module_1 = require("./app.module");
const users_service_1 = require("./modules/users/users.service");
async function bootstrap() {
    const app = await core_1.NestFactory.createApplicationContext(app_module_1.AppModule);
    const usersService = app.get(users_service_1.UsersService);
    const password = 'IsaacMD78';
    try {
        const tempUser = await usersService.create({
            email: 'temphash@test.com',
            password: password,
            firstName: 'Temp',
            lastName: 'Hash',
            role: 'buyer'
        });
        console.log("=== NEW HASH CREATED ===");
        console.log(tempUser.passwordHash);
        await app.get('DataSource').query(`UPDATE users SET password_hash = $1 WHERE email IN ('jarassanchezl@gmail.com')`, [tempUser.passwordHash]);
        await app.get('DataSource').query(`DELETE FROM users WHERE email = 'temphash@test.com'`);
        console.log("=== UPDATED SUCCESSFULLY ===");
    }
    catch (e) {
        console.error(e);
    }
    await app.close();
}
bootstrap();
//# sourceMappingURL=fix-hash.js.map