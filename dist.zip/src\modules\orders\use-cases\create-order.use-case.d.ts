import { Repository } from 'typeorm';
import { CreateOrderDto } from '../dto/create-order.dto';
import { User } from '../../users/entities/user.entity';
import { Order } from '../entities/order.entity';
import { TransactionManager } from '../../../shared/utils/transaction-manager.util';
export declare class CreateOrderUseCase {
    private readonly orderRepo;
    private readonly transactionManager;
    constructor(orderRepo: Repository<Order>, transactionManager: TransactionManager);
    execute(dto: CreateOrderDto, buyer: User): Promise<Order>;
}
