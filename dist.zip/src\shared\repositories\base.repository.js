"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BaseRepository = void 0;
const common_1 = require("@nestjs/common");
class BaseRepository {
    constructor(repository) {
        this.repository = repository;
    }
    async findById(id) {
        const record = await this.repository.findOne({ where: { id } });
        if (!record) {
            throw new common_1.NotFoundException(`Record with ID ${id} not found`);
        }
        return record;
    }
    async findAll() {
        return await this.repository.find();
    }
    async save(data) {
        return await this.repository.save(data);
    }
    async delete(id) {
        const result = await this.repository.delete(id);
        if (result.affected === 0) {
            throw new common_1.NotFoundException(`Record with ID ${id} not found`);
        }
    }
}
exports.BaseRepository = BaseRepository;
//# sourceMappingURL=base.repository.js.map