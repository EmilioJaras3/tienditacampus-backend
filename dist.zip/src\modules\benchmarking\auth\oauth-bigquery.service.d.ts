import { ConfigService } from '@nestjs/config';
export declare class OAuthBigQueryService {
    private configService;
    private readonly logger;
    private readonly oauth2Client;
    constructor(configService: ConfigService);
    getAuthUrl(): string;
    getTokenFromCode(code: string): Promise<{
        accessToken: string;
        refreshToken?: string;
    }>;
    sendToBigQuery(accessToken: string, rows: Record<string, any>[]): Promise<void>;
    validateToken(token: string): Promise<boolean>;
    private generateState;
}
