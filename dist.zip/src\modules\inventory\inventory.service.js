"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.InventoryService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const inventory_record_entity_1 = require("./entities/inventory-record.entity");
const product_entity_1 = require("../products/entities/product.entity");
const audit_service_1 = require("../audit/audit.service");
let InventoryService = class InventoryService {
    constructor(inventoryRepository, productRepository, auditService) {
        this.inventoryRepository = inventoryRepository;
        this.productRepository = productRepository;
        this.auditService = auditService;
    }
    async addStock(createInventoryDto, user) {
        const product = await this.productRepository.findOne({
            where: { id: createInventoryDto.productId, sellerId: user.id, isActive: true },
        });
        if (!product) {
            throw new common_1.NotFoundException('Producto no encontrado para el vendedor autenticado');
        }
        let expiresAt = null;
        if (product.isPerishable && product.shelfLifeDays !== null && product.shelfLifeDays !== undefined) {
            const baseDateStr = createInventoryDto.recordDate || new Date().toISOString().split('T')[0];
            const [year, month, day] = baseDateStr.split('-').map(Number);
            const baseDate = new Date(Date.UTC(year, month - 1, day));
            baseDate.setUTCDate(baseDate.getUTCDate() + product.shelfLifeDays);
            expiresAt = baseDate.toISOString().split('T')[0];
        }
        const record = this.inventoryRepository.create({
            ...createInventoryDto,
            expiresAt,
            quantityInitial: createInventoryDto.quantity,
            quantityRemaining: createInventoryDto.quantity,
            unitCost: createInventoryDto.unitCost,
            investmentAmount: createInventoryDto.quantity * createInventoryDto.unitCost,
            seller: user,
            sellerId: user.id,
            status: 'active',
        });
        const saved = await this.inventoryRepository.save(record);
        await this.auditService.log({
            action: 'ADD_STOCK',
            userId: user.id,
            entityType: 'inventory_records',
            entityId: saved.id,
            description: `Stock añadido: ${saved.quantityInitial} unidades para el producto ${product.name}`,
            metadata: { quantity: saved.quantityInitial, unitCost: saved.unitCost }
        });
        return saved;
    }
    async getHistoryByProduct(productId, user) {
        return await this.inventoryRepository.find({
            where: { productId, sellerId: user.id },
            order: { createdAt: 'DESC' },
        });
    }
    async consumeFIFO(productId, sellerId, quantity, manager) {
        if (quantity <= 0)
            return 0;
        const activeLots = await manager
            .createQueryBuilder(inventory_record_entity_1.InventoryRecord, 'ir')
            .where('ir.product_id = :productId', { productId })
            .andWhere('ir.seller_id = :sellerId', { sellerId })
            .andWhere('ir.status = :status', { status: 'active' })
            .andWhere('ir.quantity_remaining > 0')
            .orderBy('ir.record_date', 'ASC')
            .addOrderBy('ir.expires_at', 'ASC', 'NULLS LAST')
            .getMany();
        const totalAvailable = activeLots.reduce((sum, lot) => sum + lot.quantityRemaining, 0);
        if (totalAvailable < quantity) {
            throw new common_1.BadRequestException(`Stock insuficiente para producto ${productId}. ` +
                `Disponible: ${totalAvailable}, Requerido: ${quantity}`);
        }
        let remaining = quantity;
        let totalConsumed = 0;
        for (const lot of activeLots) {
            if (remaining <= 0)
                break;
            const canConsume = Math.min(lot.quantityRemaining, remaining);
            lot.quantityRemaining -= canConsume;
            remaining -= canConsume;
            totalConsumed += canConsume;
            if (lot.quantityRemaining === 0) {
                lot.status = 'sold_out';
            }
            await manager.save(inventory_record_entity_1.InventoryRecord, lot);
        }
        return totalConsumed;
    }
};
exports.InventoryService = InventoryService;
exports.InventoryService = InventoryService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(inventory_record_entity_1.InventoryRecord)),
    __param(1, (0, typeorm_1.InjectRepository)(product_entity_1.Product)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository,
        audit_service_1.AuditService])
], InventoryService);
//# sourceMappingURL=inventory.service.js.map