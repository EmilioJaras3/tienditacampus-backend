import { DataSource } from 'typeorm';
import { OAuthBigQueryService } from '../auth/oauth-bigquery.service';
export declare class SnapshotService {
    private dataSource;
    private oauthService;
    private readonly logger;
    constructor(dataSource: DataSource, oauthService: OAuthBigQueryService);
    executeDailySnapshot(accessToken: string): Promise<void>;
    private queryDailyExport;
    private serializeRows;
    private resetStatistics;
    exportToCSV(projectId: number): Promise<string>;
    private rowsToCSV;
}
