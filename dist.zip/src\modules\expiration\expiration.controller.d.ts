import { ExpirationService } from './expiration.service';
export declare class ExpirationController {
    private readonly expirationService;
    constructor(expirationService: ExpirationService);
    runManual(): Promise<{
        lotsExpired: number;
        totalUnitsLost: number;
        totalWasteCost: number;
        message: string;
    }>;
}
