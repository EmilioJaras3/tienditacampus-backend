export declare class CloseDayItemDto {
    productId: string;
    waste: number;
    wasteReason?: 'expired' | 'damaged' | 'other';
}
export declare class CloseDayDto {
    items: CloseDayItemDto[];
}
