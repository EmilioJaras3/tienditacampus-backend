export declare class CreateInventoryRecordDto {
    productId: string;
    quantity: number;
    unitCost: number;
    recordDate?: string;
}
