import { ConfigService } from '@nestjs/config';
export declare class MailerService {
    private readonly configService;
    private readonly logger;
    private transporter;
    constructor(configService: ConfigService);
    private initTransporter;
    sendMail(to: string, subject: string, html: string): Promise<boolean>;
    send2faCode(email: string, code: string): Promise<void>;
    sendVerificationCode(to: string, code: string): Promise<boolean>;
}
