import { Repository } from 'typeorm';
import { Order } from '../entities/order.entity';
import { User } from '../../users/entities/user.entity';
import { InventoryService } from '../../inventory/inventory.service';
import { TransactionManager } from '../../../shared/utils/transaction-manager.util';
export declare class DeliverOrderUseCase {
    private readonly orderRepo;
    private readonly inventoryService;
    private readonly transactionManager;
    constructor(orderRepo: Repository<Order>, inventoryService: InventoryService, transactionManager: TransactionManager);
    execute(orderId: string, user: User): Promise<Order>;
    private syncDailySale;
    private recalculateAggregates;
    private getUnitCost;
}
