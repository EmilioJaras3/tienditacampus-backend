"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.WeeklyReport = void 0;
const typeorm_1 = require("typeorm");
const user_entity_1 = require("../../users/entities/user.entity");
const product_entity_1 = require("../../products/entities/product.entity");
let WeeklyReport = class WeeklyReport {
};
exports.WeeklyReport = WeeklyReport;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('uuid'),
    __metadata("design:type", String)
], WeeklyReport.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'seller_id' }),
    __metadata("design:type", String)
], WeeklyReport.prototype, "sellerId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => user_entity_1.User),
    (0, typeorm_1.JoinColumn)({ name: 'seller_id' }),
    __metadata("design:type", user_entity_1.User)
], WeeklyReport.prototype, "seller", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'date', name: 'week_start' }),
    __metadata("design:type", String)
], WeeklyReport.prototype, "weekStart", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'date', name: 'week_end' }),
    __metadata("design:type", String)
], WeeklyReport.prototype, "weekEnd", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 10, scale: 2, name: 'total_investment', default: 0 }),
    __metadata("design:type", Number)
], WeeklyReport.prototype, "totalInvestment", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 10, scale: 2, name: 'total_revenue', default: 0 }),
    __metadata("design:type", Number)
], WeeklyReport.prototype, "totalRevenue", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 10, scale: 2, name: 'total_profit', default: 0 }),
    __metadata("design:type", Number)
], WeeklyReport.prototype, "totalProfit", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 5, scale: 2, name: 'avg_profit_margin', default: 0 }),
    __metadata("design:type", Number)
], WeeklyReport.prototype, "avgProfitMargin", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'numeric', precision: 10, scale: 2, default: 0, name: 'total_waste_cost' }),
    __metadata("design:type", Number)
], WeeklyReport.prototype, "totalWasteCost", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', name: 'total_units_sold', default: 0 }),
    __metadata("design:type", Number)
], WeeklyReport.prototype, "totalUnitsSold", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', name: 'total_units_lost', default: 0 }),
    __metadata("design:type", Number)
], WeeklyReport.prototype, "totalUnitsLost", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 5, scale: 2, name: 'loss_percentage', default: 0 }),
    __metadata("design:type", Number)
], WeeklyReport.prototype, "lossPercentage", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'uuid', name: 'best_selling_product', nullable: true }),
    __metadata("design:type", Object)
], WeeklyReport.prototype, "bestSellingProductId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => product_entity_1.Product),
    (0, typeorm_1.JoinColumn)({ name: 'best_selling_product' }),
    __metadata("design:type", Object)
], WeeklyReport.prototype, "bestSellingProduct", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'jsonb', name: 'demand_prediction', nullable: true }),
    __metadata("design:type", Object)
], WeeklyReport.prototype, "demandPrediction", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ type: 'timestamptz', name: 'created_at' }),
    __metadata("design:type", Date)
], WeeklyReport.prototype, "createdAt", void 0);
exports.WeeklyReport = WeeklyReport = __decorate([
    (0, typeorm_1.Entity)('weekly_reports'),
    (0, typeorm_1.Unique)(['sellerId', 'weekStart'])
], WeeklyReport);
//# sourceMappingURL=weekly-report.entity.js.map