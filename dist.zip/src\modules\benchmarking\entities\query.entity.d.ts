import { Project } from './project.entity';
import { Execution } from './execution.entity';
export declare enum QueryType {
    SIMPLE_SELECT = "SIMPLE_SELECT",
    AGGREGATION = "AGGREGATION",
    JOIN = "JOIN",
    WINDOW_FUNCTION = "WINDOW_FUNCTION",
    SUBQUERY = "SUBQUERY",
    WRITE_OPERATION = "WRITE_OPERATION"
}
export declare class Query {
    query_id: number;
    project_id: number;
    project: Project;
    query_description: string;
    query_sql: string;
    target_table: string;
    query_type: QueryType;
    executions: Execution[];
}
