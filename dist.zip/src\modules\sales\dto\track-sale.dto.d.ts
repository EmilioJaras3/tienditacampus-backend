export declare class TrackSaleDto {
    productId: string;
    quantitySold: number;
    quantityLost: number;
}
