import { AuthService } from './auth.service';
import { LoginDto } from './dto/login.dto';
import { RegisterDto } from './dto/register.dto';
import { GoogleLoginDto } from './dto/google-login.dto';
import { VerifyTwoFactorDto } from './dto/verify-2fa.dto';
import { ResendTwoFactorDto } from './dto/resend-2fa.dto';
import { RescueAdminDto } from './dto/rescue-admin.dto';
import { VerifyEmailDto } from './dto/verify-email.dto';
export declare class AuthController {
    private readonly authService;
    constructor(authService: AuthService);
    register(dto: RegisterDto): Promise<{
        user: {
            id: string;
            email: string;
            firstName: string;
            lastName: string;
            role: "admin" | "seller" | "buyer";
        };
        accessToken: string;
    }>;
    login(dto: LoginDto): Promise<{
        requiresTwoFactor: boolean;
        message: string;
    }>;
    verify2fa(dto: VerifyTwoFactorDto): Promise<{
        user: {
            id: string;
            email: string;
            firstName: string;
            lastName: string;
            role: "admin" | "seller" | "buyer";
            lastLoginAt: string;
            loginCount: number;
        };
        accessToken: string;
    }>;
    resend2fa(dto: ResendTwoFactorDto): Promise<{
        message: string;
    }>;
    googleLogin(dto: GoogleLoginDto): Promise<{
        user: {
            id: string;
            email: string;
            firstName: string;
            lastName: string;
            role: "admin" | "seller" | "buyer";
            lastLoginAt: string;
            loginCount: number;
        };
        accessToken: string;
    }>;
    getProfile(user: any): Promise<{
        id: string;
        email: string;
        firstName: string;
        lastName: string;
        phone: string | null;
        avatarUrl: string | null;
        role: "admin" | "seller" | "buyer";
        isEmailVerified: boolean;
        lastLoginAt: Date | null;
        loginCount: number;
        createdAt: Date;
    }>;
    rescueAdmin(dto: RescueAdminDto): Promise<{
        message: string;
    }>;
    verifyEmail(dto: VerifyEmailDto): Promise<{
        message: string;
    }>;
}
