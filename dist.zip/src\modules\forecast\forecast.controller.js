"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ForecastController = void 0;
const common_1 = require("@nestjs/common");
const forecast_service_1 = require("./forecast.service");
const jwt_auth_guard_1 = require("../../common/guards/jwt-auth.guard");
const roles_guard_1 = require("../../common/guards/roles.guard");
const roles_decorator_1 = require("../../common/decorators/roles.decorator");
let ForecastController = class ForecastController {
    constructor(forecastService) {
        this.forecastService = forecastService;
    }
    async getForecast(productId, dayOfWeek) {
        if (dayOfWeek < 1 || dayOfWeek > 7) {
            throw new common_1.BadRequestException('dayOfWeek inválido. Debe ser entre 1 (Lunes) y 7 (Domingo)');
        }
        const recommendedQuantity = await this.forecastService.getForecast(productId, dayOfWeek);
        return {
            productId,
            dayOfWeek,
            recommendedQuantity
        };
    }
};
exports.ForecastController = ForecastController;
__decorate([
    (0, common_1.Get)(':productId/day/:dayOfWeek'),
    __param(0, (0, common_1.Param)('productId')),
    __param(1, (0, common_1.Param)('dayOfWeek', common_1.ParseIntPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Number]),
    __metadata("design:returntype", Promise)
], ForecastController.prototype, "getForecast", null);
exports.ForecastController = ForecastController = __decorate([
    (0, common_1.Controller)('forecast'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, roles_guard_1.RolesGuard),
    (0, roles_decorator_1.Roles)('seller', 'admin'),
    __metadata("design:paramtypes", [forecast_service_1.ForecastService])
], ForecastController);
//# sourceMappingURL=forecast.controller.js.map