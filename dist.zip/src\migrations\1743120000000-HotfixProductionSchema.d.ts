import { MigrationInterface, QueryRunner } from 'typeorm';
export declare class HotfixProductionSchema1743120000000 implements MigrationInterface {
    name: string;
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
