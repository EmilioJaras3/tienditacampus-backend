import { User } from '../../users/entities/user.entity';
import { Product } from '../../products/entities/product.entity';
export declare class InventoryRecord {
    id: string;
    sellerId: string;
    seller: User;
    productId: string;
    product: Product;
    recordDate: string;
    quantityInitial: number;
    quantityRemaining: number;
    investmentAmount: number;
    unitCost: number;
    status: 'active' | 'sold_out' | 'expired' | 'closed';
    expiresAt: string | null;
    createdAt: Date;
    updatedAt: Date;
}
