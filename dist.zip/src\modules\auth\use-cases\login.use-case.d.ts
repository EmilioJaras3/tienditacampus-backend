import { JwtService } from '@nestjs/jwt';
import { UsersService } from '../../users/users.service';
import { AuditService } from '../../audit/audit.service';
import { LoginDto } from '../dto/login.dto';
export declare class LoginUseCase {
    private readonly usersService;
    private readonly jwtService;
    private readonly auditService;
    constructor(usersService: UsersService, jwtService: JwtService, auditService: AuditService);
    execute(dto: LoginDto): Promise<{
        user: {
            id: string;
            email: string;
            firstName: string;
            lastName: string;
            role: "admin" | "seller" | "buyer";
        };
        requiresTwoFactor: boolean;
    }>;
}
