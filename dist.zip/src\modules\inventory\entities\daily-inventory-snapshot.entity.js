"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DailyInventorySnapshot = void 0;
const typeorm_1 = require("typeorm");
const user_entity_1 = require("../../users/entities/user.entity");
const product_entity_1 = require("../../products/entities/product.entity");
let DailyInventorySnapshot = class DailyInventorySnapshot {
};
exports.DailyInventorySnapshot = DailyInventorySnapshot;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('uuid'),
    __metadata("design:type", String)
], DailyInventorySnapshot.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'seller_id' }),
    __metadata("design:type", String)
], DailyInventorySnapshot.prototype, "sellerId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => user_entity_1.User),
    (0, typeorm_1.JoinColumn)({ name: 'seller_id' }),
    __metadata("design:type", user_entity_1.User)
], DailyInventorySnapshot.prototype, "seller", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'product_id' }),
    __metadata("design:type", String)
], DailyInventorySnapshot.prototype, "productId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => product_entity_1.Product),
    (0, typeorm_1.JoinColumn)({ name: 'product_id' }),
    __metadata("design:type", product_entity_1.Product)
], DailyInventorySnapshot.prototype, "product", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'date', name: 'snapshot_date', default: () => 'CURRENT_DATE' }),
    __metadata("design:type", String)
], DailyInventorySnapshot.prototype, "snapshotDate", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', name: 'opening_stock' }),
    __metadata("design:type", Number)
], DailyInventorySnapshot.prototype, "openingStock", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0, name: 'units_sold' }),
    __metadata("design:type", Number)
], DailyInventorySnapshot.prototype, "unitsSold", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0, name: 'units_wasted' }),
    __metadata("design:type", Number)
], DailyInventorySnapshot.prototype, "unitsWasted", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0, name: 'closing_stock' }),
    __metadata("design:type", Number)
], DailyInventorySnapshot.prototype, "closingStock", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 10, scale: 2, default: 0, name: 'waste_value' }),
    __metadata("design:type", Number)
], DailyInventorySnapshot.prototype, "wasteValue", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'decimal',
        precision: 5,
        scale: 2,
        name: 'waste_percentage',
        generatedType: 'STORED',
        asExpression: 'CASE WHEN opening_stock > 0 THEN (units_wasted::NUMERIC / opening_stock) * 100 ELSE 0 END',
        insert: false,
        update: false,
    }),
    __metadata("design:type", Number)
], DailyInventorySnapshot.prototype, "wastePercentage", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ type: 'timestamptz', name: 'created_at' }),
    __metadata("design:type", Date)
], DailyInventorySnapshot.prototype, "createdAt", void 0);
exports.DailyInventorySnapshot = DailyInventorySnapshot = __decorate([
    (0, typeorm_1.Entity)('daily_inventory_snapshots')
], DailyInventorySnapshot);
//# sourceMappingURL=daily-inventory-snapshot.entity.js.map