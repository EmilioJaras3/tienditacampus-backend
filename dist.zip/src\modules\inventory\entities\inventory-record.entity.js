"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.InventoryRecord = void 0;
const typeorm_1 = require("typeorm");
const user_entity_1 = require("../../users/entities/user.entity");
const product_entity_1 = require("../../products/entities/product.entity");
let InventoryRecord = class InventoryRecord {
};
exports.InventoryRecord = InventoryRecord;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('uuid'),
    __metadata("design:type", String)
], InventoryRecord.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'seller_id' }),
    __metadata("design:type", String)
], InventoryRecord.prototype, "sellerId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => user_entity_1.User),
    (0, typeorm_1.JoinColumn)({ name: 'seller_id' }),
    __metadata("design:type", user_entity_1.User)
], InventoryRecord.prototype, "seller", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'product_id' }),
    __metadata("design:type", String)
], InventoryRecord.prototype, "productId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => product_entity_1.Product),
    (0, typeorm_1.JoinColumn)({ name: 'product_id' }),
    __metadata("design:type", product_entity_1.Product)
], InventoryRecord.prototype, "product", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'date', name: 'record_date', default: () => 'CURRENT_DATE' }),
    __metadata("design:type", String)
], InventoryRecord.prototype, "recordDate", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', name: 'quantity_initial' }),
    __metadata("design:type", Number)
], InventoryRecord.prototype, "quantityInitial", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0, name: 'quantity_remaining' }),
    __metadata("design:type", Number)
], InventoryRecord.prototype, "quantityRemaining", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 10, scale: 2, name: 'investment_amount' }),
    __metadata("design:type", Number)
], InventoryRecord.prototype, "investmentAmount", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 10, scale: 2, name: 'unit_cost', default: 0 }),
    __metadata("design:type", Number)
], InventoryRecord.prototype, "unitCost", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'varchar',
        length: 20,
        default: 'active',
    }),
    __metadata("design:type", String)
], InventoryRecord.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'date',
        nullable: true,
        name: 'expires_at',
        comment: 'Fecha de caducidad del lote = record_date + product.shelf_life_days',
    }),
    __metadata("design:type", Object)
], InventoryRecord.prototype, "expiresAt", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ type: 'timestamptz', name: 'created_at' }),
    __metadata("design:type", Date)
], InventoryRecord.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({ type: 'timestamptz', name: 'updated_at' }),
    __metadata("design:type", Date)
], InventoryRecord.prototype, "updatedAt", void 0);
exports.InventoryRecord = InventoryRecord = __decorate([
    (0, typeorm_1.Entity)('inventory_records')
], InventoryRecord);
//# sourceMappingURL=inventory-record.entity.js.map