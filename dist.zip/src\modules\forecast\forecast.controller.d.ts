import { ForecastService } from './forecast.service';
export declare class ForecastController {
    private readonly forecastService;
    constructor(forecastService: ForecastService);
    getForecast(productId: string, dayOfWeek: number): Promise<{
        productId: string;
        dayOfWeek: number;
        recommendedQuantity: number;
    }>;
}
