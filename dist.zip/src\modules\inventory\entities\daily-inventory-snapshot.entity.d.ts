import { User } from '../../users/entities/user.entity';
import { Product } from '../../products/entities/product.entity';
export declare class DailyInventorySnapshot {
    id: string;
    sellerId: string;
    seller: User;
    productId: string;
    product: Product;
    snapshotDate: string;
    openingStock: number;
    unitsSold: number;
    unitsWasted: number;
    closingStock: number;
    wasteValue: number;
    wastePercentage: number;
    createdAt: Date;
}
