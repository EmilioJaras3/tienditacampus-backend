"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.HotfixProductionSchema1743120000000 = void 0;
class HotfixProductionSchema1743120000000 {
    constructor() {
        this.name = 'HotfixProductionSchema1743120000000';
    }
    async up(queryRunner) {
        await queryRunner.query(`ALTER TABLE "products" ALTER COLUMN "image_url" TYPE text`);
        await queryRunner.query(`ALTER TABLE "inventory_records" ADD COLUMN IF NOT EXISTS "unit_cost" numeric(10,2) NOT NULL DEFAULT 0`);
    }
    async down(queryRunner) {
        await queryRunner.query(`ALTER TABLE "products" ALTER COLUMN "image_url" TYPE character varying(500)`);
        await queryRunner.query(`ALTER TABLE "inventory_records" DROP COLUMN "unit_cost"`);
    }
}
exports.HotfixProductionSchema1743120000000 = HotfixProductionSchema1743120000000;
//# sourceMappingURL=1743120000000-HotfixProductionSchema.js.map