"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SalesRepository = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const daily_sale_entity_1 = require("../entities/daily-sale.entity");
const sale_detail_entity_1 = require("../entities/sale-detail.entity");
const product_entity_1 = require("../../products/entities/product.entity");
const base_repository_1 = require("../../../shared/repositories/base.repository");
let SalesRepository = class SalesRepository extends base_repository_1.BaseRepository {
    constructor(dailySaleRepository, saleDetailRepository, productRepository) {
        super(dailySaleRepository);
        this.dailySaleRepository = dailySaleRepository;
        this.saleDetailRepository = saleDetailRepository;
        this.productRepository = productRepository;
    }
    async findToday(sellerId) {
        return await this.dailySaleRepository.findOne({
            where: {
                sellerId,
                saleDate: new Date().toISOString().split('T')[0],
            },
            relations: ['details', 'details.product'],
        });
    }
    async createDailySale(dailySale, details) {
        const savedSale = await this.dailySaleRepository.save(dailySale);
        for (const detail of details) {
            detail.dailySale = savedSale;
            await this.saleDetailRepository.save(detail);
        }
        const result = await this.findSaleWithDetails(savedSale.id);
        if (!result) {
            throw new Error('Failed to create daily sale');
        }
        return result;
    }
    async saveSaleDetail(detail) {
        return await this.saleDetailRepository.save(detail);
    }
    async findSaleWithDetails(id) {
        return await this.dailySaleRepository.findOne({
            where: { id },
            relations: ['details'],
        });
    }
    async updateSale(id, updates) {
        await this.dailySaleRepository.update(id, updates);
    }
    async getROI(sellerId) {
        const result = await this.dailySaleRepository.query(`
      SELECT 
        COALESCE(SUM(total_investment), 0)::numeric(12,2) as global_investment,
        COALESCE(SUM(total_revenue), 0)::numeric(12,2) as global_revenue,
        (COALESCE(SUM(total_revenue), 0) - COALESCE(SUM(total_investment), 0))::numeric(12,2) as global_net_profit,
        CASE 
          WHEN COALESCE(SUM(total_investment), 0) > 0 
          THEN ROUND(((COALESCE(SUM(total_revenue), 0) - COALESCE(SUM(total_investment), 0)) / COALESCE(SUM(total_investment), 0)) * 100, 2)
          ELSE 0 
        END::numeric(5,2) as global_roi_pct
      FROM daily_sales
      WHERE seller_id = $1
      `, [sellerId]);
        if (!result || result.length === 0) {
            return { investment: 0, revenue: 0, netProfit: 0, roi: 0 };
        }
        const data = result[0];
        return {
            investment: Number(data.global_investment),
            revenue: Number(data.global_revenue),
            netProfit: Number(data.global_net_profit),
            roi: Number(data.global_roi_pct),
        };
    }
    async getHistory(sellerId, page = 1, limit = 20) {
        const [data, total] = await this.dailySaleRepository.findAndCount({
            where: { sellerId },
            order: { saleDate: 'DESC' },
            skip: (page - 1) * limit,
            take: limit,
            relations: ['details', 'details.product'],
        });
        return { data, total, page, limit };
    }
    async getByWeekdayAnalytics(sellerId, startDate, endDate) {
        const params = [sellerId];
        let where = 'WHERE ds.seller_id = $1';
        if (startDate) {
            params.push(startDate);
            where += ` AND ds.sale_date >= $${params.length}`;
        }
        if (endDate) {
            params.push(endDate);
            where += ` AND ds.sale_date <= $${params.length}`;
        }
        const rows = await this.dailySaleRepository.query(`
      SELECT
        EXTRACT(DOW FROM ds.sale_date)::int AS weekday,
        COUNT(*)::int AS days_count,
        COALESCE(SUM(ds.total_revenue), 0)::numeric(12,2) AS revenue_sum,
        COALESCE(SUM(ds.units_sold), 0)::int AS units_sold_sum,
        COALESCE(AVG(ds.total_revenue), 0)::numeric(12,2) AS revenue_avg
      FROM daily_sales ds
      ${where}
      GROUP BY EXTRACT(DOW FROM ds.sale_date)
      ORDER BY weekday ASC
      `, params);
        const weekdayName = {
            0: 'domingo',
            1: 'lunes',
            2: 'martes',
            3: 'miercoles',
            4: 'jueves',
            5: 'viernes',
            6: 'sabado',
        };
        return rows.map((row) => ({
            weekday: Number(row.weekday),
            weekdayName: weekdayName[Number(row.weekday)] ?? 'desconocido',
            daysCount: Number(row.days_count),
            revenueSum: row.revenue_sum,
            unitsSoldSum: Number(row.units_sold_sum),
            revenueAvg: row.revenue_avg,
        }));
    }
    async getPrediction(sellerId) {
        const today = new Date().getDay();
        const history = await this.dailySaleRepository.query(`
      SELECT
        sd.product_id,
        p.name as product_name,
        sd.quantity_sold
      FROM sale_details sd
      INNER JOIN daily_sales ds ON ds.id = sd.daily_sale_id
      INNER JOIN products p ON p.id = sd.product_id
      WHERE ds.seller_id = $1
      AND EXTRACT(DOW FROM ds.sale_date) = $2
      AND ds.sale_date < CURRENT_DATE
      ORDER BY sd.product_id, ds.sale_date DESC
      LIMIT 100
    `, [sellerId, today]);
        const productSales = {};
        const productNames = {};
        history.forEach((row) => {
            if (!productSales[row.product_id]) {
                productSales[row.product_id] = [];
                productNames[row.product_id] = row.product_name;
            }
            productSales[row.product_id].push(Number(row.quantity_sold));
        });
        const suggestions = Object.keys(productSales).map(productId => {
            const sales = productSales[productId];
            if (sales.length < 3)
                return null;
            sales.sort((a, b) => a - b);
            const q1 = sales[Math.floor((sales.length / 4))];
            const q3 = sales[Math.floor((sales.length * (3 / 4)))];
            const iqr = q3 - q1;
            const lower = q1 - 1.5 * iqr;
            const upper = q3 + 1.5 * iqr;
            const filtered = sales.filter(x => x >= lower && x <= upper);
            const avg = filtered.reduce((a, b) => a + b, 0) / filtered.length;
            return {
                productId,
                productName: productNames[productId],
                suggested: Math.ceil(avg),
                confidence: filtered.length / sales.length
            };
        }).filter(x => x !== null);
        return suggestions.length > 0 ? suggestions[0] : null;
    }
    async findProduct(productId) {
        return await this.productRepository.findOne({ where: { id: productId } });
    }
    async consumeInventory(productId, userId, units) {
        console.log(`Consuming ${units} units of product ${productId} for user ${userId}`);
    }
    async closeDay(dailySale) {
        let totalRevenue = 0;
        let unitsSold = 0;
        let unitsLost = 0;
        let totalWasteCost = 0;
        for (const detail of dailySale.details) {
            totalRevenue += Number(detail.unitPrice) * detail.quantitySold;
            unitsSold += detail.quantitySold;
            unitsLost += detail.quantityLost;
            totalWasteCost += Number(detail.wasteCost || 0);
        }
        dailySale.totalRevenue = totalRevenue;
        dailySale.unitsSold = unitsSold;
        dailySale.unitsLost = unitsLost;
        dailySale.totalWasteCost = totalWasteCost;
        const profit = totalRevenue - Number(dailySale.totalInvestment);
        dailySale.profitMargin = totalRevenue > 0 ? (profit / totalRevenue) * 100 : 0;
        if (dailySale.unitsSold > 0) {
            const avgSalePrice = totalRevenue / dailySale.unitsSold;
            const unitsPrepared = dailySale.unitsSold + dailySale.unitsLost;
            const avgUnitCost = unitsPrepared > 0 ? Number(dailySale.totalInvestment) / unitsPrepared : 0;
            const wasteRate = unitsPrepared > 0 ? dailySale.unitsLost / unitsPrepared : 0;
            const effectiveUnitCost = avgUnitCost * (1 + wasteRate);
            const unitMargin = avgSalePrice - effectiveUnitCost;
            if (unitMargin > 0) {
                dailySale.breakEvenUnits = Number((Number(dailySale.totalInvestment) / unitMargin).toFixed(2));
            }
            else {
                dailySale.breakEvenUnits = null;
            }
        }
        else {
            dailySale.breakEvenUnits = null;
        }
        return await this.dailySaleRepository.save(dailySale);
    }
};
exports.SalesRepository = SalesRepository;
exports.SalesRepository = SalesRepository = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(daily_sale_entity_1.DailySale)),
    __param(1, (0, typeorm_1.InjectRepository)(sale_detail_entity_1.SaleDetail)),
    __param(2, (0, typeorm_1.InjectRepository)(product_entity_1.Product)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository])
], SalesRepository);
//# sourceMappingURL=sales.repository.js.map