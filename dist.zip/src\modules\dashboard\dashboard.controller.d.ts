import { DashboardService } from './dashboard.service';
import { DashboardComparisonQueryDto } from './dto/dashboard-comparison-query.dto';
export declare class DashboardController {
    private readonly dashboardService;
    constructor(dashboardService: DashboardService);
    getComparison(req: any, query: DashboardComparisonQueryDto): Promise<{
        weekComparison: any;
        monthComparison: any;
        profitabilityByProduct: any;
    }>;
}
