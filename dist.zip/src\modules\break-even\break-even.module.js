"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BreakEvenModule = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const product_entity_1 = require("../products/entities/product.entity");
const break_even_controller_1 = require("./break-even.controller");
const break_even_service_1 = require("./break-even.service");
let BreakEvenModule = class BreakEvenModule {
};
exports.BreakEvenModule = BreakEvenModule;
exports.BreakEvenModule = BreakEvenModule = __decorate([
    (0, common_1.Module)({
        imports: [typeorm_1.TypeOrmModule.forFeature([product_entity_1.Product])],
        controllers: [break_even_controller_1.BreakEvenController],
        providers: [break_even_service_1.BreakEvenService],
        exports: [break_even_service_1.BreakEvenService],
    })
], BreakEvenModule);
//# sourceMappingURL=break-even.module.js.map