"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var CategorySeedService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.CategorySeedService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const category_entity_1 = require("./entities/category.entity");
let CategorySeedService = CategorySeedService_1 = class CategorySeedService {
    constructor(categoryRepository) {
        this.categoryRepository = categoryRepository;
        this.logger = new common_1.Logger(CategorySeedService_1.name);
    }
    async onApplicationBootstrap() {
        const categories = [
            { name: 'Snacks y Comidas', description: 'Todo tipo de snacks y alimentos preparados' },
            { name: 'Bebidas', description: 'Jugos, refrescos y agua' },
            { name: 'Postres', description: 'Dulces, pasteles y postres variados' },
        ];
        for (const catData of categories) {
            const existing = await this.categoryRepository.findOne({ where: { name: catData.name } });
            if (!existing) {
                const category = this.categoryRepository.create(catData);
                await this.categoryRepository.save(category);
                this.logger.log(`Category created: ${catData.name}`);
            }
        }
    }
};
exports.CategorySeedService = CategorySeedService;
exports.CategorySeedService = CategorySeedService = CategorySeedService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(category_entity_1.Category)),
    __metadata("design:paramtypes", [typeorm_2.Repository])
], CategorySeedService);
//# sourceMappingURL=category-seed.service.js.map