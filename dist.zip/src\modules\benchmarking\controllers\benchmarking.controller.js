"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var BenchmarkingController_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.BenchmarkingController = void 0;
const common_1 = require("@nestjs/common");
const oauth_bigquery_service_1 = require("../auth/oauth-bigquery.service");
const snapshot_service_1 = require("../snapshots/snapshot.service");
let BenchmarkingController = BenchmarkingController_1 = class BenchmarkingController {
    constructor(oauthService, snapshotService) {
        this.oauthService = oauthService;
        this.snapshotService = snapshotService;
        this.logger = new common_1.Logger(BenchmarkingController_1.name);
    }
    googleAuth() {
        const authUrl = this.oauthService.getAuthUrl();
        return { url: authUrl };
    }
    async googleCallback(code, state, res) {
        try {
            if (!code) {
                return res.status(400).send('❌ No authorization code provided');
            }
            const tokens = await this.oauthService.getTokenFromCode(code);
            this.logger.log('✅ Usuario autenticado exitosamente');
            res.redirect(`/dashboard/benchmarking?token=${tokens.accessToken}`);
        }
        catch (error) {
            this.logger.error('❌ Error en OAuth callback:', error.message);
            res.status(500).send(`❌ Authentication failed: ${error.message}`);
        }
    }
    async executeSnapshot(body, res) {
        try {
            const { accessToken } = body;
            if (!accessToken) {
                return res.status(400).json({ error: 'Access token required' });
            }
            await this.snapshotService.executeDailySnapshot(accessToken);
            res.json({
                success: true,
                message: '✅ Snapshot ejecutado y datos enviados a BigQuery',
                timestamp: new Date().toISOString(),
            });
        }
        catch (error) {
            this.logger.error('❌ Error en snapshot:', error.message);
            res.status(500).json({
                success: false,
                error: error.message,
            });
        }
    }
    async exportCSV(projectId, res) {
        try {
            const csv = await this.snapshotService.exportToCSV(projectId);
            const filename = `project_${projectId}_${new Date().toISOString().split('T')[0]}.csv`;
            res.setHeader('Content-Type', 'text/csv; charset=utf-8');
            res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
            res.send(csv);
        }
        catch (error) {
            this.logger.error('❌ Error al exportar CSV:', error.message);
            res.status(500).json({ error: error.message });
        }
    }
};
exports.BenchmarkingController = BenchmarkingController;
__decorate([
    (0, common_1.Get)('auth/google'),
    (0, common_1.Redirect)(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], BenchmarkingController.prototype, "googleAuth", null);
__decorate([
    (0, common_1.Get)('auth/callback'),
    __param(0, (0, common_1.Query)('code')),
    __param(1, (0, common_1.Query)('state')),
    __param(2, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object]),
    __metadata("design:returntype", Promise)
], BenchmarkingController.prototype, "googleCallback", null);
__decorate([
    (0, common_1.Post)('snapshots/execute'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], BenchmarkingController.prototype, "executeSnapshot", null);
__decorate([
    (0, common_1.Get)('snapshots/export/:projectId'),
    __param(0, (0, common_1.Query)('projectId')),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, Object]),
    __metadata("design:returntype", Promise)
], BenchmarkingController.prototype, "exportCSV", null);
exports.BenchmarkingController = BenchmarkingController = BenchmarkingController_1 = __decorate([
    (0, common_1.Controller)('benchmarking'),
    __metadata("design:paramtypes", [oauth_bigquery_service_1.OAuthBigQueryService,
        snapshot_service_1.SnapshotService])
], BenchmarkingController);
//# sourceMappingURL=benchmarking.controller.js.map