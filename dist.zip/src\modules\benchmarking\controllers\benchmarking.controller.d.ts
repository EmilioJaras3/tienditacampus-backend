import { Response } from 'express';
import { OAuthBigQueryService } from '../auth/oauth-bigquery.service';
import { SnapshotService } from '../snapshots/snapshot.service';
export declare class BenchmarkingController {
    private oauthService;
    private snapshotService;
    private readonly logger;
    constructor(oauthService: OAuthBigQueryService, snapshotService: SnapshotService);
    googleAuth(): {
        url: string;
    };
    googleCallback(code: string, state: string, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    executeSnapshot(body: {
        accessToken: string;
    }, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    exportCSV(projectId: number, res: Response): Promise<void>;
}
