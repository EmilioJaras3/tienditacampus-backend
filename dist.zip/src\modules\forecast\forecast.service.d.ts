import { DataSource } from 'typeorm';
export declare class ForecastService {
    private dataSource;
    private readonly logger;
    constructor(dataSource: DataSource);
    handleCron(): Promise<void>;
    getForecast(productId: string, dayOfWeek: number): Promise<number>;
}
