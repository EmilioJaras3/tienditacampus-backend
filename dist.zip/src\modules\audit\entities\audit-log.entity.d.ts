export declare class AuditLog {
    id: string;
    action: string;
    entityType: string;
    entityId: string;
    userId: string;
    metadata: Record<string, any>;
    level: string;
    description: string;
    ipAddress: string;
    createdAt: Date;
}
