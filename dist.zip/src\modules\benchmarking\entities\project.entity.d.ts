import { Query } from './query.entity';
import { Execution } from './execution.entity';
export declare enum ProjectType {
    ECOMMERCE = "ECOMMERCE",
    SOCIAL = "SOCIAL",
    FINANCIAL = "FINANCIAL",
    HEALTHCARE = "HEALTHCARE",
    IOT = "IOT",
    EDUCATION = "EDUCATION",
    CONTENT = "CONTENT",
    ENTERPRISE = "ENTERPRISE",
    LOGISTICS = "LOGISTICS",
    GOVERNMENT = "GOVERNMENT"
}
export declare enum DbEngine {
    POSTGRESQL = "POSTGRESQL",
    MYSQL = "MYSQL",
    MONGODB = "MONGODB",
    OTHER = "OTHER"
}
export declare class Project {
    project_id: number;
    project_type: ProjectType;
    description: string;
    db_engine: DbEngine;
    queries: Query[];
    executions: Execution[];
}
