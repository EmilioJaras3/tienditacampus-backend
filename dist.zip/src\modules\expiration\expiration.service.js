"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var ExpirationService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.ExpirationService = void 0;
const common_1 = require("@nestjs/common");
const schedule_1 = require("@nestjs/schedule");
const typeorm_1 = require("typeorm");
const inventory_record_entity_1 = require("../inventory/entities/inventory-record.entity");
const daily_sale_entity_1 = require("../sales/entities/daily-sale.entity");
const sale_detail_entity_1 = require("../sales/entities/sale-detail.entity");
const product_entity_1 = require("../products/entities/product.entity");
let ExpirationService = ExpirationService_1 = class ExpirationService {
    constructor(dataSource) {
        this.dataSource = dataSource;
        this.logger = new common_1.Logger(ExpirationService_1.name);
    }
    async handleCronExpiration() {
        this.logger.log('⏰ [CRON] Iniciando evaluación automática de caducidad...');
        const result = await this.processExpiredInventory();
        this.logger.log(`✅ [CRON] Evaluación completada. ` +
            `Lotes expirados: ${result.lotsExpired}, ` +
            `Unidades perdidas: ${result.totalUnitsLost}, ` +
            `Costo de merma: $${result.totalWasteCost.toFixed(2)}`);
    }
    async processExpiredInventory() {
        const todayStr = new Date().toISOString().split('T')[0];
        const queryRunner = this.dataSource.createQueryRunner();
        await queryRunner.connect();
        await queryRunner.startTransaction();
        let lotsExpired = 0;
        let totalUnitsLost = 0;
        let totalWasteCost = 0;
        try {
            const manager = queryRunner.manager;
            const expiredLots = await manager
                .createQueryBuilder(inventory_record_entity_1.InventoryRecord, 'ir')
                .leftJoinAndSelect('ir.product', 'product')
                .where('ir.status = :status', { status: 'active' })
                .andWhere('ir.quantity_remaining > 0')
                .andWhere('ir.expires_at IS NOT NULL')
                .andWhere('ir.expires_at < :today', { today: todayStr })
                .getMany();
            if (expiredLots.length === 0) {
                await queryRunner.commitTransaction();
                return { lotsExpired: 0, totalUnitsLost: 0, totalWasteCost: 0 };
            }
            const sellerWasteMap = new Map();
            for (const lot of expiredLots) {
                const unitsLost = lot.quantityRemaining;
                const unitCost = Number(lot.product?.unitCost || lot.investmentAmount / lot.quantityInitial);
                const wasteCost = unitsLost * unitCost;
                lot.quantityRemaining = 0;
                lot.status = 'expired';
                await manager.save(inventory_record_entity_1.InventoryRecord, lot);
                if (!sellerWasteMap.has(lot.sellerId)) {
                    sellerWasteMap.set(lot.sellerId, { units: 0, cost: 0, details: [] });
                }
                const sellerData = sellerWasteMap.get(lot.sellerId);
                sellerData.units += unitsLost;
                sellerData.cost += wasteCost;
                sellerData.details.push({
                    productId: lot.productId,
                    quantity: unitsLost,
                    unitCost,
                });
                lotsExpired++;
                totalUnitsLost += unitsLost;
                totalWasteCost += wasteCost;
            }
            for (const [sellerId, wasteData] of sellerWasteMap) {
                let dailySale = await manager.findOne(daily_sale_entity_1.DailySale, {
                    where: { sellerId, saleDate: todayStr },
                });
                if (!dailySale) {
                    dailySale = new daily_sale_entity_1.DailySale();
                    dailySale.sellerId = sellerId;
                    dailySale.saleDate = todayStr;
                    dailySale.totalInvestment = 0;
                    dailySale.totalRevenue = 0;
                    dailySale.unitsSold = 0;
                    dailySale.unitsLost = 0;
                    dailySale.totalWasteCost = 0;
                    dailySale.details = [];
                    dailySale = await manager.save(daily_sale_entity_1.DailySale, dailySale);
                }
                const productWasteMap = new Map();
                for (const detail of wasteData.details) {
                    if (!productWasteMap.has(detail.productId)) {
                        productWasteMap.set(detail.productId, { quantity: 0, unitCost: detail.unitCost });
                    }
                    productWasteMap.get(detail.productId).quantity += detail.quantity;
                }
                for (const [productId, pwData] of productWasteMap) {
                    const product = await manager.findOne(product_entity_1.Product, { where: { id: productId } });
                    const unitPrice = product ? Number(product.salePrice) : 0;
                    const existingDetail = await manager.findOne(sale_detail_entity_1.SaleDetail, {
                        where: { dailySaleId: dailySale.id, productId }
                    });
                    if (existingDetail) {
                        existingDetail.quantityLost += pwData.quantity;
                        existingDetail.wasteCost = Number(existingDetail.wasteCost) + (pwData.quantity * pwData.unitCost);
                        existingDetail.wasteReason = 'expired';
                        await manager.save(sale_detail_entity_1.SaleDetail, existingDetail);
                    }
                    else {
                        const saleDetail = new sale_detail_entity_1.SaleDetail();
                        saleDetail.dailySaleId = dailySale.id;
                        saleDetail.productId = productId;
                        saleDetail.quantityPrepared = 0;
                        saleDetail.quantitySold = 0;
                        saleDetail.quantityLost = pwData.quantity;
                        saleDetail.unitCost = pwData.unitCost;
                        saleDetail.unitPrice = unitPrice;
                        saleDetail.wasteReason = 'expired';
                        saleDetail.wasteCost = pwData.quantity * pwData.unitCost;
                        await manager.save(sale_detail_entity_1.SaleDetail, saleDetail);
                    }
                }
                const newUnitsLost = (Number(dailySale.unitsLost) || 0) + wasteData.units;
                const newWasteCost = Number(dailySale.totalWasteCost || 0) + wasteData.cost;
                await manager.update(daily_sale_entity_1.DailySale, dailySale.id, {
                    unitsLost: newUnitsLost,
                    totalWasteCost: newWasteCost,
                });
            }
            await queryRunner.commitTransaction();
        }
        catch (error) {
            await queryRunner.rollbackTransaction();
            this.logger.error('❌ Error en evaluación de caducidad:', error);
            throw error;
        }
        finally {
            await queryRunner.release();
        }
        return { lotsExpired, totalUnitsLost, totalWasteCost };
    }
};
exports.ExpirationService = ExpirationService;
__decorate([
    (0, schedule_1.Cron)('0 1 0 * * *', { name: 'auto-expiration', timeZone: 'America/Mexico_City' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], ExpirationService.prototype, "handleCronExpiration", null);
exports.ExpirationService = ExpirationService = ExpirationService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [typeorm_1.DataSource])
], ExpirationService);
//# sourceMappingURL=expiration.service.js.map