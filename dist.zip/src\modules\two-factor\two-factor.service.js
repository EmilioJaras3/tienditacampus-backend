"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var TwoFactorService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.TwoFactorService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const argon2_1 = require("@node-rs/argon2");
const two_factor_code_entity_1 = require("./entities/two-factor-code.entity");
let TwoFactorService = TwoFactorService_1 = class TwoFactorService {
    constructor(twoFactorRepo) {
        this.twoFactorRepo = twoFactorRepo;
        this.logger = new common_1.Logger(TwoFactorService_1.name);
    }
    async generateCode(userId) {
        await this.twoFactorRepo.update({ userId, used: false }, { used: true });
        const code = Math.floor(100000 + Math.random() * 900000).toString();
        const codeHash = await (0, argon2_1.hash)(code, {
            memoryCost: 4096,
            timeCost: 2,
            parallelism: 1,
        });
        const expiresAt = new Date(Date.now() + 10 * 60 * 1000);
        const twoFactorCode = this.twoFactorRepo.create({
            userId,
            codeHash,
            expiresAt,
            used: false,
        });
        await this.twoFactorRepo.save(twoFactorCode);
        this.logger.log(`Código 2FA generado para usuario ${userId}`);
        return code;
    }
    async verifyCode(userId, plainCode) {
        await this.cleanExpiredCodes();
        const activeCodes = await this.twoFactorRepo.find({
            where: {
                userId,
                used: false,
            },
            order: { createdAt: 'DESC' },
        });
        for (const record of activeCodes) {
            if (new Date() > record.expiresAt) {
                continue;
            }
            const isValid = await (0, argon2_1.verify)(record.codeHash, plainCode);
            if (isValid) {
                record.used = true;
                await this.twoFactorRepo.save(record);
                this.logger.log(`Código 2FA verificado exitosamente para usuario ${userId}`);
                return true;
            }
        }
        this.logger.warn(`Código 2FA inválido para usuario ${userId}`);
        return false;
    }
    async cleanExpiredCodes() {
        const result = await this.twoFactorRepo.delete({
            expiresAt: (0, typeorm_2.LessThan)(new Date()),
            used: true,
        });
        if (result.affected && result.affected > 0) {
            this.logger.log(`Limpiados ${result.affected} códigos 2FA expirados`);
        }
    }
};
exports.TwoFactorService = TwoFactorService;
exports.TwoFactorService = TwoFactorService = TwoFactorService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(two_factor_code_entity_1.TwoFactorCode)),
    __metadata("design:paramtypes", [typeorm_2.Repository])
], TwoFactorService);
//# sourceMappingURL=two-factor.service.js.map