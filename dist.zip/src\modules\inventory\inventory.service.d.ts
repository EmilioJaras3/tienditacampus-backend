import { Repository, EntityManager } from 'typeorm';
import { InventoryRecord } from './entities/inventory-record.entity';
import { CreateInventoryRecordDto } from './dto/create-inventory-record.dto';
import { User } from '../users/entities/user.entity';
import { Product } from '../products/entities/product.entity';
import { AuditService } from '../audit/audit.service';
export declare class InventoryService {
    private readonly inventoryRepository;
    private readonly productRepository;
    private readonly auditService;
    constructor(inventoryRepository: Repository<InventoryRecord>, productRepository: Repository<Product>, auditService: AuditService);
    addStock(createInventoryDto: CreateInventoryRecordDto, user: User): Promise<InventoryRecord>;
    getHistoryByProduct(productId: string, user: User): Promise<InventoryRecord[]>;
    consumeFIFO(productId: string, sellerId: string, quantity: number, manager: EntityManager): Promise<number>;
}
