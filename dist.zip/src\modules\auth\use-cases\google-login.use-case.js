"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.GoogleLoginUseCase = void 0;
const common_1 = require("@nestjs/common");
const jwt_1 = require("@nestjs/jwt");
const users_service_1 = require("../../users/users.service");
const audit_service_1 = require("../../audit/audit.service");
let GoogleLoginUseCase = class GoogleLoginUseCase {
    constructor(usersService, jwtService, auditService) {
        this.usersService = usersService;
        this.jwtService = jwtService;
        this.auditService = auditService;
    }
    async execute(dto) {
        try {
            const googleResponse = await fetch('https://www.googleapis.com/oauth2/v3/userinfo', {
                headers: { Authorization: `Bearer ${dto.token}` }
            });
            if (!googleResponse.ok)
                throw new common_1.UnauthorizedException('Token de Google inválido');
            const data = await googleResponse.json();
            const email = data.email.toLowerCase();
            let user = await this.usersService.findByEmail(email);
            const adminEmails = (process.env.ADMIN_EMAILS || 'jarassanchezl@gmail.com').toLowerCase().split(',');
            const assignedRole = adminEmails.includes(email) ? 'admin' : 'buyer';
            if (!user) {
                user = await this.usersService.create({
                    email,
                    password: `Gg#${Math.random().toString(36).slice(-8)}A1!x`,
                    firstName: data.given_name || 'Usuario',
                    lastName: data.family_name || 'Google',
                    role: assignedRole
                });
            }
            else if (user.role !== assignedRole) {
                await this.usersService.updateRole(user.id, assignedRole);
                user.role = assignedRole;
            }
            await this.usersService.recordSuccessfulLogin(user.id);
            const accessToken = this.jwtService.sign({ sub: user.id, email: user.email, role: user.role });
            await this.auditService.log({
                action: 'user.login_google',
                entityType: 'user',
                entityId: user.id,
                userId: user.id,
                description: `Login SSO Google: ${user.email}`,
            });
            return { user, accessToken };
        }
        catch (error) {
            throw new common_1.UnauthorizedException('Error en autenticación Google SSO');
        }
    }
};
exports.GoogleLoginUseCase = GoogleLoginUseCase;
exports.GoogleLoginUseCase = GoogleLoginUseCase = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [users_service_1.UsersService,
        jwt_1.JwtService,
        audit_service_1.AuditService])
], GoogleLoginUseCase);
//# sourceMappingURL=google-login.use-case.js.map