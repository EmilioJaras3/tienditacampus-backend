import { DataSource, QueryRunner } from 'typeorm';
export declare class TransactionManager {
    private readonly dataSource;
    constructor(dataSource: DataSource);
    execute<T>(operation: (queryRunner: QueryRunner) => Promise<T>, errorMessage?: string): Promise<T>;
}
