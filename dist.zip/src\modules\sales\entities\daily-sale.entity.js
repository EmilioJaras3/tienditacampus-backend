"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DailySale = void 0;
const typeorm_1 = require("typeorm");
const user_entity_1 = require("../../users/entities/user.entity");
const sale_detail_entity_1 = require("./sale-detail.entity");
let DailySale = class DailySale {
};
exports.DailySale = DailySale;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('uuid'),
    __metadata("design:type", String)
], DailySale.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'seller_id' }),
    __metadata("design:type", String)
], DailySale.prototype, "sellerId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => user_entity_1.User),
    (0, typeorm_1.JoinColumn)({ name: 'seller_id' }),
    __metadata("design:type", user_entity_1.User)
], DailySale.prototype, "seller", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'date', name: 'sale_date', default: () => 'CURRENT_DATE' }),
    __metadata("design:type", String)
], DailySale.prototype, "saleDate", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 10, scale: 2, name: 'total_investment' }),
    __metadata("design:type", Number)
], DailySale.prototype, "totalInvestment", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 10, scale: 2, default: 0, name: 'total_revenue' }),
    __metadata("design:type", Number)
], DailySale.prototype, "totalRevenue", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'decimal',
        precision: 10,
        scale: 2,
        name: 'total_profit',
        generatedType: 'STORED',
        asExpression: 'total_revenue - total_investment',
        insert: false,
        update: false,
    }),
    __metadata("design:type", String)
], DailySale.prototype, "totalProfit", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 5, scale: 2, default: 0, name: 'profit_margin' }),
    __metadata("design:type", Number)
], DailySale.prototype, "profitMargin", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0, name: 'units_sold' }),
    __metadata("design:type", Number)
], DailySale.prototype, "unitsSold", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0, name: 'units_lost' }),
    __metadata("design:type", Number)
], DailySale.prototype, "unitsLost", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'decimal',
        precision: 10,
        scale: 2,
        nullable: true,
        name: 'break_even_units',
        comment: 'Unidades mínimas necesarias para cubrir inversión del día'
    }),
    __metadata("design:type", Object)
], DailySale.prototype, "breakEvenUnits", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'decimal',
        precision: 10,
        scale: 2,
        default: 0,
        name: 'total_waste_cost',
        comment: 'Costo económico total de merma del día (suma de waste_cost de detalles)'
    }),
    __metadata("design:type", Number)
], DailySale.prototype, "totalWasteCost", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'boolean', default: false, name: 'is_closed' }),
    __metadata("design:type", Boolean)
], DailySale.prototype, "isClosed", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', nullable: true }),
    __metadata("design:type", String)
], DailySale.prototype, "notes", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => sale_detail_entity_1.SaleDetail, (detail) => detail.dailySale, { cascade: true }),
    __metadata("design:type", Array)
], DailySale.prototype, "details", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ type: 'timestamptz', name: 'created_at' }),
    __metadata("design:type", Date)
], DailySale.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({ type: 'timestamptz', name: 'updated_at' }),
    __metadata("design:type", Date)
], DailySale.prototype, "updatedAt", void 0);
exports.DailySale = DailySale = __decorate([
    (0, typeorm_1.Entity)('daily_sales')
], DailySale);
//# sourceMappingURL=daily-sale.entity.js.map