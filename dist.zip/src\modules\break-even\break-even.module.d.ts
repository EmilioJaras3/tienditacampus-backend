export declare class BreakEvenModule {
}
