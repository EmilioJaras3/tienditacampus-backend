import { OnApplicationBootstrap } from '@nestjs/common';
import { Repository } from 'typeorm';
import { Category } from './entities/category.entity';
export declare class CategorySeedService implements OnApplicationBootstrap {
    private readonly categoryRepository;
    private readonly logger;
    constructor(categoryRepository: Repository<Category>);
    onApplicationBootstrap(): Promise<void>;
}
