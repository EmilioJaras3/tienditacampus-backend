export declare class RegisterDto {
    email: string;
    password: string;
    acceptTerms: boolean;
    firstName: string;
    lastName: string;
    phone?: string;
    major?: string;
    campusLocation?: string;
    role?: 'seller' | 'buyer';
}
