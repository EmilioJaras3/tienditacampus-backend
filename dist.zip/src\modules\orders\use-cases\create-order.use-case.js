"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateOrderUseCase = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const order_entity_1 = require("../entities/order.entity");
const order_item_entity_1 = require("../entities/order-item.entity");
const product_entity_1 = require("../../products/entities/product.entity");
const inventory_record_entity_1 = require("../../inventory/entities/inventory-record.entity");
const transaction_manager_util_1 = require("../../../shared/utils/transaction-manager.util");
let CreateOrderUseCase = class CreateOrderUseCase {
    constructor(orderRepo, transactionManager) {
        this.orderRepo = orderRepo;
        this.transactionManager = transactionManager;
    }
    async execute(dto, buyer) {
        return this.transactionManager.execute(async (queryRunner) => {
            let totalOrderAmount = 0;
            const orderItemsToSave = [];
            for (const item of dto.items) {
                const product = await queryRunner.manager.findOne(product_entity_1.Product, {
                    where: { id: item.productId, sellerId: dto.sellerId, isActive: true }
                });
                if (!product) {
                    throw new common_1.NotFoundException(`Producto ${item.productId} no encontrado o inactivo`);
                }
                const activeInventory = await queryRunner.manager.findOne(inventory_record_entity_1.InventoryRecord, {
                    where: { productId: product.id, status: 'active' }
                });
                if (!activeInventory || activeInventory.quantityRemaining < item.quantity) {
                    throw new common_1.BadRequestException(`Sin stock suficiente para el producto: ${product.name}`);
                }
                const subtotal = item.quantity * Number(product.salePrice);
                totalOrderAmount += subtotal;
                const orderItem = new order_item_entity_1.OrderItem();
                orderItem.product = product;
                orderItem.productId = product.id;
                orderItem.quantity = item.quantity;
                orderItem.unitPrice = product.salePrice;
                orderItem.subtotal = subtotal;
                orderItemsToSave.push(orderItem);
            }
            let order = new order_entity_1.Order();
            order.buyerId = buyer.id;
            order.sellerId = dto.sellerId;
            order.totalAmount = totalOrderAmount;
            order.status = 'requested';
            order.deliveryMessage = dto.deliveryMessage || null;
            order = await queryRunner.manager.save(order_entity_1.Order, order);
            for (const orderItem of orderItemsToSave) {
                orderItem.order = order;
                orderItem.orderId = order.id;
                await queryRunner.manager.save(order_item_entity_1.OrderItem, orderItem);
            }
            const finalOrder = await queryRunner.manager.findOne(order_entity_1.Order, {
                where: { id: order.id },
                relations: ['items', 'items.product', 'seller']
            });
            if (!finalOrder)
                throw new common_1.InternalServerErrorException('Error recuperando la orden guardada');
            return finalOrder;
        }, 'Fallo al procesar la creación de la orden');
    }
};
exports.CreateOrderUseCase = CreateOrderUseCase;
exports.CreateOrderUseCase = CreateOrderUseCase = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(order_entity_1.Order)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        transaction_manager_util_1.TransactionManager])
], CreateOrderUseCase);
//# sourceMappingURL=create-order.use-case.js.map