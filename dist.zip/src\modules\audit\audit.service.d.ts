import { Repository } from 'typeorm';
import { AuditLog } from './entities/audit-log.entity';
export declare class AuditService {
    private readonly auditRepository;
    constructor(auditRepository: Repository<AuditLog>);
    log(params: {
        action: string;
        entityType?: string;
        entityId?: string;
        userId?: string;
        metadata?: Record<string, any>;
        level?: 'info' | 'warn' | 'error' | 'debug';
        description?: string;
        ipAddress?: string;
    }): Promise<AuditLog | null>;
    findByAction(action: string): Promise<AuditLog[]>;
    findByUser(userId: string): Promise<AuditLog[]>;
    findByEntity(entityType: string, entityId: string): Promise<AuditLog[]>;
    findByMetadataKey(key: string, value: string): Promise<AuditLog[]>;
    getRecent(limit?: number): Promise<AuditLog[]>;
    findAll(): Promise<AuditLog[]>;
}
