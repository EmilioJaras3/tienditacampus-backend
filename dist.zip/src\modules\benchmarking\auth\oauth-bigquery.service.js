"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var OAuthBigQueryService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.OAuthBigQueryService = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const bigquery_1 = require("@google-cloud/bigquery");
const googleapis_1 = require("googleapis");
let OAuthBigQueryService = OAuthBigQueryService_1 = class OAuthBigQueryService {
    constructor(configService) {
        this.configService = configService;
        this.logger = new common_1.Logger(OAuthBigQueryService_1.name);
        this.oauth2Client = new googleapis_1.google.auth.OAuth2(this.configService.get('GOOGLE_CLIENT_ID') || 'placeholder-client-id', this.configService.get('GOOGLE_CLIENT_SECRET') || 'placeholder-client-secret', this.configService.get('GOOGLE_REDIRECT_URI') || 'http://localhost:3000/benchmarking/auth/callback');
    }
    getAuthUrl() {
        const scopes = ['https://www.googleapis.com/auth/bigquery'];
        return this.oauth2Client.generateAuthUrl({
            access_type: 'offline',
            scope: scopes,
            state: this.generateState(),
        });
    }
    async getTokenFromCode(code) {
        try {
            const { tokens } = await this.oauth2Client.getToken(code);
            this.logger.log('✅ OAuth token obtenido');
            return {
                accessToken: tokens.access_token,
                refreshToken: tokens.refresh_token,
            };
        }
        catch (error) {
            this.logger.error('❌ Error al obtener token:', error.message);
            throw error;
        }
    }
    async sendToBigQuery(accessToken, rows) {
        try {
            const bigquery = new bigquery_1.BigQuery({
                projectId: this.configService.get('GCP_PROJECT_ID'),
                credentials: {
                    type: 'authorized_user',
                    client_id: this.configService.get('GOOGLE_CLIENT_ID'),
                    client_secret: this.configService.get('GOOGLE_CLIENT_SECRET'),
                    refresh_token: accessToken,
                },
            });
            const dataset = this.configService.get('BIGQUERY_DATASET');
            const table = this.configService.get('BIGQUERY_TABLE');
            const url = `https://www.googleapis.com/bigquery/v2/projects/${this.configService.get('GCP_PROJECT_ID') || 'data-from-software'}/datasets/${this.configService.get('BIGQUERY_DATASET') || 'benchmarking_warehouse'}/tables/${this.configService.get('BIGQUERY_TABLE') || 'daily_query_metrics'}/insertAll`;
            const response = await fetch(url, {
                method: 'POST',
                headers: {
                    Authorization: `Bearer ${accessToken}`,
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    rows: rows.map(row => ({ json: row })),
                    skipInvalidRows: false,
                    ignoreUnknownValues: false,
                }),
            });
            if (response.status !== 200) {
                const errorData = await response.json();
                this.logger.error('❌ Errores en inserción:', errorData.errors);
                throw new Error(`BigQuery insert errors: ${JSON.stringify(errorData.errors)}`);
            }
            this.logger.log(`✅ ${rows.length} registros enviados a BigQuery`);
        }
        catch (error) {
            this.logger.error('❌ Error al enviar a BigQuery:', error.message);
            throw error;
        }
    }
    async validateToken(token) {
        try {
            const response = await fetch(`https://www.googleapis.com/oauth2/v1/tokeninfo?access_token=${token}`);
            return response.status === 200;
        }
        catch (error) {
            this.logger.warn('⚠️ Token inválido o expirado');
            return false;
        }
    }
    generateState() {
        return Math.random().toString(36).substring(7);
    }
};
exports.OAuthBigQueryService = OAuthBigQueryService;
exports.OAuthBigQueryService = OAuthBigQueryService = OAuthBigQueryService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [config_1.ConfigService])
], OAuthBigQueryService);
//# sourceMappingURL=oauth-bigquery.service.js.map