"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var BenchmarkingService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.BenchmarkingService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const bigquery_1 = require("@google-cloud/bigquery");
const google_auth_library_1 = require("google-auth-library");
const project_entity_1 = require("./entities/project.entity");
const query_entity_1 = require("./entities/query.entity");
let BenchmarkingService = BenchmarkingService_1 = class BenchmarkingService {
    constructor(entityManager, projectRepository, queryRepository) {
        this.entityManager = entityManager;
        this.projectRepository = projectRepository;
        this.queryRepository = queryRepository;
        this.logger = new common_1.Logger(BenchmarkingService_1.name);
    }
    async getCurrentProjectId() {
        const requiredProjectId = 2;
        try {
            await this.entityManager.query(`INSERT INTO projects (project_id, project_type, description, db_engine)
                 VALUES ($1, 'ECOMMERCE', $2, 'POSTGRESQL')
                 ON CONFLICT (project_id) DO NOTHING`, [
                requiredProjectId,
                'TienditaCampus - Sistema de Comercio Electrónico Universitario',
            ]);
        }
        catch (error) {
            this.logger.error(`Benchmarking schema not ready (projects missing?): ${error.message}`);
            throw error;
        }
        return requiredProjectId;
    }
    async runRegisteredQueries() {
        const queries = await this.queryRepository.find();
        for (const q of queries) {
            try {
                await this.entityManager.query(q.query_sql);
                this.logger.log(`Consulta ejecutada: ${q.query_description}`);
            }
            catch (error) {
                this.logger.error(`Error al ejecutar consulta "${q.query_description}": ${error.message}`);
            }
        }
    }
    async processDailySnapshot(authHeader) {
        const accessToken = authHeader.replace('Bearer ', '');
        if (!accessToken)
            throw new common_1.BadRequestException('OAuth token is required');
        const metrics = await this.entityManager.query('SELECT * FROM v_daily_export');
        if (metrics.length === 0) {
            throw new common_1.BadRequestException('No hay métricas acumuladas (calls > 0) para exportar.');
        }
        return this.sendToBigQuery(accessToken, metrics);
    }
    async processHistoricalSnapshot(authHeader, days = 30) {
        const accessToken = authHeader.replace('Bearer ', '');
        if (!accessToken)
            throw new common_1.BadRequestException('OAuth token is required');
        const metrics = await this.entityManager.query('SELECT * FROM v_daily_export');
        if (metrics.length === 0) {
            throw new common_1.BadRequestException('No hay métricas base para generar historial. Ejecuta algunas consultas primero.');
        }
        const historicalRows = [];
        const startDate = new Date();
        startDate.setDate(startDate.getDate() - days);
        for (let i = 0; i <= days; i++) {
            const currentDay = new Date(startDate);
            currentDay.setDate(currentDay.getDate() + i);
            const dateStr = currentDay.toISOString().split('T')[0];
            metrics.forEach((m) => {
                const chaos = 0.5 + Math.random();
                historicalRows.push({
                    ...m,
                    snapshot_date: dateStr,
                    calls: Math.max(1, Math.floor(m.calls * chaos)),
                    total_exec_time_ms: m.total_exec_time_ms * chaos,
                });
            });
        }
        return this.sendToBigQuery(accessToken, historicalRows);
    }
    async sendToBigQuery(accessToken, rows) {
        try {
            const oauth2Client = new google_auth_library_1.OAuth2Client();
            oauth2Client.setCredentials({ access_token: accessToken });
            const bigquery = new bigquery_1.BigQuery({
                projectId: 'data-from-software',
                authClient: oauth2Client
            });
            const datasetId = 'benchmarking_warehouse';
            const tableId = 'daily_query_metrics';
            const formattedRows = rows.map(r => ({
                ...r,
                snapshot_date: typeof r.snapshot_date === 'string' ? r.snapshot_date : r.snapshot_date.toISOString().split('T')[0]
            }));
            await bigquery.dataset(datasetId).table(tableId).insert(formattedRows);
            if (rows.length < 100) {
                await this.entityManager.query('SELECT pg_stat_statements_reset()');
            }
            return {
                message: `Exportación exitosa a BigQuery.`,
                count: formattedRows.length,
                status: 'COMPLETED'
            };
        }
        catch (error) {
            this.logger.error(`Error al enviar a BigQuery: ${error.message}`);
            throw new common_1.BadRequestException(`Fallo en envío a BigQuery: ${error.message}`);
        }
    }
    async getQueryMetrics(limit = 20) {
        try {
            const metrics = await this.entityManager.query(`
                SELECT 
                    queryid::text as id,
                    LEFT(query, 120) as query,
                    calls,
                    ROUND(total_exec_time::numeric, 2) as total_time_ms,
                    ROUND(mean_exec_time::numeric, 2) as avg_time_ms,
                    rows as rows_returned,
                    shared_blks_hit,
                    shared_blks_read
                FROM pg_stat_statements
                WHERE calls > 0
                AND query NOT LIKE '%pg_stat_statements%'
                ORDER BY calls DESC
                LIMIT $1
            `, [limit]);
            return metrics;
        }
        catch (error) {
            this.logger.warn(`pg_stat_statements no disponible: ${error.message}`);
            return [];
        }
    }
};
exports.BenchmarkingService = BenchmarkingService;
exports.BenchmarkingService = BenchmarkingService = BenchmarkingService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectEntityManager)()),
    __param(1, (0, typeorm_1.InjectRepository)(project_entity_1.Project)),
    __param(2, (0, typeorm_1.InjectRepository)(query_entity_1.Query)),
    __metadata("design:paramtypes", [typeorm_2.EntityManager,
        typeorm_2.Repository,
        typeorm_2.Repository])
], BenchmarkingService);
//# sourceMappingURL=benchmarking.service.js.map