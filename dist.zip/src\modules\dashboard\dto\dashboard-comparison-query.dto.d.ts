export declare class DashboardComparisonQueryDto {
    startDate?: string;
    endDate?: string;
}
