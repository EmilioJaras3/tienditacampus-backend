import { Repository, DataSource } from 'typeorm';
import { Product } from '../products/entities/product.entity';
import { User } from '../users/entities/user.entity';
import { CalculateBreakEvenDto } from './dto/calculate-break-even.dto';
export declare class BreakEvenService {
    private readonly productRepository;
    private readonly dataSource;
    constructor(productRepository: Repository<Product>, dataSource: DataSource);
    calculate(dto: CalculateBreakEvenDto, user: User): Promise<{
        productId: string;
        productName: string;
        fixedCosts: string;
        unitCost: string;
        effectiveUnitCost: string;
        unitPrice: string;
        unitMargin: string;
        wasteRate: number;
        wasteRateSample: {
            totalLost: number;
            totalHandled: number;
            periodDays: number;
        };
        breakEvenUnits: number;
        formula: string;
    }>;
    private toCents;
    private fromCents;
    private ceilDiv;
}
