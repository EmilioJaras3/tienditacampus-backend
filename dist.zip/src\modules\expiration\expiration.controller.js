"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ExpirationController = void 0;
const common_1 = require("@nestjs/common");
const expiration_service_1 = require("./expiration.service");
const jwt_auth_guard_1 = require("../auth/guards/jwt-auth.guard");
let ExpirationController = class ExpirationController {
    constructor(expirationService) {
        this.expirationService = expirationService;
    }
    async runManual() {
        const result = await this.expirationService.processExpiredInventory();
        return {
            message: 'Evaluación de caducidad ejecutada manualmente',
            ...result,
        };
    }
};
exports.ExpirationController = ExpirationController;
__decorate([
    (0, common_1.Post)('run-manual'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], ExpirationController.prototype, "runManual", null);
exports.ExpirationController = ExpirationController = __decorate([
    (0, common_1.Controller)('expiration'),
    __metadata("design:paramtypes", [expiration_service_1.ExpirationService])
], ExpirationController);
//# sourceMappingURL=expiration.controller.js.map