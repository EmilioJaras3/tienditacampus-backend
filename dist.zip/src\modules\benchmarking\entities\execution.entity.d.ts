import { Project } from './project.entity';
import { Query } from './query.entity';
export declare enum IndexStrategy {
    NO_INDEX = "NO_INDEX",
    SINGLE_INDEX = "SINGLE_INDEX",
    COMPOSITE_INDEX = "COMPOSITE_INDEX"
}
export declare class Execution {
    execution_id: string;
    project_id: number;
    project: Project;
    query_id: number;
    query: Query;
    index_strategy: IndexStrategy;
    execution_timestamp: Date;
    execution_time_ms: string;
    records_examined: string;
    records_returned: string;
    dataset_size_rows: string;
    dataset_size_mb: number;
    concurrent_sessions: number;
    shared_buffers_hits: string;
    shared_buffers_reads: string;
}
