import { User } from '../../users/entities/user.entity';
import { OrderItem } from './order-item.entity';
export declare class Order {
    id: string;
    buyerId: string;
    buyer: User;
    sellerId: string;
    seller: User;
    totalAmount: number;
    status: string;
    deliveryMessage: string | null;
    items: OrderItem[];
    createdAt: Date;
    updatedAt: Date;
}
