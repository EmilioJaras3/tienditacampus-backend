export declare class GetWeeklyReportsDto {
    startWeek?: string;
    endWeek?: string;
}
