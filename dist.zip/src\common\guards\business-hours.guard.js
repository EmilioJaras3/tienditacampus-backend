"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BusinessHoursGuard = void 0;
const common_1 = require("@nestjs/common");
let BusinessHoursGuard = class BusinessHoursGuard {
    canActivate(context) {
        const request = context.switchToHttp().getRequest();
        const method = request.method;
        if (method === 'GET') {
            return true;
        }
        const now = new Date();
        const dayOfWeek = now.getDay();
        const hours = now.getHours();
        const isWeekday = dayOfWeek >= 1 && dayOfWeek <= 5;
        const isWorkingHours = hours >= 8 && hours < 16;
        if (!isWeekday || !isWorkingHours) {
            throw new common_1.ForbiddenException(`Acción bloqueda: Las operaciones administrativas solo están permitidas de Lunes a Viernes de 08:00 a 16:00 horas.`);
        }
        return true;
    }
};
exports.BusinessHoursGuard = BusinessHoursGuard;
exports.BusinessHoursGuard = BusinessHoursGuard = __decorate([
    (0, common_1.Injectable)()
], BusinessHoursGuard);
//# sourceMappingURL=business-hours.guard.js.map