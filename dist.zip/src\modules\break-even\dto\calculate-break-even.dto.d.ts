export declare class CalculateBreakEvenDto {
    productId: string;
    fixedCosts: number;
    unitCost?: number;
    unitPrice?: number;
}
