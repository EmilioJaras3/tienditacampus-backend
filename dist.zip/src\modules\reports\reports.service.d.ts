import { DataSource, Repository } from 'typeorm';
import { WeeklyReport } from './entities/weekly-report.entity';
import { User } from '../users/entities/user.entity';
export declare class ReportsService {
    private readonly weeklyReportRepository;
    private readonly dataSource;
    constructor(weeklyReportRepository: Repository<WeeklyReport>, dataSource: DataSource);
    generateWeeklyReport(user: User, weekStart?: string): Promise<WeeklyReport[]>;
    getWeeklyReports(user: User, startWeek?: string, endWeek?: string): Promise<WeeklyReport[]>;
    findOne(id: string, user: User): Promise<WeeklyReport>;
    remove(id: string, user: User): Promise<void>;
}
