import { Repository } from 'typeorm';
import { DailySale } from '../entities/daily-sale.entity';
import { SaleDetail } from '../entities/sale-detail.entity';
import { Product } from '../../products/entities/product.entity';
import { BaseRepository } from '../../../shared/repositories/base.repository';
export interface ISalesRepository {
    findToday(sellerId: string): Promise<DailySale | null>;
    createDailySale(dailySale: DailySale, details: SaleDetail[]): Promise<DailySale>;
    saveSaleDetail(detail: SaleDetail): Promise<SaleDetail>;
    findSaleWithDetails(id: string): Promise<DailySale | null>;
    updateSale(id: string, updates: Partial<DailySale>): Promise<void>;
    closeDay(dailySale: DailySale): Promise<DailySale>;
    findProduct(productId: string): Promise<any>;
    consumeInventory(productId: string, userId: string, units: number): Promise<void>;
    getROI(sellerId: string, startDate?: string, endDate?: string): Promise<{
        investment: number;
        revenue: number;
        netProfit: number;
        roi: number;
    }>;
    getHistory(sellerId: string, page?: number, limit?: number): Promise<{
        data: DailySale[];
        total: number;
        page: number;
        limit: number;
    }>;
    getByWeekdayAnalytics(sellerId: string, startDate?: string, endDate?: string): Promise<any[]>;
    getPrediction(sellerId: string): Promise<any>;
}
export declare class SalesRepository extends BaseRepository<DailySale> implements ISalesRepository {
    private readonly dailySaleRepository;
    private readonly saleDetailRepository;
    private readonly productRepository;
    constructor(dailySaleRepository: Repository<DailySale>, saleDetailRepository: Repository<SaleDetail>, productRepository: Repository<Product>);
    findToday(sellerId: string): Promise<DailySale | null>;
    createDailySale(dailySale: DailySale, details: SaleDetail[]): Promise<DailySale>;
    saveSaleDetail(detail: SaleDetail): Promise<SaleDetail>;
    findSaleWithDetails(id: string): Promise<DailySale | null>;
    updateSale(id: string, updates: Partial<DailySale>): Promise<void>;
    getROI(sellerId: string): Promise<{
        investment: number;
        revenue: number;
        netProfit: number;
        roi: number;
    }>;
    getHistory(sellerId: string, page?: number, limit?: number): Promise<{
        data: DailySale[];
        total: number;
        page: number;
        limit: number;
    }>;
    getByWeekdayAnalytics(sellerId: string, startDate?: string, endDate?: string): Promise<any[]>;
    getPrediction(sellerId: string): Promise<any>;
    findProduct(productId: string): Promise<Product | null>;
    consumeInventory(productId: string, userId: string, units: number): Promise<void>;
    closeDay(dailySale: DailySale): Promise<DailySale>;
}
