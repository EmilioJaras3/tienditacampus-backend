import { JwtService } from '@nestjs/jwt';
import { UsersService } from '../users/users.service';
import { AuditService } from '../audit/audit.service';
import { RegisterDto } from './dto/register.dto';
import { LoginDto } from './dto/login.dto';
import { GoogleLoginDto } from './dto/google-login.dto';
import { VerifyTwoFactorDto } from './dto/verify-2fa.dto';
import { ResendTwoFactorDto } from './dto/resend-2fa.dto';
import { MailerService } from '../mailer/mailer.service';
import { TwoFactorService } from '../two-factor/two-factor.service';
export declare class AuthService {
    private readonly usersService;
    private readonly jwtService;
    private readonly auditService;
    private readonly mailerService;
    private readonly twoFactorService;
    constructor(usersService: UsersService, jwtService: JwtService, auditService: AuditService, mailerService: MailerService, twoFactorService: TwoFactorService);
    register(dto: RegisterDto): Promise<{
        user: {
            id: string;
            email: string;
            firstName: string;
            lastName: string;
            role: "admin" | "seller" | "buyer";
        };
        accessToken: string;
    }>;
    login(dto: LoginDto): Promise<{
        requiresTwoFactor: boolean;
        message: string;
    }>;
    verify2fa(dto: VerifyTwoFactorDto): Promise<{
        user: {
            id: string;
            email: string;
            firstName: string;
            lastName: string;
            role: "admin" | "seller" | "buyer";
            lastLoginAt: string;
            loginCount: number;
        };
        accessToken: string;
    }>;
    resend2fa(dto: ResendTwoFactorDto): Promise<{
        message: string;
    }>;
    loginWithGoogle(dto: GoogleLoginDto): Promise<{
        user: {
            id: string;
            email: string;
            firstName: string;
            lastName: string;
            role: "admin" | "seller" | "buyer";
            lastLoginAt: string;
            loginCount: number;
        };
        accessToken: string;
    }>;
    getProfile(userId: string): Promise<{
        id: string;
        email: string;
        firstName: string;
        lastName: string;
        phone: string | null;
        avatarUrl: string | null;
        role: "admin" | "seller" | "buyer";
        isEmailVerified: boolean;
        lastLoginAt: Date | null;
        loginCount: number;
        createdAt: Date;
    }>;
    rescueAdmin(email: string, secret: string): Promise<{
        message: string;
    }>;
    verifyEmail(email: string, code: string): Promise<{
        message: string;
    }>;
}
