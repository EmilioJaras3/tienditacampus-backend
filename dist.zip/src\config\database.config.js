"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.databaseConfig = void 0;
const databaseConfig = (configService) => {
    const url = configService.get('database.url') || process.env.DATABASE_URL;
    if (url) {
        return {
            type: 'postgres',
            url,
            autoLoadEntities: true,
            synchronize: configService.get('POSTGRES_SYNCHRONIZE', false),
            logging: configService.get('NODE_ENV') === 'development',
            ssl: false,
        };
    }
    return {
        type: 'postgres',
        host: configService.get('POSTGRES_HOST', 'localhost'),
        port: configService.get('POSTGRES_PORT', 5432),
        database: configService.get('POSTGRES_DB', 'tienditacampus'),
        username: configService.get('POSTGRES_USER'),
        password: configService.get('POSTGRES_PASSWORD'),
        autoLoadEntities: true,
        synchronize: configService.get('POSTGRES_SYNCHRONIZE') === 'true' || configService.get('POSTGRES_SYNCHRONIZE') === true,
        logging: configService.get('NODE_ENV') === 'development',
        ssl: false,
    };
};
exports.databaseConfig = databaseConfig;
//# sourceMappingURL=database.config.js.map