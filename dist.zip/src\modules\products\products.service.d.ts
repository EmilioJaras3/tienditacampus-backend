import { Repository } from 'typeorm';
import { Product } from './entities/product.entity';
import { CreateProductDto } from './dto/create-product.dto';
import { UpdateProductDto } from './dto/update-product.dto';
import { Category } from './entities/category.entity';
import { User } from '../users/entities/user.entity';
import { InventoryRecord } from '../inventory/entities/inventory-record.entity';
import { AuditService } from '../audit/audit.service';
export declare class ProductsService {
    private readonly productRepository;
    private readonly categoryRepository;
    private readonly inventoryRepository;
    private readonly auditService;
    constructor(productRepository: Repository<Product>, categoryRepository: Repository<Category>, inventoryRepository: Repository<InventoryRecord>, auditService: AuditService);
    findAllCategories(): Promise<Category[]>;
    create(createProductDto: CreateProductDto, user: User): Promise<Product>;
    findAll(user: User, page?: number, limit?: number): Promise<{
        data: any[];
        total: number;
        page: number;
        limit: number;
    }>;
    findMarketplace(query?: string, sellerId?: string, category?: string, page?: number, limit?: number): Promise<{
        data: any[];
        total: number;
        page: number;
        limit: number;
    }>;
    findOneMarketplace(id: string): Promise<Product>;
    findOne(id: string, user: User): Promise<Product>;
    update(id: string, updateProductDto: UpdateProductDto, user: User): Promise<Product>;
    remove(id: string, user: User): Promise<void>;
}
