export declare class BenchmarkingModule {
}
