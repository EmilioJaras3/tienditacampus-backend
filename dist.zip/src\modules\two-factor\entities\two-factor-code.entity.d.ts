import { User } from '../../users/entities/user.entity';
export declare class TwoFactorCode {
    id: string;
    userId: string;
    user: User;
    codeHash: string;
    expiresAt: Date;
    used: boolean;
    createdAt: Date;
}
