"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var SnapshotService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.SnapshotService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("typeorm");
const oauth_bigquery_service_1 = require("../auth/oauth-bigquery.service");
let SnapshotService = SnapshotService_1 = class SnapshotService {
    constructor(dataSource, oauthService) {
        this.dataSource = dataSource;
        this.oauthService = oauthService;
        this.logger = new common_1.Logger(SnapshotService_1.name);
    }
    async executeDailySnapshot(accessToken) {
        try {
            this.logger.log('🔄 Iniciando snapshot diario...');
            const isTokenValid = await this.oauthService.validateToken(accessToken);
            if (!isTokenValid) {
                throw new Error('OAuth token is invalid or expired');
            }
            this.logger.log('✅ Token OAuth validado');
            const rows = await this.queryDailyExport();
            this.logger.log(`📊 ${rows.length} registros extraídos de v_daily_export`);
            if (rows.length === 0) {
                this.logger.warn('⚠️ No hay datos para exportar. ¿Ejecutaste las consultas de prueba?');
                return;
            }
            const jsonData = this.serializeRows(rows);
            await this.oauthService.sendToBigQuery(accessToken, jsonData);
            this.logger.log(`✅ Datos enviados a BigQuery exitosamente`);
            await this.resetStatistics();
            this.logger.log('🔄 pg_stat_statements reiniciado');
            this.logger.log('✅ Snapshot diario completado exitosamente');
        }
        catch (error) {
            this.logger.error('❌ Error en snapshot diario:', error.message);
            this.logger.warn('⚠️ NO se ejecutó reset. Mantén los datos para reintento.');
            throw error;
        }
    }
    async queryDailyExport() {
        const result = await this.dataSource.query(`
      SELECT * FROM v_daily_export
      WHERE snapshot_date = CURRENT_DATE
      ORDER BY project_id, queryid;
    `);
        return result || [];
    }
    serializeRows(rows) {
        return rows.map(row => ({
            project_id: row.project_id,
            snapshot_date: row.snapshot_date,
            queryid: row.queryid,
            dbid: row.dbid,
            userid: row.userid,
            query: row.query,
            calls: row.calls,
            total_exec_time_ms: row.total_exec_time_ms,
            mean_exec_time_ms: row.mean_exec_time_ms,
            min_exec_time_ms: row.min_exec_time_ms,
            max_exec_time_ms: row.max_exec_time_ms,
            stddev_exec_time_ms: row.stddev_exec_time_ms,
            rows_returned: row.rows_returned,
            shared_blks_hit: row.shared_blks_hit,
            shared_blks_read: row.shared_blks_read,
            shared_blks_dirtied: row.shared_blks_dirtied,
            shared_blks_written: row.shared_blks_written,
            temp_blks_read: row.temp_blks_read,
            temp_blks_written: row.temp_blks_written,
            ingestion_timestamp: row.ingestion_timestamp,
        }));
    }
    async resetStatistics() {
        await this.dataSource.query('SELECT pg_stat_statements_reset();');
    }
    async exportToCSV(projectId) {
        const rows = await this.dataSource.query(`
      SELECT * FROM v_daily_export
      WHERE project_id = $1 AND snapshot_date = CURRENT_DATE;
    `, [projectId]);
        const csv = this.rowsToCSV(rows || []);
        return csv;
    }
    rowsToCSV(rows) {
        if (rows.length === 0)
            return '';
        const headers = Object.keys(rows[0]);
        const headerRow = headers.join(',');
        const dataRows = rows
            .map(row => Object.values(row).join(','))
            .join('\n');
        return `${headerRow}\n${dataRows}`;
    }
};
exports.SnapshotService = SnapshotService;
exports.SnapshotService = SnapshotService = SnapshotService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [typeorm_1.DataSource,
        oauth_bigquery_service_1.OAuthBigQueryService])
], SnapshotService);
//# sourceMappingURL=snapshot.service.js.map